<div class="row">
    <div class="col-sm-12">
    	<div class="col-sm-12">
	        <section class="panel">
				<header class="panel-heading ">
					<a title="show depth" href="">Home - <?php echo date("Y-m-d H:i:s"); ?></a>
				
				</header>
				<div class="panel-body" style="overflow: scroll;">
					<div class=" col-md-2">
						<img style="width:1000px;" src="<?=base_url()?>assets/images/erp-ttgGroup.jpg">
					</div>
					<div class=" col-md-8">
						
						
					</div>
					
				</div>
				
			</section>
	    </div>
    
    	<?php if($this->user == 1){ 
		//	print_r($_COOKIE);
			//print_r($_SESSION);
		}?>
    	

	   
    </div>
</div>



            

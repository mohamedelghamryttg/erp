<?php
echo "Directory access is forbidden.";
?>
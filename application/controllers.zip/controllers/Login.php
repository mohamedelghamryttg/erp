<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
    }
    public function index(){

        $this->load->view('login_new.php');
    }

    public function doLogin(){
    	$email = $this->input->post('email');
    	$password = base64_encode($this->input->post('password'));

    	$user = $this->db->get_where('users',array('email' => $email, 'password' => $password,'status' => '1'));
    	$check = $user->num_rows();
    	$data = $user->row();
    	if($check > 0){
    		$login = array(
		      'id' => $data->id,
              'username' => $data->user_name,
		      'role' => $data->role,
              'brand' => $data->brand,
              'emp_id' => $data->employees_id,
		      'loggedin' => 1
		    );
		    $this->session->set_userdata($login);
		    redirect(base_url().'admin');
    	}else{
    		$true = "Your combination of username and password are incorrect ...";
            $this->session->set_flashdata('true', $true);
            redirect(base_url()."login");
    	}
    }

    public function logout(){
    $this->session->sess_destroy();
    redirect(base_url().'login');
  }

  public function attendanceTest(){
    	$ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://attendance.thetranslationgate.com:8080/abc/index.php/api/attendanceTest");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, "filter=1");
            $data['attendance'] = json_decode(curl_exec($ch),TRUE);
    	print_r($data['attendance']);	
    // $this->load->view('hr/attendanceTest.php',$data);
    }

}
?>
<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <meta name="description" content="">
                    <meta name="author" content="">
                    <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                    <title>Falaq| Site Manager</title>
                    <style>
                    body {
                        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                        font-size: 14px;
                        line-height: 1.428571429;
                        color: #333;
                    }
                    section#unseen
                    {
                        overflow: scroll;
                        width: 100%
                    }
                    </style>
                    <!--Core js-->
                </head>

                <body>
                <div class="panel-body">
                                <div class="adv-table editable-table ">
                                    <div class="clearfix">
                                        <div class="btn-group">
                                            <span class=" btn-primary" style="">
                                            </span>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="space15"></div>
                                    
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                            <tr>
                                                 <td colspan=2 style="background-color: #ddd;">Task Data</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Task Code</td>
                                                 <td style="background-color:#ddd;">Test</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                          </div>
                </body>
                </html>
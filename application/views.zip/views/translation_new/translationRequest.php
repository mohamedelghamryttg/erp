<script type="text/javascript">
  function hideDiv() {
    $("#filter").hide();
    $("#filter2").hide();
  }
    window.onload = hideDiv;
</script>
<!--begin::Card-->
                <div class="card">
                  <div class="card-header flex-wrap border-0 pt-6 pb-0">
                    <div class="card-title btn_lightgray">
                      <h3 class="card-label">Translation Requests Waiting Confimation - <span class="btn btn-danger"><span><?=$newTasks->num_rows()?></span></span></h3> 
                       <button id="button_filter2" onclick="showAndHide('filter2','button_filter2');" style="padding-top:0pc; float: right;font-size: 15px;" class="btn btn-success "><i class="fa fa-chevron-down"></i></button>
                    </div>
                    <div class="card-toolbar">
                     
                    
                    </div>
                  </div>
                  <div class="card-body" id="filter2">
                    <!--begin: Datatable-->
                    <table class="table table-separate table-head-custom table-checkable table-hover" id="kt_datatable2">
                     <thead>
              <tr>
                <th>PM</th>
                <th>Task Type</th>
                <th>Volume</th>
                <th>Unit</th>
                <th>Task Name</th>
                <th>Start Date</th>
                <th>Delivery Date</th>
                <th>Created Date</th>
               <th>View Task</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($newTasks->result() as $row) { 
                $jobData = $this->projects_model->getJobData($row->job_id);

              ?>
                <tr>
                  <td><?=$this->admin_model->getAdmin($row->created_by)?></td>
                  <td><?=$this->admin_model->getTaskType($row->task_type)?></td>
                  <td><?php echo $row->count; ?></td>
                                  <td><?=$this->admin_model->getUnit($row->unit)?></td>
                  <td><?=$row->subject?></td>
                  <td><?=$row->start_date?></td>
                  <td><?=$row->delivery_date?></td>
                  <td><?=$row->created_at?></td>
                  <td>
                  <?php if($permission->add == 1){ ?>
                    <a href="<?php echo base_url()?>translation/saveRequest?t=<?php echo 
                      base64_encode($row->id) ;?>" class="">
                        <i class="fa fa-eye"></i> View Task
                    </a>
                  <?php } ?>
                  </td>
                </tr>
              <?php } ?>
                    
            </tbody>
                    </table>
                    <!--end: Datatable-->
                  </div>
                </div>
                <!--end::Card-->
                <!--begin::Card-->
                <div class="card">
                  <div class="card-header flex-wrap border-0 pt-6 pb-0">
                    <div class="card-title btn_lightgray">
                      <h3 class="card-label">Request Filter</h3> 
                       <button id="button_filter" onclick="showAndHide('filter','button_filter');" style="padding-top:0pc; float: right;font-size: 15px;" class="btn btn-success "><i class="fa fa-chevron-down"></i></button>
                    </div>
                    <div class="card-toolbar">
                     
                    
                    </div>
                  </div>
                  <div class="card-body" id="filter">
                    
                    <!-- start search form card --> 
                  <div class="card card-custom gutter-b example example-compact">
          <div class="card-header">
            <h3 class="card-title">Search Translation Requests</h3>
          </div>
          <?php 
           if(!empty($_REQUEST['code'])){
                $code = $_REQUEST['code'];
                }else{
                    $code = "";
                }

                if(!empty($_REQUEST['pm'])){
                    $pm = $_REQUEST['pm'];
                }else{
                    $pm = "";
                }

                if(!empty($_REQUEST['date_from']) && isset($_REQUEST['date_to'])){
                    $date_from = date("Y-m-d", strtotime($_REQUEST['date_from']));
                    $date_to = date("Y-m-d", strtotime("+1 day", strtotime($_REQUEST['date_to'])));
                }else{
                    $date_to = "";
                    $date_from = "";
                }
                if(!empty($_REQUEST['subject'])){
                $subject = $_REQUEST['subject'];
                }else{
                    $subject = "";
                }

      ?>

            <form class="form"id="dtpRequestForm" id="translationRequestForm" action="<?php echo base_url()?>translation/" method="get" enctype="multipart/form-data">
              <div class="form-group row">
                <label class="col-lg-2 control-label" for="role name">Request Code</label>
                <div class="col-lg-3">
                     <input class="form-control " type="text" name="code" value="<?=$code?>"> 
                </div>
                 <label class="col-lg-2 control-label" for="role name">Requestor Name</label>
                <div class="col-lg-3">
                  <select name="pm" class="form-control m-b" id="pm"/>
                           <option value="" disabled="disabled" selected="selected">-- Select Requestor --</option>
                        <?=$this->admin_model->selectAllPm($pm,$this->brand)?>
                  </select>
               </div>
              </div>
             <div class="form-group row">
                <label class="col-lg-2 control-label" for="role date">Date From :</label>
                <div class="col-lg-3">
                     <input class="form-control date_sheet" type="text" name="date_from" autocomplete="off"> 
                </div>
                <label class="col-lg-2 control-label" for="role date">Date To :</label>
                <div class="col-lg-3">
                     <input class="form-control date_sheet" type="text" name="date_to" autocomplete="off">
                </div>
              </div>
            <div class="form-group row">
                <label class="col-lg-2 control-label" for="role name">Task Name</label>
                <div class="col-lg-3">
                     <input class="form-control " type="text"  name="subject" value="<?=$subject?>"> 
                </div>
              </div>

             
             <div class="card-footer">
              <div class="row">
               <div class="col-lg-2"></div>
               <div class="col-lg-10">
                           <button class="btn btn-success mr-2" name="search" type="submit">Search</button>   
                           <button class="btn btn-secondary" onclick="var e2 = document.getElementById('translationRequestForm'); e2.action='<?=base_url()?>translation/exportRequests'; e2.submit();" name="export" type="submit"><i class="fa fa-download" aria-hidden="true"></i> Export To Excel</button>
                         <a href="<?=base_url()?>translation" class="btn btn-warning"><i class="la la-trash"></i>Clear Filter</a> 

                         

               </div>
              </div>
             </div>
            </form>
                       </div>
                        
              <!-- end search form -->

                  </div>
                </div>
                <!--end::Card--> 
  <!--begin::Card-->
                <div class="card">
                  <div class="card-header flex-wrap border-0 pt-6 pb-0">
                    <div class="card-title">
                      <h3 class="card-label">All Requests <span class="btn btn-danger"><span><?=$total_rows?></span></span></h3>
                    </div>
                    <div class="card-toolbar">
                     <?php if($this->session->flashdata('true')){ ?>
                      <div class="alert alert-success" role="alert">
                              <span class="fa fa-check-circle"></span>
                              <span><strong><?=$this->session->flashdata('true')?></strong></span>
                            </div>
                      <?php  } ?>
                      <?php if($this->session->flashdata('error')){ ?>
                            <div class="alert alert-danger" role="alert">
                              <span class="fa fa-warning"></span>
                              <span><strong><?=$this->session->flashdata('error')?></strong></span>
                            </div>
                      <?php  } ?>
                    </div>
                  </div>
                  <div class="card-body">
                    <!--begin: Datatable-->
                    <table class="table table-separate table-head-custom table-checkable table-hover" id="kt_datatable2">
                    <thead>
                           <tr>
                                <th>Task Code</th>
                               <th>Count</th>
                               <th>TM</th>
                               <th>Delivery Date</th>
                               <th>Status</th>
                               <th>Created By</th>
                               <th>View Jobs</th>
                               <th>View Request</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($translation_request->result() as $row) { 
                $jobData = $this->projects_model->getJobData($row->job_id);
                      $priceListData = $this->projects_model->getJobPriceListData($jobData->price_list);
              ?>
              <tr>
                <td><a href="<?php echo base_url()?>translation/TranslationJobs?t=<?php echo base64_encode($row->id) ;?>" class="">Translation-<?=$row->id?></a></td>
                <td><?php echo $row->count ;?></td>
                <td><?php echo $row->tm ;?></td>
                <td><?php echo $row->delivery_date ;?></td>
                <td><?php echo $this->projects_model->getTranslationTaskStatus($row->status) ;?></td>
                <td><?php echo $this->admin_model->getAdmin($row->created_by) ;?></td>
                <td>
                  <?php if($permission->edit == 1){ ?>
                  <a href="<?php echo base_url()?>translation/TranslationJobs?t=<?php echo 
                    base64_encode($row->id) ;?>" class="">
                      <i class="fa fa-eye"></i> View Jobs
                  </a>
                  <?php } ?>
                </td>
                <td>
                  <?php if($permission->edit == 1){ ?>
                  <a href="<?php echo base_url()?>translation/viewRequest?t=<?php echo 
                    base64_encode($row->id) ;?>" class="">
                      <i class="fa fa-eye"></i> View Request
                  </a>
                  <?php } ?>
                </td>
              </tr>
            <?php } ?>
            </tbody>
                    </table>
                    <!--end: Datatable-->
                  </div>
                </div>
                <!--end::Card-->
<script>
   window.realAlert = window.alert;
   window.alert = function() {};
</script>

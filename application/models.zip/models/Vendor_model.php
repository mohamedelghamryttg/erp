<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Auth
*
* Author:  MOHAMED EL-SHEHABY
*
*/

class Vendor_model extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// public function AllVendors($permission,$user,$brand,$filter)
 //    {
 //        if($permission->view == 1){
 //            $data = $this->db->query(" SELECT * FROM `vendor` WHERE brand = '$brand' AND ".$filter." ORDER BY id DESC");
 //        }elseif($permission->view == 2){
 //            $data = $this->db->query(" SELECT * FROM `vendor` WHERE brand = '$brand' AND created_by = '$user' AND ".$filter." ORDER BY id DESC");
 //        }
 //        return $data;
 //    }

    public function AllVendors($permission,$user,$brand,$filter)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT v.*,s.source_lang,s.target_lang,s.dialect,s.service,s.task_type,s.rate,s.special_rate,s.unit,s.currency,s.created_at AS sheetCreatedAt,s.created_by AS sheetCreatedBy,s.id AS sheetId FROM `vendor` AS v LEFT OUTER JOIN vendor_sheet AS s ON v.id = s.vendor 
                 WHERE brand = '$brand' AND ".$filter." ORDER BY id DESC");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT v.*,s.source_lang,s.target_lang,s.dialect,s.service,s.task_type,s.rate,s.special_rate,s.unit,s.currency,s.created_at AS sheetCreatedAt,s.created_by AS sheetCreatedBy,s.id AS sheetId FROM `vendor` AS v LEFT OUTER JOIN vendor_sheet AS s ON v.id = s.vendor 
                 WHERE brand = '$brand' AND created_by = '$user' AND ".$filter." ORDER BY id DESC");
        }
        return $data;
    }

	public function AllVendorsTTG($permission,$user,$brand,$filter)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT v.*,s.source_lang,s.target_lang,s.dialect,s.service,s.task_type,s.rate,s.special_rate,s.unit,s.currency,s.created_at AS sheetCreatedAt,s.created_by AS sheetCreatedBy,s.id AS sheetId,s.copied FROM `vendor` AS v LEFT OUTER JOIN vendor_sheet AS s ON v.id = s.vendor 
                 WHERE brand = '$brand' AND ".$filter." ORDER BY v.id DESC");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT v.*,s.source_lang,s.target_lang,s.dialect,s.service,s.task_type,s.rate,s.special_rate,s.unit,s.currency,s.created_at AS sheetCreatedAt,s.created_by AS sheetCreatedBy,s.id AS sheetId,s.copied FROM `vendor` AS v LEFT OUTER JOIN vendor_sheet AS s ON v.id = s.vendor 
                 WHERE brand = '$brand' AND created_by = '$user' AND ".$filter." ORDER BY v.id DESC");
        }
        return $data;
    }

    public function AllVendorsPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT * FROM `vendor` WHERE brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT * FROM `vendor` WHERE brand = '$brand' AND created_by = '$user' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

    public function viewVmTickets($brand,$filter=""){
        if($filter){
        $data = $this->db->query(" SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM `vm_ticket` AS v WHERE ".$filter." HAVING brand = '$brand' order by id desc");
        }else{
        $data = $this->db->query(" SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM `vm_ticket` AS v HAVING brand = '$brand' order by id desc");
        }
        return $data;   
    }

    public function viewVmTicketsPages($brand,$limit,$offset){
        $data = $this->db->query("SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM vm_ticket AS v HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

    public function viewSalesVmTickets($permission,$user,$from_id)
    {
        if($permission->view == 1){
            $data = $this->db->order_by('id','desc')->get_where('vm_ticket',array('from_id'=>$from_id,'ticket_from'=>1));
        }elseif($permission->view == 2){
            $data = $this->db->order_by('id','desc')->get_where('vm_ticket',array('from_id'=>$from_id,'ticket_from'=>1,'created_by'=>$user));
        }
        return $data;
    }

        public function viewVmTicketWithoutOpp($permission,$brand,$user)
    {   
         if($brand == 3 AND $permission->view == 1){
                $data = $this->db->query("SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand From vm_ticket as v WHERE from_id = 0 AND ticket_from = 3 HAVING brand = 3 order by id desc");
         }else{
            if($permission->view == 1){
                $data = $this->db->order_by('id','desc')->get_where('vm_ticket',array('from_id'=>0,'ticket_from'=>3));
        
            }elseif($permission->view == 2){
                $data = $this->db->order_by('id','desc')->get_where('vm_ticket',array('from_id'=>0,'ticket_from'=>3,'created_by'=>$user));
            }
         }

        return $data;
    }
    

    public function viewPmVmTickets($permission,$user,$from_id)
    {
        if($permission->view == 1){
            $data = $this->db->order_by('id','desc')->get_where('vm_ticket',array('from_id'=>$from_id,'ticket_from'=>2));
        }elseif($permission->view == 2){
            $data = $this->db->order_by('id','desc')->get_where('vm_ticket',array('from_id'=>$from_id,'ticket_from'=>2,'created_by'=>$user));
        }
        return $data;
    }
  
  	public function viewPmAllTickets($permission,$brand,$filter="",$user){
        if($permission->view == 1){
            $data = $this->db->query(" SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM `vm_ticket` AS v WHERE ".$filter." AND ticket_from = '2' HAVING brand = '$brand' order by id desc");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM `vm_ticket` AS v WHERE ".$filter." AND ticket_from = '2' AND created_by = '$user' HAVING brand = '$brand' order by id desc");
        }
        
        return $data;   
    }

    public function viewPmAllTicketsPages($permission,$brand,$user,$limit,$offset){
        if($permission->view == 1){
            $data = $this->db->query(" SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM `vm_ticket` AS v WHERE ticket_from = '2' HAVING brand = '$brand' order by id desc LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM `vm_ticket` AS v WHERE ticket_from = '2' AND created_by = '$user' HAVING brand = '$brand' order by id desc LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

    public function viewVmSheet($permission,$user,$brand,$filter="")
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT v.*,(SELECT brand FROM vendor WHERE vendor.id = v.vendor) AS brand FROM `vendor_sheet` AS v  WHERE ".$filter." HAVING brand = '$brand' ORDER BY id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT v.*,(SELECT brand FROM vendor WHERE vendor.id = v.vendor) AS brand FROM `vendor_sheet` AS v WHERE created_by = '$user' AND ".$filter." HAVING brand = '$brand' ORDER BY id DESC ");
        }
        return $data;
    }

    public function viewVmSheetPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query("  SELECT v.*,(SELECT brand FROM vendor WHERE vendor.id = v.vendor) AS brand FROM `vendor_sheet` AS v HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("  SELECT v.*,(SELECT brand FROM vendor WHERE vendor.id = v.vendor) AS brand FROM `vendor_sheet` AS v  WHERE created_by = '$user' HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

	public function selectTicketType($select=""){
        if($select == 1){
            $selected1 = 'selected';
        }elseif ($select == 2) {
            $selected2 = 'selected';
        }
        elseif ($select == 3) {
            $selected3 = 'selected';
        }
        elseif ($select == 4) {
            $selected4 = 'selected';
        }
        elseif ($select == 5) {
            $selected5 = 'selected';
        }
        else{
            $selected1 = '';
            $selected2 = '';
            $selected3 = '';
            $selected4 = '';
            $selected5 = '';
          }

        $outpt = '<option value="1" '.$selected1.'>New Resource</option>
                  <option value="2" '.$selected2.'>Price Inquiry</option>
                  <option value="3" '.$selected3.'>General</option>
                  <option value="4" '.$selected4.'>Resources Availability</option>
                  <option value="5" '.$selected5.'>CV Request</option>
                  ';
        return $outpt;
	}

     public function selectSalesTicketType($select=""){
        if($select == 1){
            $selected1 = 'selected';
        }elseif ($select == 2) {
            $selected2 = 'selected';
        }
        elseif ($select == 4) {
            $selected4 = 'selected';
        }
        elseif ($select == 5) {
            $selected5 = 'selected';
        }
        else{
            $selected1 = '';
            $selected2 = '';
            $selected4 = '';
            $selected5 = '';
          }

        $outpt = '<option value="1" '.$selected1.'>New Resource</option>
                  <option value="2" '.$selected2.'>Price Inquiry</option>
                  <option value="4" '.$selected4.'>Resources Availability</option>
                  <option value="5" '.$selected5.'>CV Request</option>
                  ';
        return $outpt;
    }

	public function getTicketType($select=""){
        if($select == 1){
            $outpt = 'New Resource';
        }elseif ($select == 2) {
            $outpt = 'Price Inquiry';
        }
        elseif ($select == 3) {
            $outpt = 'General';
        }
        elseif ($select == 4) {
            $outpt = 'Resources Availability';
        }
        elseif ($select == 5) {
            $outpt = 'CV Request';
        }
        else{
        	$outpt = "";
        }
        return $outpt;
	}

    public function selectTicketStatusPartly($select=""){
        if ($select == 2) {
            $selected2 = 'selected';
        }
        elseif ($select == 3) {
            $selected3 = 'selected';
        }
        else{
            $selected2 = '';
            $selected3 = '';
          }

        $outpt = '<option value="2" '.$selected2.'>Opened</option>
                  <option value="3" '.$selected3.'>Partly Closed</option>
                  ';
        return $outpt;
    }

    public function selectTicketStatusClosed($select=""){
        if ($select == 2) {
            $selected2 = 'selected';
        }
        elseif ($select == 3) {
            $selected3 = 'selected';
        }
        elseif ($select == 4) {
            $selected4 = 'selected';
        }
        else{
            $selected2 = '';
            $selected3 = '';
            $selected4 = '';
          }

        $outpt = '<option value="2" '.$selected2.' disabled="">Opened</option>
                  <option value="3" '.$selected3.'>Partly Closed</option>
                  <option value="4" '.$selected4.'>Closed</option>
                  ';
        return $outpt;
    }

    public function selectAllTicketStatus($select=""){
        if($select == 1){
            $selected1 = 'selected';
        }elseif ($select == 2) {
            $selected2 = 'selected';
        }
        elseif ($select == 3) {
            $selected3 = 'selected';
        }
        elseif ($select == 4) {
            $selected4 = 'selected';
        }
        elseif ($select == 5) {
            $selected5 = 'selected';
        }
        else{
            $selected1 = '';
            $selected2 = '';
            $selected3 = '';
            $selected4 = '';
            $selected5 = '';
          }

        $outpt = '<option value="1" '.$selected1.'>New</option>
                  <option value="2" '.$selected2.'>Opened</option>
                  <option value="3" '.$selected3.'>Partly Closed</option>
                  <option value="4" '.$selected4.'>Closed</option>
                  <option value="5" '.$selected5.'>Closed Waiting Requester Acceptance</option>
                  ';
        return $outpt;
    }

    public function getTicketStatus($select=""){
         if($select == 0){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #FF4E28">Rejected</span>';
        }
        else if($select == 1){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #5e5e5d">New</span>';
        }
        else if($select == 2){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #07b817">Opened</span>';
        }
        else if($select == 3){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #e8e806">Partly Closed</span>';
        }
        else if($select == 4){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #fb0404">Closed</span>';
        }
        else if($select == 5){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #f05a0a">Closed Waiting Requester Acceptance</span>';
        }
        else{
            $outpt = "";
        }
        return $outpt;
    }

    public function getVendorName($vendor){
        $result = $this->db->get_where('vendor',array('id' => $vendor))->row();
        if(isset($result->name)){
            return $result->name;
        }else{
            return '';
        }
    }

    public function selectVendor($id="",$brand="")
    {
        $vendor = $this->db->order_by('name','ASC')->get_where('vendor',array('brand' => $brand))->result();
        $data = "";
        foreach ($vendor as $vendor) {
            if ($vendor->id == $id) {
                $data .= "<option value='" . $vendor->id . "' selected='selected'>" . $vendor->name . "</option>";
            } else {
                $data .= "<option value='" . $vendor->id . "'>" . $vendor->name . "</option>";
            }
        }
        return $data;
    }
  	
  	public function selectVendorByMail($id="",$brand="")
    {
        $vendor = $this->db->order_by('name','ASC')->get_where('vendor',array('brand' => $brand))->result();
        $data = "";
        foreach ($vendor as $vendor) {
            if ($vendor->id == $id) {
                $data .= "<option value='" . $vendor->id . "' selected='selected'>" . $vendor->name.' - '.$vendor->email . "</option>";
            } else {
                $data .= "<option value='" . $vendor->id . "'>" . $vendor->name.' - '.$vendor->email . "</option>";
            }
        }
        return $data;
    }
  
  	public function selectVendorSheet($id="",$brand="")
    {
        $vendor = $this->db->query(" SELECT DISTINCT id,vendor,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand FROM `vendor_sheet` HAVING brand = '$brand'  ")->result();
        $data = "";
        foreach ($vendor as $vendor) {
            if ($vendor->id == $id) {
                $data .= "<option value='" . $vendor->id . "' selected='selected'>" . Self::getVendorName($vendor->vendor) . "</option>";
            } else {
                $data .= "<option value='" . $vendor->id . "'>" . Self::getVendorName($vendor->vendor) . "</option>";
            }
        }
        return $data;
    }
  
  	public function selectVendorByJob($id,$source,$target,$service,$brand)
    {
        // $vendor = $this->db->get_where('vendor_sheet',array('source_lang'=>$source,'target_lang'=>$target,'service'=>$service))->result();
        // $vendor = $this->db->query(" SELECT *,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand FROM `vendor_sheet` WHERE source_lang = '$source' AND target_lang = '$target' AND service = '$service' HAVING brand = '$brand' ")->result();
        // $data = "";
        // foreach ($vendor as $vendor) {
        //     if ($vendor->id == $id) {
        //         $data .= "<option value='" . $vendor->id . "' selected='selected'>" . $this->vendor_model->getVendorName($vendor->vendor) . "</option>";
        //     } else {
        //         $data .= "<option value='" . $vendor->id . "'>" . $this->vendor_model->getVendorName($vendor->vendor) . "</option>";
        //     }
        // }
        // return $data;

        $vendor = $this->db->query(" SELECT DISTINCT v.id,v.name FROM `vendor` AS v LEFT OUTER JOIN vendor_sheet AS s ON s.vendor = v.id WHERE v.brand = '$brand' AND s.source_lang = '$source' AND s.target_lang = '$target' AND s.service = '$service' AND v.status = '0' ORDER BY v.name ASC ")->result();

        foreach ($vendor as $vendor) {
            if ($vendor->id == $id) {
                $data .= "<option value='" . $vendor->id . "' selected='selected'>" . $vendor->name . "</option>";
            } else {
                $data .= "<option value='" . $vendor->id . "'>" . $vendor->name . "</option>";
            }
        }
        return $data;
    }

    public function getTicketStatusNum($brand){
        $data['new'] = $this->db->query(" SELECT *,(SELECT brand FROM `users` WHERE users.id = created_by) AS brand FROM `vm_ticket` WHERE status = 1 HAVING brand = '$brand' ")->num_rows();
        $data['opened'] = $this->db->query(" SELECT *,(SELECT brand FROM `users` WHERE users.id = created_by) AS brand FROM `vm_ticket` WHERE status = 2 HAVING brand = '$brand' ")->num_rows();
        $data['part_closed'] = $this->db->query(" SELECT *,(SELECT brand FROM `users` WHERE users.id = created_by) AS brand FROM `vm_ticket` WHERE status = 3 HAVING brand = '$brand' ")->num_rows();
        $data['closed'] = $this->db->query(" SELECT *,(SELECT brand FROM `users` WHERE users.id = created_by) AS brand FROM `vm_ticket` WHERE status = 4 HAVING brand = '$brand' ")->num_rows();
        // $data = $this->db->query(" SELECT (SELECT COUNT(*) FROM `vm_ticket` WHERE status = 1) AS new,(SELECT COUNT(*) FROM `vm_ticket` WHERE status = 2) AS opened,(SELECT COUNT(*) FROM `vm_ticket` WHERE status = 3) AS part_closed,(SELECT COUNT(*) FROM `vm_ticket` WHERE status = 4) AS closed ")->row();
        return $data;
    }

    public function changeTicketToOpen($id,$user){
        $result = $this->db->get_where('vm_ticket',array('id' => $id))->row();
        if($result->status == 1){
            $data['status'] = 2;
            if($this->db->update('vm_ticket',$data,array('id'=>$id))){
                $this->addTicketTimeStatus($id,$user,2);
            }
        }
    }

    public function addTicketTimeStatus($ticket,$user,$status){
        $time['status'] = $status;
        $time['ticket'] = $ticket;
        $time['created_by'] = $user;
        $time['created_at'] = date("Y-m-d H:i:s");
        $this->db->insert('vm_ticket_time',$time);
    }

    public function ticketTime($id){
        $row = $this->db->get_where('vm_ticket_time',array('ticket'=>$id))->result();
        $hrs = 0;
        $counter = 0;
        foreach ($row as $row) {
            if($row->status <= 3){
                $time = strtotime($row->created_at);
            }else{
                $time = strtotime($row->created_at) - $time;
                $hrs = $hrs + $time / (60 * 60);
            }
        }
        // return round($hrs,2);
        $arr = round($hrs,2);
        $date = explode(".", $arr);
        if(isset($date[1])){
            return $date[0].':'.round(($date[1]/100)*60);
        }else{
            return $date[0].':0';
        }
    }
  
  	public function getVendorData($id){
        $data = $this->db->get_where('vendor',array('id'=>$id))->row();
        return $data;
    }
  
  	public function getVendorSheetData($id){
        $data = $this->db->get_where('vendor_sheet',array('id'=>$id))->row();
        return $data;
    }
  
  	public function getVendorSheetByVendor($vendor){
        $data = $this->db->get_where('vendor_sheet',array('vendor'=>$vendor))->result();
        return $data;
    }
  
  	public function sendNewTicketEmail($user,$ticketNumber,$brand,$emailSubject="",$opportunity=0){
        $pmMail = $this->admin_model->getUserEmail($user);
        $subject = "New Ticket : #".$ticketNumber." - ".$emailSubject;

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail. "\r\n";
        $headers .= 'From: '.$pmMail."\r\n".'Reply-To: '.$pmMail."\r\n";
    
    	//PM CC..
        if($opportunity > 0){
            $pmId = $this->db->get_where('sales_opportunity',array('id'=>$opportunity))->row()->pm;
            $headers .= "Cc: ".$this->admin_model->getUserEmail($pmId). "\r\n";
        }

        if($brand == 1){
            $mailTo = " vm@thetranslationgate.com ";
        }elseif($brand == 2){
            $mailTo = " vm@dtpzone.com ";
        }elseif ($brand == 3) {
            $mailTo = " vm@europelocalize.com ";
            $headers .= "Cc: suhan.yilmaz@europelocalize.com" . "\r\n";   
        }elseif ($brand == 4) {
            $mailTo = " vm@afaqtranslations.com ";
            $headers .= "Cc: nour.mahmoud@afaqtranslations.com" . "\r\n";   
        }

        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                    <p>Dear VM Team,</p>
                       <p> Please Check This New Ticket #'.$ticketNumber.' </p>
                       <p>Created By : '.$this->admin_model->getUser($user).'</p>
                       <p> Thanks</p>
                    </body>
                    </html>';
        mail($mailTo,$subject,$message,$headers);
    }
  	
  	public function sendTicketMail($user,$ticketNumber,$mailSubject,$msg,$brand){
        $userData = $this->admin_model->getUserData($user);
        $MailTo = $userData->email;
        $subject = $mailSubject." : #".$ticketNumber;
        $ticketData = $this->db->get_where('vm_ticket',array('id'=>$ticketNumber))->row();
    
    	$headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
        if($ticketData->ticket_from == 1){
            $msgData = '<p> Opportunity Number: #'.$ticketData->from_id.'</p>';
        	$pmId = $this->db->get_where('sales_opportunity',array('id'=>$ticketData->from_id))->row()->pm;
            $headers .= "Cc: ".$this->admin_model->getUserEmail($pmId). "\r\n";
        }elseif($ticketData->ticket_from == 2){
            $msgData = '<p> Project Number: #'.$ticketData->from_id.'</p>';
        }
        
      	if($brand == 1){
            $headers .= "Cc: vm@thetranslationgate.com " . "\r\n";
            $headers .= 'From: vm@thetranslationgate.com '."\r\n".'Reply-To: vm@thetranslationgate.com'."\r\n";
        }elseif($brand == 2){
            $headers .= "Cc: vm@dtpzone.com " . "\r\n";
            $headers .= 'From: vm@dtpzone.com '."\r\n".'Reply-To: vm@dtpzone.com'."\r\n";
        }elseif ($brand == 3) {
            $headers .= "Cc: vm@europelocalize.com " . "\r\n".'Bcc: suhan.yilmaz@europelocalize.com'."\r\n";
            $headers .= 'From: vm@europelocalize.com '."\r\n".'Reply-To: vm@europelocalize.com'."\r\n";
        }elseif ($brand == 4) {
            $headers .= "Cc: vm@afaqtranslations.com " . "\r\n";
            $headers .= "Cc: nour.mahmoud@afaqtranslations.com" . "\r\n";
            $headers .= 'From: vm@afaqtranslations.com '."\r\n".'Reply-To: vm@afaqtranslations.com'."\r\n";
        }


        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                    <p>Dear '.$userData->user_name.' ,</p>
                       <p> '.$msg.' </p>
                       <p> '.$msgData.' </p>
                       <p> Thanks</p>
                    </body>
                    </html>';
        mail($MailTo,$subject,$message,$headers);
    }
  
  	public function TicketReplyMail($user,$ticketNumber,$brand,$comment,$emailSubject=""){
        $userData = $this->admin_model->getUserData($user);
        $MailTo = $userData->email;
        $subject = " New Reply : #".$ticketNumber." Project Name :".$emailSubject;
        $ticketData = $this->db->get_where('vm_ticket',array('id'=>$ticketNumber))->row();
        
    	$headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        if($ticketData->ticket_from == 1){
            $msgData = '<p> Opportunity Number: #'.$ticketData->from_id.'</p>';
            $pmId = $this->db->get_where('sales_opportunity',array('id'=>$ticketData->from_id))->row()->pm;
            $headers .= "Cc: ".$this->admin_model->getUserEmail($pmId). "\r\n";
        }elseif($ticketData->ticket_from == 2){
            $msgData = '<p> Project Number: #'.$ticketData->from_id.'</p>';
        }
        
      	if($brand == 1){
            $headers .= "Cc: vm@thetranslationgate.com " . "\r\n";
            $headers .= 'From: vm@thetranslationgate.com '."\r\n".'Reply-To: vm@thetranslationgate.com'."\r\n";
        }elseif($brand == 2){
            $headers .= "Cc: vm@dtpzone.com " . "\r\n";
            $headers .= 'From: vm@dtpzone.com '."\r\n".'Reply-To: vm@dtpzone.com'."\r\n";
        }elseif ($brand == 3) {
            $headers .= "Cc: vm@europelocalize.com " . "\r\n".'Bcc: suhan.yilmaz@europelocalize.com'."\r\n";
            $headers .= 'From: vm@europelocalize.com '."\r\n".'Reply-To: vm@europelocalize.com'."\r\n";
        }elseif ($brand == 4) {
            $headers .= "Cc: vm@afaqtranslations.com " . "\r\n";
            $headers .= "Cc: nour.mahmoud@afaqtranslations.com" . "\r\n";
            $headers .= 'From: vm@afaqtranslations.com '."\r\n".'Reply-To: vm@afaqtranslations.com'."\r\n";
        }
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                    <p>Dear All,</p>
                       <p> A new reply has already sent to your ticket by : '.$this->admin_model->getUserData($this->user)->user_name.', please check .. </p>
                       <p> '.$msgData.' </p>
                       <p> Replay : '.$comment.' </p>
                       <p> Thanks</p>
                    </body>
                    </html>';
        mail($MailTo,$subject,$message,$headers);
    }
  
  	public function ticketAcceptanceMail($ticket,$type){
        $ticketData = $this->db->get_where('vm_ticket',array('id'=>$ticket))->row();
        $userData = $this->admin_model->getUserData($ticketData->created_by);
        $MailTo = "vm@thetranslationgate.com";
        $subject = " Closing Ticket Request : #".$ticket;
    
    	$headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        
    	if($ticketData->ticket_from == 1){
        	$pmId = $this->db->get_where('sales_opportunity',array('id'=>$ticketData->from_id))->row()->pm;
            $headers .= "Cc: ".$this->admin_model->getUserEmail($pmId). "\r\n";
            $msgData = '<p> Opportunity Number: #'.$ticketData->from_id.'</p>';
        }elseif($ticketData->ticket_from == 2){
            $msgData = '<p> Project Number: #'.$ticketData->from_id.'</p>';
        }
        
        $headers .= "Cc: ". $userData->email . "\r\n";
        $headers .= 'From: '. $userData->email ."\r\n".'Reply-To:'.$userData->email."\r\n";
        if($type == 2){$data = "declined";}
        if($type == 1){$data = "accept";}
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                    <p>Dear VM Team,</p>
                       <p> '.$userData->user_name.' '.$data.' to close your ticekt please check ..</p>
                       <p> '.$msgData.' </p>
                       <p> Thanks</p>
                    </body>
                    </html>';
        mail($MailTo,$subject,$message,$headers);
    }
  
  	public function getVendorInfo($id){
        $row = $this->db->get_where('vendor',array('id'=>$id))->row();

        $data = '<table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;">
                        <thead>
                            <tr>
                                 <th>Email</th>
                                 <th>Contact</th>
                                 <th>Country</th>
                            </tr>
                        </thead>                            
                        <tbody>
                            <tr class="">
                                <td>'.$row->email.'</td>
                                <td>'.$row->contact.'</td>
                                <td>'.$this->admin_model->getCountry($row->country).'</td>
                            </tr>
                        </tbody>
                    </table>';
        return $data;
    }
  
  	public function selectVendorType($select=""){
        if($select == 0){
            $selected1 = 'selected';
        }elseif ($select == 1) {
            $selected2 = 'selected';
        }
        else{
            $selected1 = '';
            $selected2 = '';
          }

        $outpt = '<option value="0" '.$selected1.'>Freelancer</option>
                  <option value="1" '.$selected2.'>In House</option>
                  ';
        return $outpt;
    }

    public function getVendorType($select=""){
        if($select == 0){
            $outpt = 'Freelancer';
        }elseif ($select == 1) {
            $outpt = 'In House';
        }
        else{
            $outpt = "";
        }
        return $outpt;
    }
  
  	public function getVendorTableData($id,$task_type,$rate){
        $row = $this->db->get_where('vendor_sheet',array('vendor'=>$id,'task_type'=>$task_type))->row();
        if(isset($row->rate)){
            $data = '<table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;">
                        <thead>
                            <tr>
                                 <th>Unit</th>
                                 <th>Rate</th>
                                 <th>Currency</th>
                            </tr>
                        </thead>                            
                        <tbody>
                            <tr class="">
                                <input type="text" id="unit_1" name="unit_1" value="'.$row->unit.'" hidden="">
                                <input type="text" id="currency_1" name="currency_1" value="'.$row->currency.'" hidden="">
                                <td>'.$this->admin_model->getUnit($row->unit).'</td>
                                <td><input onblur="calculateVendorCostChecked()" type="text" id="rate_1" name="rate_1" value="'.$rate.'"></td>
                                <td>'.$this->admin_model->getCurrency($row->currency).'</td>
                            </tr>
                        </tbody>
                    </table>';
            echo $data;
        }
    }
  
  	public function viewVmTicketsActivity($permission,$brand,$user,$filter=1){
        if($permission->view == 1){
            $data = $this->db->query(" SELECT v.id AS ticket,v.created_at AS request_time,v.request_type,v.service,v.task_type,v.number_of_resource,v.rate,v.source_lang,v.target_lang,v.start_date,v.due_date,
                v.delivery_date,v.count,v.unit,v.currency,v.subject,v.software,v.created_by AS requester,v.status AS ticket_status,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand,t.created_by AS vm,t.created_at AS open_time FROM `vm_ticket` AS v
                LEFT OUTER JOIN vm_ticket_time AS t ON t.id = (SELECT id FROM vm_ticket_time WHERE ticket = v.id and status = '2' LIMIT 1 )
                WHERE ".$filter." HAVING brand = '$brand' ORDER BY v.id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT v.id AS ticket,v.created_at AS request_time,v.request_type,v.service,v.task_type,v.number_of_resource,v.rate,v.source_lang,v.target_lang,v.start_date,v.due_date,
                v.delivery_date,v.count,v.unit,v.currency,v.subject,v.software,v.created_by AS requester,v.status AS ticket_status,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand,t.created_by AS vm,t.created_at AS open_time FROM `vm_ticket` AS v
                LEFT OUTER JOIN vm_ticket_time AS t ON t.id = (SELECT id FROM vm_ticket_time WHERE ticket = v.id and status = '2' LIMIT 1 )
                WHERE ".$filter." AND t.created_by = '$user' HAVING brand = '$brand' ORDER BY v.id DESC ");
        }
        return $data;
    }

    public function viewVmTicketsActivityPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT v.id AS ticket,v.created_at AS request_time,v.request_type,v.service,v.task_type,v.number_of_resource,v.rate,v.source_lang,v.target_lang,v.start_date,v.due_date,
                v.delivery_date,v.count,v.unit,v.currency,v.subject,v.software,v.created_by AS requester,v.status AS ticket_status,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand,t.created_by AS vm,t.created_at AS open_time FROM `vm_ticket` AS v
                LEFT OUTER JOIN vm_ticket_time AS t ON t.id = (SELECT id FROM vm_ticket_time WHERE ticket = v.id and status = '2' LIMIT 1 )
                HAVING brand = '$brand' ORDER BY v.id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT v.id AS ticket,v.created_at AS request_time,v.request_type,v.service,v.task_type,v.number_of_resource,v.rate,v.source_lang,v.target_lang,v.start_date,v.due_date,
                v.delivery_date,v.count,v.unit,v.currency,v.subject,v.software,v.created_by AS requester,v.status AS ticket_status,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand,t.created_by AS vm,t.created_at AS open_time FROM `vm_ticket` AS v
                LEFT OUTER JOIN vm_ticket_time AS t ON t.id = (SELECT id FROM vm_ticket_time WHERE ticket = v.id and status = '2' LIMIT 1 )
                WHERE t.created_by = '$user' HAVING brand = '$brand' ORDER BY v.id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

	public function AllVendorsCV($permission,$user,$brand,$filter)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT * FROM `vendor_cv` WHERE brand = '$brand' AND ".$filter." ORDER BY id DESC");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT * FROM `vendor_cv` WHERE brand = '$brand' AND created_by = '$user' AND ".$filter." ORDER BY id DESC");
        }
        return $data;
    }

    public function AllVendorsCVPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT * FROM `vendor_cv` WHERE brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT * FROM `vendor_cv` WHERE brand = '$brand' AND created_by = '$user' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

	public function selectVendorColor($select=""){
        if($select == 1){
            $selected1 = 'selected';
        }elseif ($select == 2) {
            $selected2 = 'selected';
        }
        else{
            $selected1 = '';
            $selected2 = '';
          }

        $outpt = '
                  <option value="1" '.$selected1.'>Red</option>
                  <option value="2" '.$selected2.'>Yellow</option>';
        return $outpt;
    }

	public function viewPmSalesTickets($permission,$brand,$filter="",$user){
        if($permission->view == 1){
            $data = $this->db->query(" SELECT s.pm,s.customer,s.project_name,t.*,(SELECT brand FROM `users` WHERE users.id = s.created_by) AS brand FROM vm_ticket AS t LEFT OUTER JOIN sales_opportunity AS s ON s.id = t.from_id WHERE t.ticket_from = 1 AND ".$filter." HAVING brand = '$brand' order by id desc ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT s.pm,s.customer,s.project_name,t.* FROM vm_ticket AS t
                LEFT OUTER JOIN sales_opportunity AS s ON s.id = t.from_id
                WHERE t.ticket_from = 1 AND ".$filter." AND s.pm = '$user' order by id desc ");
        }
        
        return $data;   
    }

    public function viewPmSalesTicketsPages($permission,$brand,$user,$limit,$offset){
        if($permission->view == 1){
            $data = $this->db->query(" SELECT s.pm,s.customer,s.project_name,t.*,(SELECT brand FROM `users` WHERE users.id = s.created_by) AS brand FROM vm_ticket AS t LEFT OUTER JOIN sales_opportunity AS s ON s.id = t.from_id WHERE t.ticket_from = 1 HAVING brand = '$brand' order by id desc LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT s.pm,s.customer,s.project_name,t.* FROM vm_ticket AS t
                LEFT OUTER JOIN sales_opportunity AS s ON s.id = t.from_id
                WHERE t.ticket_from = 1 AND s.pm = '$user' order by id desc LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

     public function validateEmail($email="",$brand)
    {
        
        if($this->db->query("SELECT * FROM  vendor WHERE email LIKE '%$email%' AND brand = '$brand' ")->num_rows() > 0 ){
            $data = "1";
        }else{
             $data = "0";
        }
        return $data;
    }

    public function validateEmailEdit($email,$id,$brand)
        {
            //$d1= $this->db->query("SELECT * FROM  vendor WHERE email = '$email' AND id = '$id' ")->num_rows();
            $d1= $this->db->query("SELECT * FROM  vendor WHERE email LIKE '%$email%' AND id != '$id' AND brand = '$brand' ")->num_rows() ;
            if($d1 >= 1){
                $data = "1";
            }else{
                $data="0";
            }
           /* if($d2 > 0 ){
                 $data = "2";
            }*/
            return $data;
        }

	public function changeTicketToClose(){
        $ticket = $this->db->query("SELECT * FROM vm_ticket WHERE status = '5'");
        foreach($ticket->result() as $row){
            $statusRow = $this->db->query("SELECT * FROM vm_ticket_time WHERE ticket = '$row->id' AND status = '5' ORDER BY id DESC LIMIT 1")->row();
            $lastDate =strtotime($statusRow->created_at);
            $currentDate = strtotime("now");
            $days = abs($lastDate - $currentDate)/60/60/24;
            //update status
            if($days >= 3){
                $data['status'] = 4;
                if($this->db->update('vm_ticket',$data,array('id'=>$row->id))){
                    $this->addTicketTimeStatus($row->id,0,4); }
            }
        }
    }

	public function selectVendorStatus($select=""){
        if($select == 0){
            $selected1 = 'selected';
        }elseif ($select == 1) {
            $selected2 = 'selected';
        }
        else{
            $selected1 = '';
            $selected2 = '';
          }

        $outpt = '<option value="0" '.$selected1.'>Active</option>
                  <option value="1" '.$selected2.'>Deactive</option>';
        return $outpt;
    }

    public function getVendorStatus($select=""){
        if($select == 0){
            $outpt = 'Active';
        }elseif ($select == 1) {
            $outpt = 'Deactive';
        }
        else{
            $outpt = "";
        }
        return $outpt;
    }


    public function selectVmEmployeeId($id="",$brand=""){
        $vm = $this->db->query(" SELECT * FROM users WHERE (role = '11' OR role = '32') AND brand = '$this->brand' AND status = '1' ")->result();
        foreach ($vm as $vm) {
            if ($vm->id == $id) {
                $data .= "<option value='" . $vm->employees_id . "' selected='selected'>" . $vm->user_name . "</option>";
            } else {
                $data .= "<option value='" . $vm->employees_id . "'>" . $vm->user_name . "</option>";
            }
        }
        return $data;
    }


    //tickets with issue
    public function viewVmTicketsWithIssues($role,$user,$brand,$filter=""){
        if($filter){
                if($role == 32) {
                     $data = $this->db->query(" SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM `vm_ticket` AS v WHERE issue_status = 1 AND ".$filter." HAVING brand = '$brand' order by id desc");
                 }else{
                     $data = $this->db->query(" SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM `vm_ticket` AS v WHERE issue_status = 1 AND v.issue_by = '$user' AND ".$filter." HAVING brand = '$brand' order by id desc");
                 }
              
        }else{ 
            if($role == 32) {
                $data = $this->db->query(" SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM `vm_ticket` AS v WHERE issue_status = 1 HAVING brand = '$brand' order by id desc");
            }else{
                $data = $this->db->query(" SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM `vm_ticket` AS v WHERE issue_status = 1 AND v.issue_by = '$user' HAVING brand = '$brand' order by id desc");
            }
           
        }
        return $data;   
    }
public function viewVmTicketsWithIssuesPages($role,$user,$brand,$limit,$offset){
      if($role == 32){
        $data = $this->db->query("SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM vm_ticket AS v WHERE issue_status = 1 HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
       }else{
        $data = $this->db->query("SELECT v.*,(SELECT brand FROM `users` WHERE users.id = v.created_by) AS brand FROM vm_ticket AS v WHERE issue_status = 1 AND v.issue_by = '$user' HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
       }
        
        return $data;
    }
    //
        public function AllCompanies($brand,$filter)

    {

        $data = $this->db->query(" SELECT * FROM `companies` WHERE ".$filter." AND brand = '$brand' ORDER BY id ASC , id DESC ");
        return $data;
    }

    public function AllCompaniesPages($brand,$limit,$offset)
    {
        $data = $this->db->query("SELECT * FROM `companies` WHERE brand = '$brand' ORDER BY id ASC , id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }   
    public function AllFavouriteVendor($permission,$user,$brand,$filter)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT v.*,s.source_lang,s.target_lang,s.dialect,s.service,s.task_type,s.rate,s.special_rate,s.unit,s.currency,s.created_at AS sheetCreatedAt,s.created_by AS sheetCreatedBy,s.id AS sheetId FROM `vendor` AS v LEFT OUTER JOIN vendor_sheet AS s ON v.id = s.vendor 
                 WHERE brand = '$brand' AND ".$filter." HAVING favourite = '1' ORDER BY id DESC");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT v.*,s.source_lang,s.target_lang,s.dialect,s.service,s.task_type,s.rate,s.special_rate,s.unit,s.currency,s.created_at AS sheetCreatedAt,s.created_by AS sheetCreatedBy,s.id AS sheetId FROM `vendor` AS v LEFT OUTER JOIN vendor_sheet AS s ON v.id = s.vendor 
                 WHERE brand = '$brand' AND created_by = '$user' AND ".$filter." HAVING favourite = '1' ORDER BY id DESC");
        }
        return $data;
    }

    public function AllFavouriteVendorPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT * FROM `vendor` WHERE brand = '$brand' HAVING favourite = '1' ORDER BY id DESC LIMIT $limit OFFSET $offset  ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT * FROM `vendor` WHERE brand = '$brand' AND created_by = '$user' HAVING favourite = '1' ORDER BY id DESC LIMIT $limit OFFSET $offset  ");
        }
        return $data;
    }

    }
    
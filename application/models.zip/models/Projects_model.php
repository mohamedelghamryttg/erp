<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Auth
*
* Author:  MOHAMED EL-SHEHABY
*
*/

class Projects_model extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function AllProjects($permission,$user,$brand,$filter,$having=1)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand,(SELECT IF ((SELECT count(*) from job where project_id = p.id) = (SELECT count(*) from job where project_id = p.id AND status = '1'), 1, 0)) AS closed FROM `project` AS p WHERE ".$filter." HAVING brand = '$brand' AND ".$having." ORDER BY id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand,(SELECT IF ((SELECT count(*) from job where project_id = p.id) = (SELECT count(*) from job where project_id = p.id AND status = '1'), 1, 0)) AS closed FROM `project` AS p WHERE ".$filter." AND created_by = '$user' HAVING brand = '$brand' AND ".$having." ORDER BY id DESC ");

        }
        return $data;
    }

    public function AllProjectsPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `project` AS p HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `project` AS p WHERE created_by = '$user' HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

	public function AllProjectsCount($permission,$user,$brand,$filter)
    {

        if($permission->view == 1){
            $data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `project` AS p WHERE ".$filter." HAVING brand = '$brand' ORDER BY id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `project` AS p WHERE ".$filter." AND created_by = '$user' HAVING brand = '$brand' ORDER BY id DESC ");
        }
        return $data;
    }

	public function OpportunitiesByPm($permission,$pm,$brand){
		if($permission->view == 1){
			$data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `sales_opportunity` AS p WHERE p.assigned = '1' AND p.saved = '0' HAVING brand = '$brand' ");
		}elseif($permission->view == 2){
			$data = $this->db->query("SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand,(SELECT COUNT(*) FROM customer_pm WHERE customer_pm.lead = p.lead AND customer_pm.pm = '$pm') AS total FROM `sales_opportunity` AS p WHERE p.assigned = '1' AND p.saved = '0' HAVING total > 0 AND brand = '$brand' ");
		}	
		return $data;
	}

	public function generateProjectCode($lead,$pm){
        $leadRow = $this->db->get_where('customer_leads',array('id'=>$lead))->row();
        $customer = $this->db->get_where('customer',array('id'=>$leadRow->customer))->row();
        $id = $this->db->query(" show table status where name='project' ")->row();
        $projectCode = $this->sales_model->getUserAbbreviations($pm).'-'.$id->Auto_increment.'-'.$this->sales_model->getRegionAbbreviations($leadRow->region).'-'.$this->sales_model->getBrandAbbreviations($customer->brand);
        return $projectCode;
    }

    public function updateProjectCode($lead,$id,$pm){
        $leadRow = $this->db->get_where('customer_leads',array('id'=>$lead))->row();
        $customer = $this->db->get_where('customer',array('id'=>$leadRow->customer))->row();
        $projectCode = $this->sales_model->getUserAbbreviations($pm).'-'.$id.'-'.$this->sales_model->getRegionAbbreviations($leadRow->region).'-'.$this->sales_model->getBrandAbbreviations($customer->brand);
        return $projectCode;
    }
  
  	public function projectJobs($permission,$user,$id)
    {
    	if($permission->view == 1){
			$data = $this->db->get_where('job',array('project_id'=>$id));
		}elseif($permission->view == 2){
			$data = $this->db->get_where('job',array('project_id'=>$id,'created_by'=>$user));
		}	
		return $data;
    }
  
  	public function generateJobCode($projectId,$priceList){
        $projectCode = $this->db->get_where('project',array('id'=>$projectId))->row()->code;
        $service = $this->db->get_where('customer_price_list',array('id'=>$priceList))->row()->service;
        $id = $this->db->query(" show table status where name='job' ")->row();
        $jobCode = $projectCode.'-'.$id->Auto_increment.'-'.$this->sales_model->getServiceAbbreviations($service);
        return $jobCode;
    }

    public function updateJobCode($projectId,$priceList,$id){
        $projectCode = $this->db->get_where('project',array('id'=>$projectId))->row()->code;
        $service = $this->db->get_where('customer_price_list',array('id'=>$priceList))->row()->service;
        $jobCode = $projectCode.'-'.$id.'-'.$this->sales_model->getServiceAbbreviations($service);
        return $jobCode;
    }
  
  	public function generateTaskCode($taskId){
        $taskCode = $this->db->get_where('job',array('id'=>$taskId))->row()->code;
        $id = $this->db->query(" show table status where name='job_task' ")->row();
        $jobCode = $taskCode.'-'.$id->Auto_increment;
        return $jobCode;
    }

    public function updateTaskCode($taskId,$id){
        $taskCode = $this->db->get_where('job',array('id'=>$taskId))->row()->code;
        $jobCode = $taskCode.'-'.$id;
        return $jobCode;
    }
  
  	public function getProjectData($id)
    {
        $result = $this->db->get_where('project',array('id'=>$id))->row();
        return $result;
    }
  
  	public function getJobData($id)
    {
        $result = $this->db->get_where('job',array('id'=>$id))->row();
        return $result;
    }
  
  	public function getTaskData($id)
    {
        $result = $this->db->get_where('job_task',array('id'=>$id))->row();
        return $result;
    }
  
  	public function jobTasks($permission,$user,$id)
    {
        if($permission->view == 1){
            $data = $this->db->get_where('job_task',array('job_id'=>$id));
        }elseif($permission->view == 2){
            $data = $this->db->get_where('job_task',array('job_id'=>$id,'created_by'=>$user));
        }   
        return $data;
    }
  	
  	public function getJobPriceListData($id){
        $row = $this->db->get_where('job_price_list',array('id'=>$id))->row();
        return $row;
    }
  
  	public function sendVendorTaskMail($id,$user,$brand){
        $row = Self::getTaskData($id);
        $job = Self::getJobData($row->job_id);
        $jobPrice = Self::getJobPriceListData($job->price_list);
        $pmMail = $this->admin_model->getUserEmail($user);
        
        $vendor = $this->vendor_model->getVendorData($row->vendor);
        $mailTo = $vendor->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
      	$subject = "New Vendor Task : ".$row->subject;


         $config = Array(
        'protocol' => 'smtp',
        'smtp_host' => 'mail.thetranslationgate.com',
        'smtp_port' => 465,
        'smtp_user' => 'falaqsystem@thetranslationgate.com',
        'smtp_pass' => 'GaU6FjtJ$*Hb8P-j',
        'charset'=>'utf-8',
         'validate'=>TRUE,
        'wordwrap'=> TRUE,
      );
      $this->load->library('email', $config);
      $this->email->set_newline("\r\n");
      $this->email->from($pmMail);
      // replace my mail by pm manger it is just for testing
      $this->email->to($mailTo);
      if($brand == 1){
        $this->email->cc($pmMail.', vm@thetranslationgate.com');
      }elseif ($brand == 2) {
        $this->email->cc($pmMail.', shehab.hussein@dtpzone.com, vm@dtpzone.com');
      }elseif ($brand == 3) {
        $this->email->cc($pmMail.', vm@europelocalize.com');
      }
      $this->email->subject($subject);
      // $msg = $this->load->view('admin/mail','',TRUE);
      if(strlen($row->file) > 1){
            $file = '<a href="'.base_url().'assets/uploads/taskFile/'.$row->file.'" target="_blank">Click Here ..</a>'; 
        }
      $this->email->message('<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <meta name="description" content="">
                    <meta name="author" content="">
                    <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                    <title>Falaq| Site Manager</title>
                    <style>
                    body {
                        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                        font-size: 14px;
                        line-height: 1.428571429;
                        color: #333;
                    }
                    section#unseen
                    {
                        overflow: scroll;
                        width: 100%
                    }
                    </style>
                    <!--Core js-->
                </head>

                <body>
                <div class="panel-body">
                                <div class="adv-table editable-table ">
                                    <div class="clearfix">
                                        <div class="btn-group">
                                            <span class=" btn-primary" style="">
                                            </span>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="space15"></div>
                                    
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                            <tr>
                                                 <td colspan=2 style="background-color: #ddd;">Task Data</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Task Code</td>
                                                 <td style="background-color:#ddd;">'.$row->code.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Task Type</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getTaskType($row->task_type).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Service</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getServices($this->admin_model->getTaskTypeParent($row->task_type)).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Vendor</td>
                                                 <td style="background-color:#ddd;">'.$this->vendor_model->getVendorName($row->vendor).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Source</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getLanguage($jobPrice->source).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Target</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getLanguage($jobPrice->target).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Count</td>
                                                 <td style="background-color:#ddd;">'.$row->count.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Unit</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getUnit($row->unit).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Rate</td>
                                                 <td style="background-color:#ddd;">'.$row->rate.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Total Cost</td>
                                                 <td style="background-color:#ddd;">'.$row->rate * $row->count.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Currency</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getCurrency($row->currency).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Task File</td>
                                                 <td style="background-color:#ddd;">'.$file.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Instructions</td>
                                                 <td style="background-color:#ddd;">'.$row->insrtuctions.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Start Date</td>
                                                 <td style="background-color:#ddd;">'.$row->start_date.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Delivery Date</td>
                                                 <td style="background-color:#ddd;">'.$row->delivery_date.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Time Zone</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getTimeZone($row->time_zone).'</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                          </div>
                </body>
                </html>');
      $this->email->set_header('Reply-To', $pmMail);
      $this->email->set_mailtype('html');
      $this->email->send();
    }
  
  	public function sendVendorUpdateTaskMail($id,$user,$brand){
        $row = Self::getTaskData($id);
        $job = Self::getJobData($row->job_id);
        $jobPrice = Self::getJobPriceListData($job->price_list);
        $pmMail = $this->admin_model->getUserEmail($user);
        
        $vendor = $this->vendor_model->getVendorData($row->vendor);
        $mailTo = $vendor->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        $subject = "Updated Vendor Task : ".$row->subject;
        
        $config = Array(
        'protocol' => 'smtp',
        'smtp_host' => 'mail.thetranslationgate.com',
        'smtp_port' => 465,
        'smtp_user' => 'falaqsystem@thetranslationgate.com',
        'smtp_pass' => 'GaU6FjtJ$*Hb8P-j',
        'charset'=>'utf-8',
         'validate'=>TRUE,
        'wordwrap'=> TRUE,
      );
      $this->load->library('email', $config);
      $this->email->set_newline("\r\n");
      $this->email->from($pmMail);
      // replace my mail by pm manger it is just for testing
      $this->email->to($mailTo);
      if($brand == 1){
        $this->email->cc($pmMail.', vm@thetranslationgate.com');
      }elseif ($brand == 2) {
        $this->email->cc($pmMail.', shehab.hussein@dtpzone.com, vm@dtpzone.com');
      }elseif ($brand == 3) {
        $this->email->cc($pmMail.', vm@europelocalize.com');
      }
      $this->email->subject($subject);
        
        if(strlen($row->file) > 1){
            $file = '<a href="'.base_url().'assets/uploads/taskFile/'.$row->file.'" target="_blank">Click Here ..</a>'; 
        }
      
        $msg = '<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <meta name="description" content="">
                    <meta name="author" content="">
                    <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                    <title>Falaq| Site Manager</title>
                    <style>
                    body {
                        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                        font-size: 14px;
                        line-height: 1.428571429;
                        color: #333;
                    }
                    section#unseen
                    {
                        overflow: scroll;
                        width: 100%
                    }
                    </style>
                    <!--Core js-->
                </head>

                <body>
                <div class="panel-body">
                                <div class="adv-table editable-table ">
                                    <div class="clearfix">
                                        <div class="btn-group">
                                            <span class=" btn-primary" style="">
                                            </span>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="space15"></div>
                                    
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                            <tr>
                                                 <td colspan=2 style="background-color: #ddd;">Task Data</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Task Code</td>
                                                 <td style="background-color:#ddd;">'.$row->code.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Task Type</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getTaskType($row->task_type).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Service</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getServices($this->admin_model->getTaskTypeParent($row->task_type)).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Vendor</td>
                                                 <td style="background-color:#ddd;">'.$this->vendor_model->getVendorName($row->vendor).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Source</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getLanguage($jobPrice->source).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Target</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getLanguage($jobPrice->target).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Count</td>
                                                 <td style="background-color:#ddd;">'.$row->count.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Unit</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getUnit($row->unit).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Rate</td>
                                                 <td style="background-color:#ddd;">'.$row->rate.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Total Cost</td>
                                                 <td style="background-color:#ddd;">'.$row->rate * $row->count.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Currency</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getCurrency($row->currency).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Task File</td>
                                                 <td style="background-color:#ddd;">'.$file.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Instructions</td>
                                                 <td style="background-color:#ddd;">'.$row->insrtuctions.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Start Date</td>
                                                 <td style="background-color:#ddd;">'.$row->start_date.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Delivery Date</td>
                                                 <td style="background-color:#ddd;">'.$row->delivery_date.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Time Zone</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getTimeZone($row->time_zone).'</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                          </div>
                </body>
                </html>';
            //echo $msg;
      $this->email->message($msg);
      $this->email->set_header('Reply-To', $pmMail);
      $this->email->set_mailtype('html');
      $this->email->send();
    }
  
  	public function sendVPOMail($id,$user,$brand){
        $row = Self::getTaskData($id);    
        $job = Self::getJobData($row->job_id);
        $jobPrice = Self::getJobPriceListData($job->price_list);
        $pmMail = $this->admin_model->getUserEmail($user);
        
        $vendor = $this->vendor_model->getVendorData($row->vendor);
        $mailTo = $vendor->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        $subject = "Vendor VPO : ".$row->subject;
        
        $config = Array(
        'protocol' => 'smtp',
        'smtp_host' => 'mail.thetranslationgate.com',
        'smtp_port' => 465,
        'smtp_user' => 'falaqsystem@thetranslationgate.com',
        'smtp_pass' => 'GaU6FjtJ$*Hb8P-j',
        'charset'=>'utf-8',
         'validate'=>TRUE,
        'wordwrap'=> TRUE,
      );

      $this->load->library('email', $config);
      $this->email->set_newline("\r\n");
      $this->email->from($pmMail);
      // replace my mail by pm manger it is just for testing
      $this->email->to($mailTo);
      $this->email->subject($subject);

        if($brand == 1){
            $this->email->cc($pmMail.', vm@thetranslationgate.com, accountspayable@thetranslationgate.com');
            $msg = '<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <meta name="description" content="">
                    <meta name="author" content="">
                    <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                    <title>Falaq| Site Manager</title>
                    <style>
                    body {
                        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                        font-size: 14px;
                        line-height: 1.428571429;
                        color: #333;
                    }
                    section#unseen
                    {
                        overflow: scroll;
                        width: 100%
                    }
                    </style>
                    <!--Core js-->
                </head>

                <body>
                <div class="panel-body">
                                <div class="adv-table editable-table ">
                                    <div class="clearfix">
                                        <div class="btn-group">
                                            <span class=" btn-primary" style="">
                                            </span>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="space15"></div>
                                    
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                            <tr>
                                                 <td style="font-size:bold;"><img src="'.base_url().'assets/images/logo_ar.png" alt="" style="width:50%;"></td>
                                                 <td><p>3A Almashtal st, Taksim Elshishiny Corniche El-Nil,</p><p>Maadi, Cairo 11511 - EGYPT </p> Tel: +202 2528 1190 </p><p> Fax: +202 2528 3816 info@thetranslationgate.com </p> <p>www.thetranslationgate.com<p></td>
                                            </tr>
                                            <tr>
                                            Click Here to Download Your PO File <a href="'.base_url().'po/download?t='.base64_encode($row->id).'" target="_blank">Click Here ..</a>
                                            </tr>
                                            <tr>
                                                 <td colspan=2 style="background-color: #ffff06;color:#ff0606;text-align:left;font-size:18px;">
                                                    <p>Dear our valued Vendor, please take into consideration the below conditions:</p>
                                                    <p>• Payments will be processed within 45 to 60 days from date of receiving your invoice by 
                                                    accountspayable@thetranslationgate.com.</p>
                                                    <p>• Once you submit your work to our PM, please send your invoice along with the PO number received
                                                    from our PM via email to accountspayable@thetranslationgate.com.</p>
                                                    <p>• The company is not responsible for any payment delay due to sending the invoice to the incorrect 
                                                    contact/person, The invoice must be sent to: accountspayable@thetranslationgate.com.</p>
                                                    <p>• If any delay from your side to send your invoice once you finished the work, so it is not the company'."'".'s 
                                                    responsibility, and the normal duration paymnet will be applied "45 to 60 days from date of receiving your late invoice".</p> 
                                                    <p>• PLEASE DO NOT SEND your invoice to the Project/Vendor Manager. Invoices MUST ONLY be sent to accountspayable@thetranslationgate.com, if you wish you can keep the PM cced. </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                           <tr>
                                            <td colspan=2 style="background-color: #622422;color: white;">PO</td>
                                            <td colspan=2 style="background-color:#fc6;color: black;">'.$row->code.'</td>
                                           </tr>
                                           <tr>
                                            <td style="background-color: #622422;color: white;">Project Manager</td>
                                            <td style="background-color:#fc6;color: black;">'.$this->admin_model->getAdmin($user).'</td>
                                            <td style="background-color: #622422;color: white;">PO Date</td>
                                            <td style="background-color:#fc6;color: black;">'.$row->delivery_date.'</td>
                                           </tr>
                                           <tr>
                                            <td style="background-color: #622422;color: white;">Service</td>
                                            <td style="background-color:#fc6;color: black;">'.$this->admin_model->getServices($jobPrice->service).'</td>
                                            <td style="background-color: #622422;color: white;">Vendor Name</td>
                                            <td style="background-color:#fc6;color: black;">'.$this->vendor_model->getVendorName($row->vendor).'</td>
                                           </tr>
                                           <tr>
                                           <td style="background-color: #622422;color: white;">Source</td>
                                            <td style="background-color:#fc6;color: black;">'.$this->admin_model->getLanguage($jobPrice->source).'</td>
                                            <td style="background-color: #622422;color: white;">Vendor Email</td>
                                            <td style="background-color:#fc6;color: black;">'.$this->vendor_model->getVendorData($row->vendor)->email.'</td>
                                           </tr>
                                           <tr>
                                           <td style="background-color: #622422;color: white;">Target</td>
                                            <td style="background-color:#fc6;color: black;">'.$this->admin_model->getLanguage($jobPrice->target).'</td>
                                            <td style="background-color: #622422;color: white;">Contact Person</td>
                                            <td style="background-color:#fc6;color: black;"></td>
                                           </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                           <tr>
                                            <td style="background-color: #622422;color: white;">Task Name</td>
                                            <td style="background-color: #622422;color: white;">Volume</td>
                                            <td style="background-color: #622422;color: white;">Unit</td>
                                            <td style="background-color: #622422;color: white;">Rate</td>
                                            <td style="background-color: #622422;color: white;">Price</td>
                                           </tr>
                                           <tr>
                                            <td style="background-color: #fc6;color: black;">'.$row->subject.'</td>
                                            <td style="background-color: #fc6;color: black;">'.$row->count.'</td>
                                            <td style="background-color:#fc6;color: black;">'.$this->admin_model->getUnit($row->unit).'</td>
                                            <td style="background-color: #fc6;color: black;">'.$row->rate.'</td>
                                            <td style="background-color: #fc6;color: black;">'.$row->count*$row->rate.'</td>
                                           </tr>
                                           <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td style="background-color: #fc6;color: black;">Total</td>
                                            <td style="background-color: #fc6;color: black;">'.$row->count*$row->rate.'</td>
                                           </tr>
                                           <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td style="background-color:#fc6;color: black;">'.$this->admin_model->getCurrency($row->currency).'</td>
                                           </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;font-size:18px;">
                                        <tbody>
                                            <tr>
                                                 <td colspan=2 style="background-color: #ffff06;color:black;text-align:left;">
                                                 <p style="color:red;font-weight: bold;text-decoration: underline;">Terms & Conditions:</p> 
                                                <p>• Vendors must Include "The Translation Gate" PO Number in their invoices. </p>
                                                <p>• Payment transfer fees will be divided 50-50 between the company and the vendor.</p>
                                                <p>• Your invoice should include the payment methods with full and correct details, and "The Translation Gate" is not responsible for 
                                                any payment delays caused by incorrect details that the Vendor submits on the payment invoices.  
                                                <p>• We use Money Bookers or PayPal  for the amounts less than 300 USD, Western union for the amounts from 300 to 700 USD or 
                                                Bank transfers for the amounts more than 700 USD.</p>
                                                <p>• Any change or editing in the PO content should be made only through the direct PM, otherwise the PO will be cancelled. 
                                                <p>• Failure to comply with job instructions will be penalized by sufficient deductions and could lead to cancel the whole PO.</p>
                                                <p>• Deadline extensions can ONLY be requested 12 hours before the job.'."'".'s deadline and will be reviewed if applicable, and failure to meet the deadlines requested in this PO will be penalized by sufficient deductions and could lead to cancel the whole PO.</p>
                                                <p>• If the service quality is below the accepted standards, deductions or job cancellation might be applied.</p>
                                                <p>• This PO will be considered "cancelled", if our PM did not receive an email confirmation of accepting the job, and indicating fully 
                                                understanding of the job.'."'".'s instructions, and accepting the delivery deadline.</p>
                                                <p>• Payments expire after 1 year from task delivery dates.</p>
                                                 </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                          </div>
                </body>
                </html>';
            }else if($brand == 3){
                $this->email->cc($pmMail.', vm@europelocalize.com');
                $headers .= "Cc: 'vm@europelocalize.com" . "\r\n";
                $msg = '<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <meta name="description" content="">
                    <meta name="author" content="">
                    <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                    <title>Falaq| Site Manager</title>
                    <style>
                    body {
                        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                        font-size: 14px;
                        line-height: 1.428571429;
                        color: #333;
                    }
                    section#unseen
                    {
                        overflow: scroll;
                        width: 100%
                    }
                    </style>
                    <!--Core js-->
                </head>

                <body>
                <div class="panel-body">
                                <div class="adv-table editable-table ">
                                    <div class="clearfix">
                                        <div class="btn-group">
                                            <span class=" btn-primary" style="">
                                            </span>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="space15"></div>
                                    
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                            <tr>
                                                 <td style="font-size:bold;"><img src="'.base_url().'assets/images/europe.png" alt="" style="width:50%;"></td>
                                                 <td><p>Ul. Borowej Góry 6/64, 01-354 Warsaw, Poland</p><p>Tel: + 48 (22) 163 42 63</p></td>
                                            </tr>
                                            <tr>
                                            Click Here to Download Your PO File <a href="'.base_url().'po/download?t='.base64_encode($row->id).'" target="_blank">Click Here ..</a>
                                            </tr>
                                            <tr>
                                                 <td colspan=2 style="background-color: #06b8e8;color:#d306e8;text-align:left;">
                                                 <p style="color:red;font-weight: bold;text-decoration: underline;">Terms & Conditions:</p> 
                                                <p>• Vendors must Include "Europe Localize" PO Number in their invoices. </p>
                                                <p>• Payment transfer fees will be divided 50-50 between the company and the vendor.</p>
                                                <p>• Your invoice should include the payment methods with full and correct details, and "Europe Localize" is not responsible for 
                                                any payment delays caused by incorrect details that the Vendor submits on the payment invoices.  
                                                <p>• We use Money Bookers or PayPal  for the amounts less than 300 USD, Western union for the amounts from 300 to 700 USD or 
                                                Bank transfers for the amounts more than 700 USD.</p>
                                                <p>• Any change or editing in the PO content should be made only through the direct PM, otherwise the PO will be cancelled. 
                                                <p>• Failure to comply with job instructions will be penalized by sufficient deductions and could lead to cancel the whole PO.</p>
                                                <p>• Deadline extensions can ONLY be requested 12 hours before the job.'."'".'s deadline and will be reviewed if applicable, and failure to meet the deadlines requested in this PO will be penalized by sufficient deductions and could lead to cancel the whole PO.</p>
                                                <p>• If the service quality is below the accepted standards, deductions or job cancellation might be applied.</p>
                                                <p>• This PO will be considered "cancelled", if our PM did not receive an email confirmation of accepting the job, and indicating fully 
                                                understanding of the job.'."'".'s instructions, and accepting the delivery deadline.</p>
                                                <p>• Payments expire after 1 year from task delivery dates.</p>
                                                 </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                           <tr>
                                            <td colspan=2 style="color: #d306e8;">PO</td>
                                            <td colspan=2 style="color: black;">'.$row->code.'</td>
                                           </tr>
                                           <tr>
                                            <td style="color: #d306e8;">Project Manager</td>
                                            <td style="color: black;">'.$this->admin_model->getAdmin($user).'</td>
                                            <td style="color: #d306e8;">PO Date</td>
                                            <td style="color: black;">'.$row->delivery_date.'</td>
                                           </tr>
                                           <tr>
                                            <td style="color: #d306e8;">Service</td>
                                            <td style="color: black;">'.$this->admin_model->getServices($jobPrice->service).'</td>
                                            <td style="color: #d306e8;">Vendor Name</td>
                                            <td style="color: black;">'.$this->vendor_model->getVendorName($row->vendor).'</td>
                                           </tr>
                                           <tr>
                                           <td style="color: #d306e8;">Source</td>
                                            <td style="color: black;">'.$this->admin_model->getLanguage($jobPrice->source).'</td>
                                            <td style="color: #d306e8;">Vendor Email</td>
                                            <td style="color: black;">'.$this->vendor_model->getVendorData($row->vendor)->email.'</td>
                                           </tr>
                                           <tr>
                                           <td style="color: #d306e8;">Target</td>
                                            <td style="color: black;">'.$this->admin_model->getLanguage($jobPrice->target).'</td>
                                            <td style="color: #d306e8;">Contact Person</td>
                                            <td style="color: black;"></td>
                                           </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                           <tr>
                                            <td style="color: #d306e8;">Task Name</td>
                                            <td style="color: #d306e8;">Volume</td>
                                            <td style="color: #d306e8;">Unit</td>
                                            <td style="color: #d306e8;">Rate</td>
                                            <td style="color: #d306e8;">Price</td>
                                           </tr>
                                           <tr>
                                            <td style="color: black;">'.$row->subject.'</td>
                                            <td style="color: black;">'.$row->count.'</td>
                                            <td style="color: black;">'.$this->admin_model->getUnit($row->unit).'</td>
                                            <td style="color: black;">'.$row->rate.'</td>
                                            <td style="color: black;">'.$row->count*$row->rate.'</td>
                                           </tr>
                                           <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td style="color: black;">Total</td>
                                            <td style="color: black;">'.$row->count*$row->rate.'</td>
                                           </tr>
                                           <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td style="color: black;">'.$this->admin_model->getCurrency($row->currency).'</td>
                                           </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;font-size:18px;">
                                        <tbody>
                                            <tr>
                                                 <td colspan=2 style="background-color: #06b8e8;color:#d306e8;text-align:left;">
                                                    <p>Dear our valued Vendor, please take into consideration the below conditions:</p>
                                                    <p>• Payments will be processed within 45 to 60 days from date of receiving your invoice by 
                                                     belgin.cemil@europelocalize.com.</p>
                                                    <p>• Once you submit your work to our PM, please send your invoice along with the PO number received
                                                    from our PM via email to  belgin.cemil@europelocalize.com.</p>
                                                    <p>• The company is not responsible for any payment delay due to sending the invoice to the incorrect 
                                                    contact/person, The invoice must be sent to:  belgin.cemil@europelocalize.com.</p>
                                                    <p>• If any delay from your side to send your invoice once you finished the work, so it is not the company'."'".'s 
                                                    responsibility, and the normal duration paymnet will be applied "45 to 60 days from date of receiving your late invoice".</p> 
                                                    <p>• PLEASE DO NOT SEND your invoice to the Project/Vendor Manager. Invoices MUST ONLY be sent to  belgin.cemil@europelocalize.com, if you wish you can keep the PM cced. </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                          </div>
                </body>
                </html>';
            }else if($brand == 2){
                $this->email->cc($pmMail.', shehab.hussein@dtpzone.com, vm@dtpzone.com');
                $msg = '<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <meta name="description" content="">
                    <meta name="author" content="">
                    <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                    <title>Falaq| Site Manager</title>
                    <style>
                    body {
                        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                        font-size: 14px;
                        line-height: 1.428571429;
                        color: #333;
                    }
                    section#unseen
                    {
                        overflow: scroll;
                        width: 100%
                    }
                    </style>
                    <!--Core js-->
                </head>

                <body>
                <div class="panel-body">
                                <div class="adv-table editable-table ">
                                    <div class="clearfix">
                                        <div class="btn-group">
                                            <span class=" btn-primary" style="">
                                            </span>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="space15"></div>
                                    
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                            <tr>
                                                 <td style="font-size:bold;"><img src="'.base_url().'assets/images/dtp_zone.png" alt="" style="width:50%;"></td>
                                                 <td><p>3 Saad Zallam St. El Maddi – Cairo – Egypt.</p><p>Mobile: +2 01020666959</p><p>Phone: +2 02 25276200</p><p>Fax: +2 02 25283816</p></td>
                                            </tr>
                                            <tr>
                                            Click Here to Download Your PO File <a href="'.base_url().'po/download?t='.base64_encode($row->id).'" target="_blank">Click Here ..</a>
                                            </tr>
                                            <tr>
                                                 <td colspan=2 style="background-color: #06b8e8;color:#d306e8;text-align:left;">
                                                 <p style="color:red;font-weight: bold;text-decoration: underline;">Terms & Conditions:</p> 
                                                <p>• Vendors must Include "DTP Zone" PO Number in their invoices. </p>
                                                <p>• Payment transfer fees will be divided 50-50 between the company and the vendor.</p>
                                                <p>• Your invoice should include the payment methods with full and correct details, and "DTP Zone" is not responsible for 
                                                any payment delays caused by incorrect details that the Vendor submits on the payment invoices.  
                                                <p>• We use Money Bookers or PayPal  for the amounts less than 300 USD, Western union for the amounts from 300 to 700 USD or 
                                                Bank transfers for the amounts more than 700 USD.</p>
                                                <p>• Any change or editing in the PO content should be made only through the direct PM, otherwise the PO will be cancelled. 
                                                <p>• Failure to comply with job instructions will be penalized by sufficient deductions and could lead to cancel the whole PO.</p>
                                                <p>• Deadline extensions can ONLY be requested 12 hours before the job.'."'".'s deadline and will be reviewed if applicable, and failure to meet the deadlines requested in this PO will be penalized by sufficient deductions and could lead to cancel the whole PO.</p>
                                                <p>• If the service quality is below the accepted standards, deductions or job cancellation might be applied.</p>
                                                <p>• This PO will be considered "cancelled", if our PM did not receive an email confirmation of accepting the job, and indicating fully 
                                                understanding of the job.'."'".'s instructions, and accepting the delivery deadline.</p>
                                                <p>• Payments expire after 1 year from task delivery dates.</p>
                                                 </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                           <tr>
                                            <td colspan=2 style="color: #d306e8;">PO</td>
                                            <td colspan=2 style="color: black;">'.$row->code.'</td>
                                           </tr>
                                           <tr>
                                            <td style="color: #d306e8;">Project Manager</td>
                                            <td style="color: black;">'.$this->admin_model->getAdmin($user).'</td>
                                            <td style="color: #d306e8;">PO Date</td>
                                            <td style="color: black;">'.$row->delivery_date.'</td>
                                           </tr>
                                           <tr>
                                            <td style="color: #d306e8;">Service</td>
                                            <td style="color: black;">'.$this->admin_model->getServices($jobPrice->service).'</td>
                                            <td style="color: #d306e8;">Vendor Name</td>
                                            <td style="color: black;">'.$this->vendor_model->getVendorName($row->vendor).'</td>
                                           </tr>
                                           <tr>
                                           <td style="color: #d306e8;">Source</td>
                                            <td style="color: black;">'.$this->admin_model->getLanguage($jobPrice->source).'</td>
                                            <td style="color: #d306e8;">Vendor Email</td>
                                            <td style="color: black;">'.$this->vendor_model->getVendorData($row->vendor)->email.'</td>
                                           </tr>
                                           <tr>
                                           <td style="color: #d306e8;">Target</td>
                                            <td style="color: black;">'.$this->admin_model->getLanguage($jobPrice->target).'</td>
                                            <td style="color: #d306e8;">Contact Person</td>
                                            <td style="color: black;"></td>
                                           </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                           <tr>
                                            <td style="color: #d306e8;">Task Name</td>
                                            <td style="color: #d306e8;">Volume</td>
                                            <td style="color: #d306e8;">Unit</td>
                                            <td style="color: #d306e8;">Rate</td>
                                            <td style="color: #d306e8;">Price</td>
                                           </tr>
                                           <tr>
                                            <td style="color: black;">'.$row->subject.'</td>
                                            <td style="color: black;">'.$row->count.'</td>
                                            <td style="color: black;">'.$this->admin_model->getUnit($row->unit).'</td>
                                            <td style="color: black;">'.$row->rate.'</td>
                                            <td style="color: black;">'.$row->count*$row->rate.'</td>
                                           </tr>
                                           <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td style="color: black;">Total</td>
                                            <td style="color: black;">'.$row->count*$row->rate.'</td>
                                           </tr>
                                           <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td style="color: black;">'.$this->admin_model->getCurrency($row->currency).'</td>
                                           </tr>
                                        </tbody>
                                    </table>
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;font-size:18px;">
                                        <tbody>
                                            <tr>
                                                 <td colspan=2 style="background-color: #06b8e8;color:#d306e8;text-align:left;">
                                                    <p>Dear our valued Vendor, please take into consideration the below conditions:</p>
                                                    <p>• Payments will be processed within 45 to 60 days from date of receiving your invoice by 
                                                     mira.mohammed@dtpzone.com.</p>
                                                    <p>• Once you submit your work to our PM, please send your invoice along with the PO number received
                                                    from our PM via email to  mira.mohammed@dtpzone.com.</p>
                                                    <p>• The company is not responsible for any payment delay due to sending the invoice to the incorrect 
                                                    contact/person, The invoice must be sent to:  mira.mohammed@dtpzone.com.</p>
                                                    <p>• If any delay from your side to send your invoice once you finished the work, so it is not the company'."'".'s 
                                                    responsibility, and the normal duration paymnet will be applied "45 to 60 days from date of receiving your late invoice".</p> 
                                                    <p>• PLEASE DO NOT SEND your invoice to the Project/Vendor Manager. Invoices MUST ONLY be sent to  mira.mohammed@dtpzone.com, if you wish you can keep the PM cced. </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                          </div>
                </body>
                </html>';
            }
            //echo $msg;
            $this->email->message($msg);
              $this->email->set_header('Reply-To', $pmMail);
              $this->email->set_mailtype('html');
              $this->email->send();
    }
  	
  	public function getProjectStatus($status=""){
        if($status == 0){
            echo "Running";
        }elseif($status == 1){
            echo "Closed";
        }
    }
  
    public function getNewProjectStatus($status="",$projectId=""){
        $projectStatus = $this->checkCloseProject($projectId);
          if($projectStatus == 1){
            echo "Closed";
          }else{
            echo "Running";
          }
    }


    public function selectProjectStatus($select=""){
        if($select == 0){
            $selected1 = 'selected';
        }elseif ($select == 1) {
            $selected2 = 'selected';
        }
        else{
            $selected1 = '';
            $selected2 = '';
        }

        $outpt = '<option value="0" '.$selected1.'>Running</option>
                  <option value="1" '.$selected2.'>Closed</option>';
        return $outpt;
    }
  
  	public function getJobStatus($status=""){
        if($status == 0){
            echo "Running";
        }elseif($status == 1){
            echo "Delivered";
        }elseif ($status == 2) {
            echo "Cancelled";
        }
    }

    public function selectJobStatus($select=""){
        if($select == 0){
            $selected1 = 'selected';
        }elseif ($select == 1) {
            $selected2 = 'selected';
        }
        else{
            $selected1 = '';
            $selected2 = '';
        }

        $outpt = '<option value="0" '.$selected1.'>Running</option>
                  <option value="1" '.$selected2.'>Delivered</option>';
        return $outpt;
    }
  
	// public function checkCloseJob($job){
	// $tasksNum = $this->db->query(" SELECT * FROM `job_task` WHERE status <> 2 AND job_id = '$job'  ")->num_rows();
	// $DTPNum = $this->db->query(" SELECT * FROM `dtp_request` WHERE status <> 0 AND job_id = '$job'  ")->num_rows();
	// $translationNum = $this->db->query(" SELECT * FROM `translation_request` WHERE status <> 0 AND job_id = '$job'  ")->num_rows();
	// $closedTaskNum = $this->db->get_where('job_task',array('job_id'=>$job,'status'=>1))->num_rows();
	// $closedDTPNum = $this->db->get_where('dtp_request',array('job_id'=>$job,'status'=>3))->num_rows();
	// $closedTranslationNum = $this->db->get_where('translation_request',array('job_id'=>$job,'status'=>3))->num_rows();
	// if(($tasksNum + $DTPNum + $translationNum) == 0){
	// return false;
	// }else{
	// if(($tasksNum + $DTPNum + $translationNum) === ($closedTaskNum + $closedDTPNum + $closedTranslationNum)){
	// return true;
	// }else{
	// return false;
	// }
	// }
	// }
	
	public function checkCloseJob($job){
        $tasksNum = $this->db->query(" SELECT * FROM `job_task` WHERE status <> 2 AND job_id = '$job'  ")->num_rows();
        $DTPNum = $this->db->query(" SELECT * FROM `dtp_request` WHERE (status <> 0 AND status <> 4) AND job_id = '$job'  ")->num_rows();
        $translationNum = $this->db->query(" SELECT * FROM `translation_request` WHERE (status <> 0 AND status <> 4) AND job_id = '$job'  ")->num_rows();
        $LeTasksNum = $this->db->query(" SELECT * FROM `le_request` WHERE (status <> 0 AND status <> 4) AND job_id = '$job'  ")->num_rows();
        $closedTaskNum = $this->db->get_where('job_task',array('job_id'=>$job,'status'=>1))->num_rows();
        $closedDTPNum = $this->db->get_where('dtp_request',array('job_id'=>$job,'status'=>3))->num_rows();
        $closedTranslationNum = $this->db->get_where('translation_request',array('job_id'=>$job,'status'=>3))->num_rows();
        $closedLeNum = $this->db->get_where('le_request',array('job_id'=>$job,'status'=>3))->num_rows();
        if(($tasksNum + $DTPNum + $translationNum + $LeTasksNum) == 0){
            return false;
        }else{
            if(($tasksNum + $DTPNum + $translationNum + $LeTasksNum) === ($closedTaskNum + $closedDTPNum + $closedTranslationNum + $closedLeNum)){
                return true;
            }else{
                return false;
            }
        }
    }

  	public function checkProjectPo($po,$select){
        $check = $this->db->get_where('po',array('number'=>trim($po)));
        if($check->num_rows() > 0){
          $poId = $check->row()->id;
          $jobIds = $this->db->query(" SELECT GROUP_CONCAT(id SEPARATOR ',') AS ids FROM job WHERE po = '$poId' ")->row();
          if($select == $jobIds->ids){
            return true;
          }else{
            return false;
          }
        }else{
          return true;
        }
    }
  
  	public function checkCloseProject($project){
        $jobsNum = $this->db->get_where('job',array('project_id'=>$project))->num_rows();
        $closedJobNum = $this->db->get_where('job',array('project_id'=>$project,'status'=>1))->num_rows();
        if($jobsNum == 0){
            return false;
        }else{
            if($jobsNum === $closedJobNum){
                return true;
            }else{
                return false;
            }
        }
    }
  	
  	public function totalRevenueProject($id){
        $jobs = $this->db->get_where('job',array('project_id'=>$id))->result();
        $data['total'] = 0;
        foreach ($jobs as $job) {
            $total = 0;
            $priceList = Self::getJobPriceListData($job->price_list);
            $data['currency'] = $priceList->currency;
            if($job->type == 1){
                $total = $priceList->rate * $job->volume;
            }elseif ($job->type == 2) {
                $fuzzy = $this->db->get_where('project_fuzzy',array('job'=>$job->id))->result();
                $total = 0;
                foreach ($fuzzy as $row) {
                    $total = $total + ($row->unit_number * $row->value * $priceList->rate);
                }
            }
            $data['total'] = $data['total'] + $total;
        }

        return $data;
    }

	public function totalRevenuePO($id){
        $jobs = $this->db->get_where('job',array('po'=>$id))->result();
        $data['total'] = 0;
        foreach ($jobs as $job) {
            $total = 0;
            $priceList = Self::getJobPriceListData($job->price_list);
            $data['currency'] = $priceList->currency;
            if($job->type == 1){
                $total = $priceList->rate * $job->volume;
            }elseif ($job->type == 2) {
                $fuzzy = $this->db->get_where('project_fuzzy',array('job'=>$job->id))->result();
                $total = 0;
                foreach ($fuzzy as $row) {
                    $total = $total + ($row->unit_number * $row->value * $priceList->rate);
                }
            }
            $data['total'] = $data['total'] + $total;
        }

        return $data;
    }
  
  	public function totalTaskProject($id){
        $job_ids = $this->db->query(" SELECT GROUP_CONCAT(id SEPARATOR ',') AS job_ids FROM job WHERE project_id = '$id' ")->row()->job_ids;
        if($job_ids == NULL){
            $job_ids = 0;
        }
        $task = $this->db->query(" SELECT * FROM `job_task` WHERE job_id IN (".$job_ids.") ")->result();
        $total = 0;
        foreach ($task as $task) {        
            $total = $total + ($task->rate * $task->count);
        }
        return $total;
    }
  
  	public function allJobs($permission,$user,$brand,$filter)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT j.*,p.customer,p.lead,l.service,l.source,l.target,l.rate,l.currency,l.product_line,(SELECT brand FROM `users` WHERE users.id = j.created_by) AS brand FROM job AS j 
                LEFT OUTER JOIN project AS p on j.project_id = p.id
                LEFT OUTER JOIN job_price_list AS l on l.id = j.price_list
                WHERE project_id <> 0 AND ".$filter." HAVING brand = '$brand' order by id desc ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT j.*,p.customer,p.lead,l.service,l.source,l.target,l.rate,l.currency,l.product_line,(SELECT brand FROM `users` WHERE users.id = j.created_by) AS brand FROM job AS j 
                LEFT OUTER JOIN project AS p on j.project_id = p.id
                LEFT OUTER JOIN job_price_list AS l on l.id = j.price_list
                WHERE j.created_by = '$user' AND project_id <> 0 AND ".$filter." HAVING brand = '$brand' order by id desc ");
        }
        return $data;
    }

    public function allJobsPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT j.*,p.customer,p.lead,l.service,l.source,l.target,l.rate,l.currency,l.product_line,(SELECT brand FROM `users` WHERE users.id = j.created_by) AS brand FROM job AS j 
                LEFT OUTER JOIN project AS p on j.project_id = p.id
                LEFT OUTER JOIN job_price_list AS l on l.id = j.price_list
                WHERE project_id <> 0
                HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("SELECT j.*,p.customer,p.lead,l.service,l.source,l.target,l.rate,l.currency,l.product_line,(SELECT brand FROM `users` WHERE users.id = j.created_by) AS brand FROM job AS j 
                LEFT OUTER JOIN project AS p on j.project_id = p.id
                LEFT OUTER JOIN job_price_list AS l on l.id = j.price_list
                WHERE j.created_by = '$user' AND project_id <> 0 HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }
  
    public function AllTasks($permission,$user,$brand,$filter)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT j.*,l.source,l.target,(SELECT brand FROM `users` WHERE users.id = j.created_by) AS brand FROM job_task AS j 
                LEFT OUTER JOIN job AS p on j.job_id = p.id
                LEFT OUTER JOIN job_price_list AS l on l.id = p.price_list
                WHERE job_id <> 0 AND ".$filter." HAVING brand = '$brand' order by id desc ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT j.*,l.source,l.target,(SELECT brand FROM `users` WHERE users.id = j.created_by) AS brand FROM job_task AS j 
                LEFT OUTER JOIN job AS p on j.job_id = p.id
                LEFT OUTER JOIN job_price_list AS l on l.id = p.price_list
                WHERE j.created_by = '$user' AND job_id <> 0 AND ".$filter." HAVING brand = '$brand' order by id desc ");
        }
        return $data;
    }

  
    public function AllTasksPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT j.*,l.source,l.target,l.rate,(SELECT brand FROM `users` WHERE users.id = j.created_by) AS brand FROM job_task AS j 
                LEFT OUTER JOIN job AS p on j.job_id = p.id
                LEFT OUTER JOIN job_price_list AS l on l.id = p.price_list
                WHERE project_id <> 0
                HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("SELECT j.*,l.source,l.target,(SELECT brand FROM `users` WHERE users.id = j.created_by) AS brand FROM job_task AS j 
                LEFT OUTER JOIN job AS p on j.job_id = p.id
                LEFT OUTER JOIN job_price_list AS l on l.id = p.price_list
                WHERE j.created_by = '$user' AND job_id <> 0 HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

  
  	public function sendRejectMail($data,$pm,$opportunity){
        $row = $this->db->get_where('sales_opportunity',array('id'=>$opportunity))->row();
        $sam = $this->db->get_where('users',array('id'=>$row->created_by))->row();
        $pmMail = $this->db->get_where('users',array('id'=>$pm))->row()->email;
        $mailTo = $sam->email;
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
       
        $subject = "Opportunity Rejected #".$opportunity." - ".date("Y-m-d H:i:s");
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                    <p>Dear '.$sam->user_name.',</p>
                       <p>Please check your Opportunity #'.$opportunity.' </p>
                       <p>PM Comment : '.$data['reject_reason'].'</p>
                       <p>Thanks</p>
                    </body>
                    </html>';
      //    echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }
  
  	public function sendVendorCancelTaskMail($id,$user,$brand){
        $row = Self::getTaskData($id);
        $job = Self::getJobData($row->job_id);
        $jobPrice = Self::getJobPriceListData($job->price_list);
        // $vendor = $this->vendor_model->getVendorSheetData($row->vendor);
        $pmMail = $this->admin_model->getUserEmail($user);
        
        $vendor = $this->vendor_model->getVendorData($row->vendor);
        $mailTo = $vendor->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        $subject = "Cancelled Task : ".$row->code;
        
         $config = Array(
        'protocol' => 'smtp',
        'smtp_host' => 'mail.thetranslationgate.com',
        'smtp_port' => 465,
        'smtp_user' => 'falaqsystem@thetranslationgate.com',
        'smtp_pass' => 'GaU6FjtJ$*Hb8P-j',
        'charset'=>'utf-8',
         'validate'=>TRUE,
        'wordwrap'=> TRUE,
      );

      $this->load->library('email', $config);
      $this->email->set_newline("\r\n");
      $this->email->from($pmMail);
      // replace my mail by pm manger it is just for testing
      $this->email->to($mailTo);
      if($brand == 1){
        $this->email->cc($pmMail.', vm@thetranslationgate.com');
      }elseif ($brand == 2) {
        $this->email->cc($pmMail.', shehab.hussein@dtpzone.com, vm@dtpzone.com');
      }elseif ($brand == 3) {
        $this->email->cc($pmMail.', vm@europelocalize.com');
      }
      $this->email->subject($subject);
        
        $msg = '<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <meta name="description" content="">
                    <meta name="author" content="">
                    <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                    <title>Falaq| Site Manager</title>
                    <style>
                    body {
                        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                        font-size: 14px;
                        line-height: 1.428571429;
                        color: #333;
                    }
                    section#unseen
                    {
                        overflow: scroll;
                        width: 100%
                    }
                    </style>
                    <!--Core js-->
                </head>

                <body>
                <div class="panel-body">
                                <div class="adv-table editable-table ">
                                    <div class="clearfix">
                                        <div class="btn-group">
                                            <span class=" btn-primary" style="">
                                            </span>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="space15"></div>
                                    
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                            <tr>
                                                 <td colspan=2 style="background-color: #ddd;">Task Data</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Task Code</td>
                                                 <td style="background-color:#ddd;">'.$row->code.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Task Type</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getTaskType($row->task_type).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Service</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getServices($this->admin_model->getTaskTypeParent($row->task_type)).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Vendor</td>
                                                 <td style="background-color:#ddd;">'.$this->vendor_model->getVendorName($row->vendor).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Source</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getLanguage($jobPrice->source).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Target</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getLanguage($jobPrice->target).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Count</td>
                                                 <td style="background-color:#ddd;">'.$row->count.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Unit</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getUnit($row->unit).'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Rate</td>
                                                 <td style="background-color:#ddd;">'.$row->rate.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Total Cost</td>
                                                 <td style="background-color:#ddd;">'.$row->rate * $row->count.'</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Currency</td>
                                                 <td style="background-color:#ddd;">'.$this->admin_model->getCurrency($row->currency).'</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                          </div>
                </body>
                </html>';
            //echo $msg;
            $this->email->message($msg);
          $this->email->set_header('Reply-To', $pmMail);
          $this->email->set_mailtype('html');
          $this->email->send();
    }
  
  	public function AllCustomerJobs($permission,$user,$brand)
    {
        if($permission->view == 1){
          $data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `job_customer` AS p WHERE p.status = '0' HAVING brand = '$brand' ");
        }elseif($permission->view == 2){
          $data = $this->db->query("SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand,(SELECT COUNT(*) FROM customer_pm WHERE customer_pm.lead = p.lead AND customer_pm.pm = '$pm') AS total FROM `job_customer` AS p WHERE p.status = '0' HAVING total > 0 AND brand = '$brand' ");
        } 
        return $data;
    }

	public function getJobPoData($id){
        $po = $this->db->get_where('po',array('id'=>$id))->row();
        return $po;
    }

	public function lateDeliveryReport($filter,$brand){
        $jobs = $this->db->query(" SELECT j.*,(SELECT brand FROM `users` WHERE users.id = j.created_by) AS brand FROM `job` AS j WHERE j.status = '0' AND j.delivery_date IS NOT NULL AND ".$filter." HAVING brand = '$brand' ");
        return $jobs;
    }

	public function clientAllJobs($permission,$user,$brand,$filter)
    {
          $data = $this->db->query(" SELECT j.*,p.customer,p.lead,l.service,l.source,l.target,l.rate,l.currency,l.product_line,(SELECT COUNT(*) FROM `customer_pm` WHERE pm = '$user' AND customer_pm.lead = p.lead) AS total FROM job AS j 
                LEFT OUTER JOIN project AS p on j.project_id = p.id
                LEFT OUTER JOIN job_price_list AS l on l.id = j.price_list
                WHERE project_id <> 0 AND ".$filter." HAVING total > '0' order by id desc ");
        return $data;
    }

    public function clientAllJobsPages($permission,$user,$brand,$limit,$offset)
    {
            $data = $this->db->query(" SELECT j.*,p.customer,p.lead,l.service,l.source,l.target,l.rate,l.currency,l.product_line,(SELECT COUNT(*) FROM `customer_pm` WHERE pm = '$user' AND customer_pm.lead = p.lead) AS total FROM job AS j 
                LEFT OUTER JOIN project AS p on j.project_id = p.id
                LEFT OUTER JOIN job_price_list AS l on l.id = j.price_list
                WHERE project_id <> 0
                HAVING total > '0' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

	public function returnDTPTakenTime($task,$stoped){
        $dtpHistory = $this->db->get_where('dtp_request_history',array('task'=>$task));
        $LastRunning = $this->db->query(" SELECT * FROM `dtp_request_history` WHERE task = '$task' AND status = 1 ORDER BY id desc ")->row();
        $started = strtotime($LastRunning->created_at);
        $stoped = strtotime($stoped);

        $taken = $stoped - $started;
        return $taken / (60 * 60);
    }

	public function getDTPJobTime($jobId){
        $time = $this->db->query("SELECT SUM(taken_time) AS totalTime FROM `dtp_request_history` WHERE `task` = '$jobId' ")->row();
        $timeTotal = explode(".", $time->totalTime);
        // print_r($timeTotal);
        $data['hrs'] = round($timeTotal[0]);
        $data['mins'] = round(($time->totalTime - $timeTotal[0]) * 60);
        return $data;
    }

	public function getDTPRate($target_direction,$source_application,$translation_in){
        $data = $this->db->get_where('dtp_rates',array('target_direction'=>$target_direction,'source_application'=>$source_application,'translation_in'=>$translation_in));
        if($data->num_rows() > 0){
          return $data->row()->rate;
        }else{
          return "";
        }
    }

	public function getDTPTaskStatus($status=""){
        if($status == 1){
            echo '<span class="badge badge-danger p-2" style="background-color: #e8e806">Waiting Confirmation</span>';
        }
        elseif($status == 2){
            echo '<span class="badge badge-danger p-2" style="background-color: #07b817">Running</span>';
        }elseif($status == 0){
            echo '<span class="badge badge-danger p-2" style="background-color: #fb0404">Rejected</span>';
        }elseif($status == 3){
            echo '<span class="badge badge-danger p-2" style="background-color: #5e5e5d">Closed</span>';
        }elseif($status == 5){
            echo '<span class="badge badge-danger p-2" style="background-color: #6303A5">Update</span>';
        }elseif($status == 4){
            echo '<span class="badge badge-danger p-5" style="background-color: #FF5733">Cancelled</span>';
        }
    }

	public function newDtpTasks($brand){
        $data = $this->db->query("SELECT *,(SELECT brand FROM `users` where id = dtp_request.created_by) AS brand FROM `dtp_request` WHERE status = 1 HAVING brand = '$brand' ");
        return $data;
    }

	public function AllDTPTasks($permission,$user,$brand,$filter)
    {

        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = dtp_request.created_by) AS brand FROM `dtp_request` WHERE ".$filter." AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = dtp_request.created_by) AS brand FROM `dtp_request` WHERE ".$filter." AND status_by = '$user' AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC ");
        }
        return $data;
    }

    public function AllDTPTasksPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = dtp_request.created_by) AS brand FROM `dtp_request` WHERE (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("SELECT *,(SELECT brand FROM `users` where id = dtp_request.created_by) AS brand FROM `dtp_request` WHERE status_by = '$user' AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

  public function AllDTPPm($permission,$user,$brand,$filter)
    {

        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = dtp_request.created_by) AS brand FROM `dtp_request` WHERE ".$filter." AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = dtp_request.created_by) AS brand FROM `dtp_request` WHERE ".$filter." AND created_by = '$user' AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC ");
        }
        return $data;
    }


    public function AllDTPJobs($permission,$user,$brand,$filter)
    {

        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = dtp_request_job.created_by) AS brand FROM `dtp_request_job` WHERE ".$filter." HAVING brand = '$brand' ORDER BY id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = dtp_request_job.created_by) AS brand FROM `dtp_request_job` WHERE ".$filter." AND dtp = '$user' HAVING brand = '$brand' ORDER BY id DESC ");
        }
        return $data;
    }

    public function AllDTPJobsPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = dtp_request_job.created_by) AS brand FROM `dtp_request_job` HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("SELECT *,(SELECT brand FROM `users` where id = dtp_request_job.created_by) AS brand FROM `dtp_request_job` WHERE dtp = '$user' HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

	public function getTranslationTaskStatus($status=""){
        if($status == 1){
            echo '<span class="badge badge-danger p-2" style="background-color: #e8e806">Waiting Confirmation</span>';
        }
        elseif($status == 2){
            echo '<span class="badge badge-danger p-2" style="background-color: #07b817">Running</span>';
        }elseif($status == 0){
            echo '<span class="badge badge-danger p-2" style="background-color: #fb0404">Rejected</span>';
        }elseif($status == 3){
            echo '<span class="badge badge-danger p-2" style="background-color: #5e5e5d">Closed</span>';
        }elseif($status == 5){
            echo '<span class="badge badge-danger p-2" style="background-color: #6303A5">Update</span>';
        }elseif($status == 4){
            echo '<span class="badge badge-danger p-2" style="background-color: #FF5733">Cancelled</span>';
        }
    }

    public function newTranslationTasks($brand){
        $data = $this->db->query("SELECT *,(SELECT brand FROM `users` where id = translation_request.created_by) AS brand FROM `translation_request` WHERE status = 1 HAVING brand = '$brand' ");
        return $data;
    }

    public function AllTranslationTasks($permission,$user,$brand,$filter)
    {

        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = translation_request.created_by) AS brand FROM `translation_request` WHERE ".$filter." AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, delivery_date ASC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = translation_request.created_by) AS brand FROM `translation_request` WHERE ".$filter." AND status_by = '$user' AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, delivery_date ASC ");
        }
        return $data;
    }

    public function AllTranslationTasksPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = translation_request.created_by) AS brand FROM `translation_request` WHERE (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, delivery_date ASC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("SELECT *,(SELECT brand FROM `users` where id = translation_request.created_by) AS brand FROM `translation_request` WHERE status_by = '$user' AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, delivery_date ASC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }


        public function AllTranslationPm($permission,$user,$brand,$filter)
    {

        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = translation_request.created_by) AS brand FROM `translation_request` WHERE ".$filter." AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = translation_request.created_by) AS brand FROM `translation_request` WHERE ".$filter." AND created_by = '$user' AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC ");
        }
        return $data;
    }

    public function getTranslationJobStatus($status=""){
        if($status == 0){
            echo '<span class="badge badge-danger p-2" style="background-color: #e8e806">Not Started</span>';
        }
        elseif($status == 1){
            echo '<span class="badge badge-danger p-2" style="background-color: #07b817">Running</span>';
        }elseif($status == 3){
            echo '<span class="badge badge-danger p-2" style="background-color: #fb0404">Rejected</span>';
        }elseif($status == 2){
            echo '<span class="badge badge-danger p-2" style="background-color: #5e5e5d">Closed</span>';
        }elseif($status == 4){
            echo '<span class="badge badge-danger p-2" style="background-color: #6303A5">Partly Closed</span>';
        }
    }

    public function AllTranslationJobs($permission,$user,$brand,$filter)
    {

        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = translation_request_job.created_by) AS brand FROM `translation_request_job` WHERE ".$filter." HAVING brand = '$brand' ORDER BY id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = translation_request_job.created_by) AS brand FROM `translation_request_job` WHERE ".$filter." AND translator = '$user' HAVING brand = '$brand' ORDER BY id DESC ");
        }
        return $data;
    }

    public function AllTranslationJobsPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = translation_request_job.created_by) AS brand FROM `translation_request_job` HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("SELECT *,(SELECT brand FROM `users` where id = translation_request_job.created_by) AS brand FROM `translation_request_job` WHERE translator = '$user' HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

    public function returnTranslationTakenTime($task,$stoped){
        $dtpHistory = $this->db->get_where('translation_request_history',array('task'=>$task));
        $LastRunning = $this->db->query(" SELECT * FROM `translation_request_history` WHERE task = '$task' AND status = 1 ORDER BY id desc ")->row();
        $started = strtotime($LastRunning->created_at);
        $stoped = strtotime($stoped);

        $taken = $stoped - $started;
        return $taken / (60 * 60);
    }

	public function getTranslationJobTime($jobId){
        $time = $this->db->query("SELECT SUM(taken_time) AS totalTime FROM `translation_request_history` WHERE `task` = '$jobId' ")->row();
        $timeTotal = explode(".", $time->totalTime);
        // print_r($timeTotal);
        $data['hrs'] = round($timeTotal[0]);
        $data['mins'] = round(($time->totalTime - $timeTotal[0]) * 60);
        return $data;
    }

    public function checkCloseTranslationRequest($request){
        $allJobs = $this->db->get_where('translation_request_job',array('request_id'=>$request))->num_rows();
        $closedJobs = $this->db->query(" SELECT * FROM `translation_request_job` WHERE request_id = '$request' AND (status = 2 OR status = 4 OR status = 3) ")->num_rows();
        if($allJobs == 0){
          return false;
        }else{
          if($allJobs == $closedJobs){
              return true;
          }else{
            return false;
          }
        }
    }

    public function getLETaskStatus($status=""){
        if($status == 1){
            echo '<span class="badge badge-danger p-2" style="background-color: #e8e806">Waiting Confirmation</span>';
        }
        elseif($status == 2){
            echo '<span class="badge badge-danger p-2" style="background-color: #07b817">Running</span>';
        }elseif($status == 0){
            echo '<span class="badge badge-danger p-2" style="background-color: #fb0404">Rejected</span>';
        }elseif($status == 3){
            echo '<span class="badge badge-danger p-2" style="background-color: #5e5e5d">Closed</span>';
        }elseif($status == 5){
            echo '<span class="badge badge-danger p-2" style="background-color: #6303A5">Update</span>';
        }elseif($status == 4){
            echo '<span class="badge badge-danger p-5" style="background-color: #FF5733">Cancelled</span>';
        }
    }

    public function newLETasks($brand){
        $data = $this->db->query("SELECT *,(SELECT brand FROM `users` where id = le_request.created_by) AS brand FROM `le_request` WHERE status = 1 HAVING brand = '$brand' ");
        return $data;
    }

    public function AllLETasks($permission,$user,$brand,$filter)
    {

        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = le_request.created_by) AS brand FROM `le_request` WHERE ".$filter." AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = le_request.created_by) AS brand FROM `le_request` WHERE ".$filter." AND status_by = '$user' AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC ");
        }
        return $data;
    }

    public function AllLETasksPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = le_request.created_by) AS brand FROM `le_request` WHERE (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("SELECT *,(SELECT brand FROM `users` where id = le_request.created_by) AS brand FROM `le_request` WHERE status_by = '$user' AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }


            public function AllLEPm($permission,$user,$brand,$filter)
    {

        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = le_request.created_by) AS brand FROM `le_request` WHERE ".$filter." AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = le_request.created_by) AS brand FROM `le_request` WHERE ".$filter." AND created_by = '$user' AND (status <> 0 AND (status <> 1 AND status <> 5)) HAVING brand = '$brand' ORDER BY status ASC, id DESC ");
        }
        return $data;
    }


    ////////request with no job

        public function AllLETasksNoJob($permission,$user,$brand,$filter)
    {

        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = le_request.created_by) AS brand FROM `le_request` WHERE job_id = 0 AND ".$filter." HAVING brand = '$brand' ORDER BY id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = le_request.created_by) AS brand FROM `le_request` WHERE job_id = 0 AND ".$filter." AND created_by = '$user' HAVING brand = '$brand' ORDER BY id DESC ");
        }
        return $data;
    }

public function AllLETasksPagesNoJob($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = le_request.created_by) AS brand FROM `le_request` WHERE job_id = 0 HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("SELECT *,(SELECT brand FROM `users` where id = le_request.created_by) AS brand FROM `le_request` WHERE job_id = 0 AND created_by = '$user' HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }


    /////////////////

    public function AllLEJobs($permission,$user,$brand,$filter)
    {

        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = le_request_job.created_by) AS brand FROM `le_request_job` WHERE ".$filter." HAVING brand = '$brand' ORDER BY status ASC , id DESC ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = le_request_job.created_by) AS brand FROM `le_request_job` WHERE ".$filter." AND le = '$user' HAVING brand = '$brand' ORDER BY status ASC , id DESC ");
        }
        return $data;
    }

    public function AllLEJobsPages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT *,(SELECT brand FROM `users` where id = le_request_job.created_by) AS brand FROM `le_request_job` HAVING brand = '$brand' ORDER BY status ASC , id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("SELECT *,(SELECT brand FROM `users` where id = le_request_job.created_by) AS brand FROM `le_request_job` WHERE le = '$user' HAVING brand = '$brand' ORDER BY status ASC , id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

    public function checkCloseLERequest($request){
        $allJobs = $this->db->get_where('le_request_job',array('request_id'=>$request))->num_rows();
        $closedJobs = $this->db->query(" SELECT * FROM `le_request_job` WHERE request_id = '$request' AND (status = 2 OR status = 4 OR status = 3) ")->num_rows();
        if($allJobs == 0){
          return false;
        }else{
          if($allJobs == $closedJobs){
              return true;
          }else{
            return false;
          }
        }
    }

    public function checkCloseDTPRequest($request){
        $allJobs = $this->db->get_where('dtp_request_job',array('request_id'=>$request))->num_rows();
        $closedJobs = $this->db->query(" SELECT * FROM `dtp_request_job` WHERE request_id = '$request' AND (status = 2 OR status = 4 OR status = 3) ")->num_rows();
        if($allJobs == 0){
          return false;
        }else{
          if($allJobs == $closedJobs){
              return true;
          }else{
            return false;
          }
        }
    }

	public function returnLETakenTime($task,$stoped){
        $dtpHistory = $this->db->get_where('le_request_history',array('task'=>$task));
        $LastRunning = $this->db->query(" SELECT * FROM `le_request_history` WHERE task = '$task' AND status = 1 ORDER BY id desc ")->row();
        $started = strtotime($LastRunning->created_at);
        $stoped = strtotime($stoped);

        $taken = $stoped - $started;
        return $taken / (60 * 60);
    }

	public function getLEJobTime($jobId){
        $time = $this->db->query("SELECT SUM(taken_time) AS totalTime FROM `le_request_history` WHERE `task` = '$jobId' ")->row();
        $timeTotal = explode(".", $time->totalTime);
        // print_r($timeTotal);
        $data['hrs'] = round($timeTotal[0]);
        $data['mins'] = round(($time->totalTime - $timeTotal[0]) * 60);
        return $data;
    }

	public function sendLERequestMail($id,$data){
        $pmMail = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        $mailTo = "le@thetranslationgate.com";
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
       
        $subject = "New LE Request # LE-".$id." - ".$data['subject'];
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                    <table class="table table-striped  table-hover table-bordered" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center" id="">
                    <thead>
                      <tr>
                        <th>PM</th>
                        <th>Task Type</th>
                       <th>Task Name</th>
                       <th>Start Date</th>
                       <th>Delivery Date</th>
                       <th>Created Date</th>
                      </tr>
                    </thead>
                    <tbody>
                    <tr>
                          <td>'.$this->admin_model->getAdmin($data['created_by']).'</td>
                          <td>'.$this->admin_model->getLETaskType($data['task_type']).'</td>
                          <td>'.$data['subject'].'</td>
                          <td>'.$data['start_date'].'</td>
                          <td>'.$data['delivery_date'].'</td>
                          <td>'.$data['created_at'].'</td>
                      </tr>
                      </tbody>
                    </table>
                    </body>
                    </html>';
      //    echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendDTPRequestMail($id,$data){
        $pmMail = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        if($this->brand == 2){
           $mailTo = "maged.kamel@dtpzone.com";
        }else{
           $mailTo = "dtp@thetranslationgate.com";
        }
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
       
        $subject = "New DTP Request # DTP-".$id." - ".$data['task_name'];
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                    <table class="table table-striped  table-hover table-bordered" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center" id="">
                    <thead>
                      <tr>
                        <th>PM</th>
                        <th>Task Type</th>
                       <th>Task Name</th>
                       <th>Start Date</th>
                       <th>Delivery Date</th>
                       <th>Created Date</th>
                      </tr>
                    </thead>
                    <tbody>
                    <tr>
                          <td>'.$this->admin_model->getAdmin($data['created_by']).'</td>
                          <td>'.$this->admin_model->getDTPTaskType($data['task_type']).'</td>
                          <td>'.$data['task_name'].'</td>
                          <td>'.$data['start_date'].'</td>
                          <td>'.$data['delivery_date'].'</td>
                          <td>'.$data['created_at'].'</td>
                      </tr>
                      </tbody>
                    </table>
                    </body>
                    </html>';
      //    echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendTranslationRequestMail($id,$data){
        $pmMail = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        $mailTo = "translation.allocator@thetranslationgate.com";
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
       
        $subject = "New Translation Request # Translation-".$id." - ".$data['subject'];
        if(strlen($data['file']) > 1){
        	$attachment = '<a href="'.base_url().'assets/uploads/translationRequest/'.$data['file'].'">Click Here</a>';
        }else{
        	$attachment = '';
        }
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                    <table class="table table-striped  table-hover table-bordered" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center" id="">
                    <thead>
                      <tr>
                        <th>PM</th>
                        <th>Task Type</th>
                       <th>Task Name</th>
                        <th>Attachment</th>
                       <th>Start Date</th>
                       <th>Delivery Date</th>
                       <th>Created Date</th>
                      </tr>
                    </thead>
                    <tbody>
                    <tr>
                          <td>'.$this->admin_model->getAdmin($data['created_by']).'</td>
                          <td>'.$this->admin_model->getTaskType($data['task_type']).'</td>
                          <td>'.$data['subject'].'</td>
                          <td>'.$attachment.'</td>
                          <td>'.$data['start_date'].'</td>
                          <td>'.$data['delivery_date'].'</td>
                          <td>'.$data['created_at'].'</td>
                      </tr>
                      </tbody>
                    </table>
                    </body>
                    </html>';
      //    echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendLERequestStatusMail($id,$data,$comment="",$file=""){
        $requestData = $this->db->get_where('le_request',array('id'=>$id))->row();
        $mailTo = $this->db->get_where('users',array('id'=>$requestData->created_by))->row()->email;
        $LE = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$LE."\r\n";
        $headers .= 'From: '.$LE."\r\n";
        $msgData = "";
        $subject = "LE Request # LE-".$id." - ".$requestData->subject;  

      if(strlen($file) > 1){
        $fileMsg = 'Check the attachment file <a href="'.base_url().'assets/uploads/leRequest/'.$file.'" target="_blank">Click Here ..</a>'; 
        
        }else{
          $fileMsg = '';
        }

        if($data['status'] == 2){
            $msgData .= '<p>Your request has been accepted, please check</p>';
        }elseif($data['status'] == 0){
            $msgData .= '<p>Your request has been Rejected, please check</p>';
            $msgData .= '<p>'.$comment.'</p>';
            $msgData .= '<p>Thank You!</p>';
        }elseif($data['status'] == 3){
            $msgData .= '<p>Your request has been Closed, please check</p>';
            $msgData .= '<p>'.$comment.'</p>';
            $msgData .= '<p>'.$fileMsg.'</p>';
            $msgData .= '<p>Thank You!</p>';
        }elseif($data['status'] == 5){
            $msgData .= '<p>Your request needs some updates, please check</p>';
            $msgData .= '<p>'.$comment.'</p>';
            $msgData .= '<p>Thank You!</p>';
        }
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        '.$msgData.'
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendJobAssignment($userId,$mailSubject,$mailBody){
        $user = $this->db->get_where('users',array('id'=>$userId))->row();
        $mailTo = $user->email;
        $from = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$from."\r\n";
        $headers .= 'From: '.$from."\r\n";
        $msgData = "";
        //$subject = "New Job Assignment: ".date("Y-m-d H:i:s");
        $subject = $mailSubject ;
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        <p>Dear '.$user->user_name.', </p>
                         <p>'.$mailBody.'</p>
                        <p>Thank You!</p>
                    </body>
                    </html>';
             // echo $message; 
          mail($mailTo,$subject,$message,$headers);
    }

	public function sendTranslationRequestStatusMail($id,$data,$comment="",$file=""){
        $requestData = $this->db->get_where('translation_request',array('id'=>$id))->row();
        $mailTo = $this->db->get_where('users',array('id'=>$requestData->created_by))->row()->email;
        $translation = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$translation."\r\n";
        $headers .= 'From: '.$translation."\r\n";
        $msgData = "";
        $subject = "Translation Request # Translation-".$id." - ".$requestData->subject;

        if(strlen($file) > 1){
        $fileMsg = 'Check the attachment file <a href="'.base_url().'assets/uploads/translationRequest/'.$file.'" target="_blank">Click Here ..</a>'; 
        
        }else{
          $fileMsg = '';
        }

        if($data['status'] == 2){
            $msgData .= '<p>Your request has been accepted, please check</p>';
        }elseif($data['status'] == 0){
            $msgData .= '<p>Your request has been Rejected, please check</p>';
            $msgData .= '<p>'.$comment.'</p>';
            $msgData .= '<p>Thank You!</p>';
        }elseif($data['status'] == 3){
            $msgData .= '<p>Your request has been Closed, please check</p>';
            $msgData .= '<p>'.$comment.'</p>';
            $msgData .= '<p>'.$fileMsg.'</p>';
            $msgData .= '<p>Thank You!</p>';
        }elseif($data['status'] == 5){
            $msgData .= '<p>Your request needs some updates, please check</p>';
            $msgData .= '<p>'.$comment.'</p>';
            $msgData .= '<p>Thank You!</p>';
        }
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        '.$msgData.'
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendDTPRequestStatusMail($id,$data,$comment="",$file){
        $requestData = $this->db->get_where('dtp_request',array('id'=>$id))->row();
        $mailTo = $this->db->get_where('users',array('id'=>$requestData->created_by))->row()->email;
        $DTP = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$DTP."\r\n";
        $headers .= 'From: '.$DTP."\r\n";
        $msgData = "";
        $subject = "DTP Request # DTP-".$id." - ".$requestData->task_name;


      if(strlen($file) > 1){
        $fileMsg = 'Check the attachment file <a href="'.base_url().'assets/uploads/dtpRequest/'.$file.'" target="_blank">Click Here ..</a>'; 
        
        }else{
          $fileMsg = '';
        }


        if($data['status'] == 2){
            $msgData .= '<p>Your request has been accepted, please check</p>';
        }elseif($data['status'] == 0){
            $msgData .= '<p>Your request has been Rejected, please check</p>';
            $msgData .= '<p>'.$comment.'</p>';
            $msgData .= '<p>Thank You!</p>';
        }elseif($data['status'] == 3){
            $msgData .= '<p>Your request has been Closed, please check</p>';
            $msgData .= '<p>'.$comment.'</p>';
            $msgData .= '<p>'.$fileMsg.'</p>';
            $msgData .= '<p>Thank You!</p>';
        }elseif($data['status'] == 5){
            $msgData .= '<p>Your request needs some updates, please check</p>';
            $msgData .= '<p>'.$comment.'</p>';
            $msgData .= '<p>Thank You!</p>';
        }
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        '.$msgData.'
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendLEJobStatusMail($id,$data){
        $jobData = $this->db->get_where('le_request_job',array('id'=>$id))->row();
        $pmMail = $this->db->get_where('users',array('id'=>$jobData->created_by))->row()->email;
        $mailTo = $this->db->get_where('users',array('id'=>$jobData->le))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: le@thetranslationgate.com " . "\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
        $msgData = "";
        $subject = "LE Job";

        if($data['status'] == 2){
            $msgData .= '<p>Your Job has been Closed, please check.</p>';
        }elseif($data['status'] == 0){
            $msgData .= '<p>You have assigned to a new job, please check.</p>';
        }elseif($data['status'] == 3){
            $msgData .= '<p>Your job has been rejected, please check</p>';
        }elseif($data['status'] == 1){
            $msgData .= '<p>Your job has been accepted, please check</p>';
        }elseif($data['status'] == 4){
            $msgData .= '<p>Your job has been partly closed, please check</p>';
        }
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        '.$msgData.'
                        <p>Thank You!</p>
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendDTPJobStatusMail($id,$data){
        $jobData = $this->db->get_where('dtp_request_job',array('id'=>$id))->row();
        $pmMail = $this->db->get_where('users',array('id'=>$jobData->created_by))->row()->email;
        $mailTo = $this->db->get_where('users',array('id'=>$jobData->dtp))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
        $msgData = "";
        $subject = "DTP Job";

        if($data['status'] == 2){
            $msgData .= '<p>Your Job has been Closed, please check.</p>';
        }elseif($data['status'] == 0){
            $msgData .= '<p>You have assigned to a new job, please check.</p>';
        }elseif($data['status'] == 3){
            $msgData .= '<p>Your job has been rejected, please check</p>';
        }elseif($data['status'] == 1){
            $msgData .= '<p>Your job has been accepted, please check</p>';
        }elseif($data['status'] == 4){
            $msgData .= '<p>Your job has been partly closed, please check</p>';
        }
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        '.$msgData.'
                        <p>Thank You!</p>
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendTranslationJobStatusMail($id,$data){
        $jobData = $this->db->get_where('translation_request_job',array('id'=>$id))->row();
        $pmMail = $this->db->get_where('users',array('id'=>$jobData->created_by))->row()->email;
        $mailTo = $this->db->get_where('users',array('id'=>$jobData->translator))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
        $msgData = "";
        $subject = "Translation Job";

        if($data['status'] == 2){
            $msgData .= '<p>Your Job has been Closed, please check.</p>';
        }elseif($data['status'] == 0){
            $msgData .= '<p>You have assigned to a new job, please check.</p>';
        }elseif($data['status'] == 3){
            $msgData .= '<p>Your job has been rejected, please check</p>';
        }elseif($data['status'] == 1){
            $msgData .= '<p>Your job has been accepted, please check</p>';
        }elseif($data['status'] == 4){
            $msgData .= '<p>Your job has been partly closed, please check</p>';
        }
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        '.$msgData.'
                        <p>Thank You!</p>
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendLEReOpenRequestMail($id){
        $requestData = $this->db->get_where('le_request',array('id'=>$id))->row();
        $mailTo = "le@thetranslationgate.com";
        $pmMail = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
        $msgData = "";
        $subject = "Re-opened LE Request # LE-".$id." - ".$requestData->subject;
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        Your request has been re-opened again, please check ..
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendTranslationReOpenRequestMail($id){
        $requestData = $this->db->get_where('translation_request',array('id'=>$id))->row();
        $mailTo = "translation.allocator@thetranslationgate.com";
        $pmMail = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
        $msgData = "";
        $subject = "Re-opened Translation Request # Translation-".$id." - ".$requestData->subject;
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        Your request has been re-opened again, please check ..
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendDTPReOpenRequestMail($id){
        $requestData = $this->db->get_where('dtp_request',array('id'=>$id))->row();
        if($this->brand == 2){
           $mailTo = "maged.kamel@dtpzone.com";
        }else{
           $mailTo = "dtp@thetranslationgate.com";
        }
        $pmMail = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
        $msgData = "";
        $subject = "Re-opened DTP Request # DTP-".$id." - ".$requestData->subject;
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        Your request has been re-opened again, please check ..
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }
    ///late vpos 
   public function jobsWithoutTasks($brand)
       {
         $data = $this->db->query(" SELECT j.*,(SELECT brand FROM users WHERE j.created_by = users.id) AS brand,(SELECT count(*) from job_task where job_task.job_id = j.id) AS tasks,(SELECT COUNT(*) FROM translation_request WHERE j.id = translation_request.job_id) AS translation,(SELECT COUNT(*) FROM dtp_request WHERE j.id = dtp_request.job_id) AS dtp from job AS j WHERE j.project_id > 0 AND j.status = '1' HAVING brand = '$brand' ORDER BY id ASC");

        return $data;
        }
    //
    public function AllDTPFreeLance($task_type,$brand,$filter)
    {
			
        $data = $this->db->query(" SELECT *,(SELECT brand FROM users WHERE users.id = job_task.created_by) AS brand FROM `job_task` WHERE task_type IN ('$task_type') AND ".$filter." HAVING brand = '$brand' ORDER BY id DESC ");
        return $data;
    }

    public function AllDTPFreeLancePages($task_type,$brand,$limit,$offset)
    {
        $data = $this->db->query("SELECT *,(SELECT brand FROM users WHERE users.id = job_task.created_by) AS brand FROM `job_task` WHERE task_type IN ('$task_type') HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

	public function sendTranslationCancelRequestMail($id){
        $requestData = $this->db->get_where('translation_request',array('id'=>$id))->row();
        $mailTo = "translation.allocator@thetranslationgate.com";
        $pmMail = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
        $msgData = "";
        $subject = "Re-opened Translation Request # Translation-".$id." - ".$requestData->subject;
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        Your request has been Cancelled ..
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function sendDTPCancelRequestMail($id){
        $requestData = $this->db->get_where('dtp_request',array('id'=>$id))->row();
        if($this->brand == 2){
           $mailTo = "maged.kamel@dtpzone.com";
        }else{
           $mailTo = "dtp@thetranslationgate.com";
        }
        $pmMail = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
        $msgData = "";
        $subject = "Cancelled DTP Request # DTP - ".$id." - ".$requestData->subject;
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        Your request has been Cancelled ..
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

    public function sendLECancelRequestMail($id){
        $requestData = $this->db->get_where('le_request',array('id'=>$id))->row();
        $mailTo = "le@thetranslationgate.com";
        $pmMail = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$pmMail."\r\n";
        $headers .= 'From: '.$pmMail."\r\n";
        $msgData = "";
        $subject = "Cancelled DTP Request # DTP - ".$id." - ".$requestData->subject;
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        Your request has been Cancelled ..
                    </body>
                    </html>';
         // echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }

	public function getAssignedSam($lead){
    	$query = $this->db->query("SELECT GROUP_CONCAT(sam SEPARATOR ',') AS sam FROM `customer_sam` WHERE lead = '$lead' ")->row();
    	return $query->sam;
    } 

     public function sendTranslationCommentByMail($id,$mailTO,$comment){
        $requestData = $this->db->get_where('translation_request',array('id'=>$id))->row();
        $mailTo = $mailTO;
        $mailFrom = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$mailFrom."\r\n";
        $headers .= 'From: '.$mailFrom."\r\n";
        $msgData = "";
        $subject = "Comment On Translation Request".$id." - ".$requestData->subject;
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                       '.$comment.'</br>
                       <a href="'.base_url().'projects/translationTask?t='.base64_encode($id).'" class="">
                          <i class="fa fa-eye"></i> View Task
                        </a>
                    </body>
                    </html>';
         
      mail($mailTo,$subject,$message,$headers);
    }
  
   public function sendTranslationCommentBtweenTeamByMail($id,$comment){
        $requestData = $this->db->get_where('translation_request_job',array('id'=>$id))->row();
       $role = $this->db->get_where('users',array('id'=>$this->user))->row()->role;
          if($role == 28){
            //sender is allocator 
              $mailTo = $this->db->get_where('users',array('id'=>$requestData->translator))->row()->email;
              $mailFrom = "translation.allocator@thetranslationgate.com";
          }elseif ($role = 27){
            //sender is translator
              $mailTo = "translation.allocator@thetranslationgate.com";
              $mailFrom = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
          }

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$mailFrom."\r\n";
        $headers .= 'From: '.$mailFrom."\r\n";
        $msgData = "";
        $subject = "Comment On Translation Job";
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                       '.$comment.'</br>
                       <a href="'.base_url().'translation/viewTranslatorTask?t='.base64_encode($id).'" class="">
                          <i class="fa fa-eye"></i> View Task
                        </a>
                    </body>
                    </html>';
        
      mail($mailTo,$subject,$message,$headers);
  }

public function sendLeCommentByMail($id,$comment,$flag){
        $requestData = $this->db->get_where('le_request',array('id'=>$id))->row();
           if($flag == 1){
                //from Le
               $mailTo = $this->db->get_where('users',array('id'=>$requestData->created_by))->row()->email;
            }elseif($flag == 2) {
                //from pm
             // $mailTo = $this->db->get_where('users',array('id'=>$requestData->status_by))->row()->email;  
               $mailTo = "le@thetranslationgate.com";      
               }
        $mailFrom = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$mailFrom."\r\n";
        $headers .= 'From: '.$mailFrom."\r\n";
        $msgData = "";
        $subject = "Comment On Translation Request".$id;
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                       '.$comment.'</br>
                       <a href="'.base_url().'projects/leTask?t='.base64_encode($id).'" class="">
                          <i class="fa fa-eye"></i> View Task
                        </a>
                    </body>
                    </html>';
         
      mail($mailTo,$subject,$message,$headers);
    } 
    public function sendDtpCommentByMail($id,$comment,$flag){
        $requestData = $this->db->get_where('dtp_request',array('id'=>$id))->row();
           if($flag == 1){
                //from Dtp
               $mailTo = $this->db->get_where('users',array('id'=>$requestData->created_by))->row()->email;
            }elseif($flag == 2) {
                //from pm
             // $mailTo = $this->db->get_where('users',array('id'=>$requestData->status_by))->row()->email;      
              $mailTo = "dtp@thetranslationgate.com";  
               }
        $mailFrom = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: ".$mailFrom."\r\n";
        $headers .= 'From: '.$mailFrom."\r\n";
        $msgData = "";
        $subject = "Comment On Translation Request".$id;
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                       '.$comment.'</br>
                       <a href="'.base_url().'projects/dTPTask?t='.base64_encode($id).'" class="">
                          <i class="fa fa-eye"></i> View Task
                        </a>
                    </body>
                    </html>';
         
      mail($mailTo,$subject,$message,$headers);
    } 
    
   // calculate rate for le request
  public function calculateLeRequestRate($task_type,$linguist,$deliverable,$complexicty,$volume){
     $complexictyValue = $this->db->query("SELECT * FROM le_request_amount WHERE task_type = '$task_type' AND linguist_format = '$linguist' AND deliverable_format = '$deliverable'")->row(); 
    if($complexicty == 1) {
          $rate = $complexictyValue->complexicty_low * $volume;
    }elseif ($complexicty == 2) {
          $rate = $complexictyValue->complexicty_mid * $volume;
    }elseif ($complexicty == 3) { 
          $rate = $complexictyValue->complexicty_high * $volume;
    } 
    return $rate;
    } 

    ///get le complexicty
    public function getLeComplexicty($id){
        if($id == 1){
            echo 'Low';
        }elseif($id == 2){
            echo 'Mid';
        }elseif($id == 3){
            echo 'High';
        }
    }
    ///get le complexicty value
  public function getLeComplexictyValue($task_type,$linguist,$deliverable,$complexicty,$volume){
     $complexictyValue = $this->db->query("SELECT * FROM le_request_amount WHERE task_type = '$task_type' AND linguist_format = '$linguist' AND deliverable_format = '$deliverable'")->row(); 
    if($complexicty == 1) {
          $complexicty_value = $complexictyValue->complexicty_low ;
    }elseif ($complexicty == 2) {
          $complexicty_value = $complexictyValue->complexicty_mid ;
    }elseif ($complexicty == 3) { 
          $complexicty_value = $complexictyValue->complexicty_high ;
    } 
    return $complexicty_value;
    }

	public function getJobsRevenue($pm,$date_from,$date_to){
    	$total=0;
    	$jobs = $this->db->query("SELECT j.id,j.type,j.volume,j.code,j.closed_date,j.price_list FROM job AS j 
										WHERE j.created_by = '$pm' AND j.status = '1' AND j.closed_date BETWEEN '$date_from' AND '$date_to'");
    	foreach($jobs->result() as $job){
        	$priceList = $this->projects_model->getJobPriceListData($job->price_list);
        	$revenue = $this->sales_model->calculateRevenueJob($job->id,$job->type,$job->volume,$priceList->id);
        	$total_revenue = $this->accounting_model->transfareTotalToCurrencyRate($priceList->currency,2,$job->closed_date,$revenue);
        	$total = $total + $total_revenue;
        }
    	$data['total'] = $total;
    	$data['jobsNum'] = $jobs->num_rows();
    	return $data;
    }

	public function getTotalCost($pm,$date_from,$date_to){
    	$this->db->query("SET SESSION group_concat_max_len = 100000000000;");
    	$jobs = $this->db->query(" SELECT GROUP_CONCAT(j.id SEPARATOR ',') AS jobs FROM job AS j 
									WHERE j.created_by = '$pm' AND j.status = '1' AND j.closed_date BETWEEN '$date_from' AND '$date_to' ")->row()->jobs; 
    	if($jobs == NULL){$jobs=0;}
    	$tasks = $this->db->query(" SELECT * FROM `job_task` WHERE status = '1' AND job_id IN (".$jobs.") ")->result();
    	$totalCost=0;
        	foreach($tasks as $task){
            	$taskCost = $task->rate * $task->count;
            	$totalCostUSD =  $this->accounting_model->transfareTotalToCurrencyRate($task->currency,2,$task->closed_date,$taskCost);
            	$totalCost = $totalCost + $totalCostUSD;
            }
    	return $totalCost;
    }

	public function getTotalCostByCustomer($customer,$date_from,$date_to){
    	$this->db->query("SET SESSION group_concat_max_len = 100000000000;");
    	$jobs = $this->db->query(" SELECT GROUP_CONCAT(j.id SEPARATOR ',') AS jobs FROM job AS j LEFT OUTER JOIN project AS p ON p.id = j.project_id 
        							WHERE j.status = '1' AND p.customer = '$customer' AND j.closed_date BETWEEN '$date_from' AND '$date_to' ")->row()->jobs;
    	if($jobs == NULL){$jobs=0;}
    	$tasks = $this->db->query(" SELECT * FROM `job_task` WHERE status = '1' AND job_id IN (".$jobs.") ")->result();
    	$totalCost=0;
    	foreach($tasks as $task){
    	$taskCost = $task->rate * $task->count;
    	$totalCostUSD =  $this->accounting_model->transfareTotalToCurrencyRate($task->currency,2,$task->closed_date,$taskCost);
    	$totalCost = $totalCost + $totalCostUSD;
    	}
    	return $totalCost;
    }

      public function selectPmEmployeeId($id="",$brand=""){
        // $pm = $this->db->get_where('users',array('role'=>2,'brand'=>$brand))->result();
        $pm = $this->db->query(" SELECT * FROM users WHERE (role = '2' OR role = '29' OR role = '16') AND brand = '$this->brand' AND status = '1' ")->result();
        foreach ($pm as $pm) {
            if ($pm->id == $id) {
                $data .= "<option value='" . $pm->employees_id . "' selected='selected'>" . $pm->user_name . "</option>";
            } else {
                $data .= "<option value='" . $pm->employees_id . "'>" . $pm->user_name . "</option>";
            }
        }
        return $data;
    }


        public function AllPMOCustomer($permission,$user,$brand,$filter)
   {

        $data = $this->db->query(" SELECT * FROM `customer` WHERE ".$filter." HAVING brand = '$brand' ORDER BY id ASC");
        return $data;
    }

	public function creditNote($permission,$user,$brand,$filter)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT c.*,p.number,p.created_by AS pm,(SELECT brand FROM customer WHERE customer.id = c.customer) AS brand
        							FROM credit_note AS c LEFT OUTER JOIN po AS p ON p.id = c.po
            							WHERE ".$filter." AND (type = 4 OR type = 1) HAVING brand = '$brand' order by id desc ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT c.*,p.number,p.created_by AS pm,(SELECT brand FROM customer WHERE customer.id = c.customer) AS brand
        							FROM credit_note AS c LEFT OUTER JOIN po AS p ON p.id = c.po
            						WHERE ".$filter." AND (type = 4 OR type = 1) AND p.created_by = '$user' HAVING brand = '$brand' order by id desc ");
        }
        return $data;
    }

    public function creditNotePages($permission,$user,$brand,$limit,$offset)
    {
        if($permission->view == 1){
            $data = $this->db->query(" SELECT c.*,p.number,p.created_by AS pm,(SELECT brand FROM customer WHERE customer.id = c.customer) AS brand
        							FROM credit_note AS c LEFT OUTER JOIN po AS p ON p.id = c.po
									WHERE (type = 4 OR type = 1) HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query("SELECT c.*,p.number,p.created_by AS pm,(SELECT brand FROM customer WHERE customer.id = c.customer) AS brand
        							FROM credit_note AS c LEFT OUTER JOIN po AS p ON p.id = c.po
									 WHERE p.created_by = '$user' AND (type = 4 OR type = 1) HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }
        return $data;
    }

    //pm conversion request
     public function AllPmConversionRequest($permission,$user,$brand,$filter)
    {
        
        if($permission->view == 1){
            $data = $this->db->query(" SELECT * FROM `pm_conversion_request` WHERE brand = '$brand' AND ".$filter." ORDER BY id DESC ");
        }elseif($permission->view == 2){
           $data = $this->db->query(" SELECT * FROM `pm_conversion_request` WHERE brand = '$brand' AND created_by ='$user' AND ".$filter." ORDER BY id DESC ");
       }
        return $data;

    }

    public function AllPmConversionRequestPages($permission,$user,$brand,$limit,$offset)
    {  
         if($permission->view == 1){
            $data = $this->db->query(" SELECT * FROM `pm_conversion_request` WHERE brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT * FROM `pm_conversion_request` WHERE brand = '$brand' AND created_by ='$user' ORDER BY id DESC LIMIT $limit OFFSET $offset");
        }
        return $data;
    }
 public function getConversionTaskType($task_type){
        $result = $this->db->get_where('pm_conversion_task_type',array('id' => $task_type))->row();
        if(isset($result->name)){
            return $result->name;
        }else{
            return '';
        }
    }

        public function selectConversionTaskType($id="")
    {
        $task_type = $this->db->get('pm_conversion_task_type')->result();
        $data = "";
        foreach ($task_type as $task_type) {
            if ($task_type->id == $id) {
                $data .= "<option value='" . $task_type->id . "' selected='selected'>" . $task_type->name . "</option>";
            } else {
                $data .= "<option value='" . $task_type->id . "'>" . $task_type->name . "</option>";
            }
        }
        return $data;
    }

	public function sendUpdateMail($data,$id){
        $requestData = $this->db->get_where('pm_conversion_request',array('id'=>$id))->row();
        $mailTo = $this->db->get_where('users',array('id'=>$requestData->created_by))->row()->email;
    	//$mailTo = "mohamed.elshehaby@thetranslationgate.com";  
        $mailFrom = "le-conversion@thetranslationgate.com";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: mohamed.elshehaby@thetranslationgate.com"."\r\n";
        $headers .= 'From: '.$mailFrom."\r\n";
        $msgData = "";
        $subject = "Conversion Request Updated: ".$id;
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                       Hi,
                       </br>
                       Your Request has been updated please check the status.
                       </br>
                       <a href="'.base_url().'projects/viewPmConversionRequest?t='.base64_encode($id).'" class="">
                          <i class="fa fa-eye"></i> View Task
                        </a>
                    </body>
                    </html>';
         
      mail($mailTo,$subject,$message,$headers);
    } 
    //

    ///latedelevery job mail 
    public function sendLateDeliveryJobsMail($file){
    	$config = Array(
        'protocol' => 'smtp',
        'smtp_host' => 'mail.thetranslationgate.com',
        'smtp_port' => 465,
        'smtp_user' => 'falaqsystem@thetranslationgate.com',
        'smtp_pass' => 'GaU6FjtJ$*Hb8P-j',
        'charset'=>'utf-8',
         'validate'=>TRUE,
        'wordwrap'=> TRUE,
      );
      $this->load->library('email', $config);
      $this->email->set_newline("\r\n");
      $fileName= base_url().'assets/uploads/late_delivery_daily_report/'.$file;
      $this->email->attach($fileName);
      $this->email->from("falaqsystem@thetranslationgate.com");
      $this->email->to("tarek.seif@thetranslationgate.com");
      $this->email->cc("mohamed.elshehaby@thetranslationgate.com");
      $this->email->subject("Late Delivery Jobs - ".date("Y-m-d H:i:s"));  
      $message = '<!DOCTYPE ><html dir=ltr>
                    <head>
                    </head>
					<body>
                    <p>Hi Tarek,</p>
                    <p>Kindly find attached file with a list of the undelivered jobs.</p>
                    <p>Thank You!</p>
                    </body>
                    </html>';
    	$this->email->message($message);
      	$this->email->set_header('Reply-To', "mohamed.elshehaby@thetranslationgate.com");
      	$this->email->set_mailtype('html');
      	$this->email->send();
    }

	public function activeCustomersDaily($file){
    	$config = Array(
        'protocol' => 'smtp',
        'smtp_host' => 'mail.thetranslationgate.com',
        'smtp_port' => 465,
        'smtp_user' => 'falaqsystem@thetranslationgate.com',
        'smtp_pass' => 'GaU6FjtJ$*Hb8P-j',
        'charset'=>'utf-8',
         'validate'=>TRUE,
        'wordwrap'=> TRUE,
      );
      $this->load->library('email', $config);
      $this->email->set_newline("\r\n");
      $fileName= base_url().'assets/uploads/active_customers_report/'.$file;
      $this->email->attach($fileName);
      $this->email->from("falaqsystem@thetranslationgate.com");
      $this->email->to("mohammad@thetranslationgate.com, shehab@thetranslationgate.com, sam-spocs@thetranslationgate.com, zeinab.moustafa@thetranslationgate.com");
      $this->email->cc("dev@thetranslationgate.com");
      $this->email->subject("Daily Active Customers");  
      $message = '<!DOCTYPE ><html dir=ltr>
                    <head>
                    </head>
					<body>
                    <p>Hi,</p>
                    <p>Kindly find the attached file with a list of the active customers for the jobs added to the system yesterday.</p>
                    <p>Thank You!</p>
                    </body>
                    </html>';
    	$this->email->message($message);
      	$this->email->set_header('Reply-To', "dev@thetranslationgate.com");
      	$this->email->set_mailtype('html');
      	$this->email->send();
    }

	public function activeCustomersWeekly($file){
    	$config = Array(
        'protocol' => 'smtp',
        'smtp_host' => 'mail.thetranslationgate.com',
        'smtp_port' => 465,
        'smtp_user' => 'falaqsystem@thetranslationgate.com',
        'smtp_pass' => 'GaU6FjtJ$*Hb8P-j',
        'charset'=>'utf-8',
         'validate'=>TRUE,
        'wordwrap'=> TRUE,
      );
      $date = date("Y-m-d");
      $week_date = date("Y-m-d",strtotime("-7 days"));
      $this->load->library('email', $config);
      $this->email->set_newline("\r\n");
      $fileName= base_url().'assets/uploads/active_customers_report/'.$file;
      $this->email->attach($fileName);
      $this->email->from("falaqsystem@thetranslationgate.com");
      $this->email->to("mohammad@thetranslationgate.com, shehab@thetranslationgate.com, sam-spocs@thetranslationgate.com, zeinab.moustafa@thetranslationgate.com");
      $this->email->cc("dev@thetranslationgate.com");
      $this->email->subject("Weekly Active Customers");  
      $message = '<!DOCTYPE ><html dir=ltr>
                    <head>
                    </head>
					<body>
                    <p>Hi,</p>
                    <p>Kindly find the attached file with a list of the active customers for the jobs added to the system from '.$week_date.' to '.$date.' </p>
                    <p>Thank You!</p>
                    </body>
                    </html>';
    	$this->email->message($message);
      	$this->email->set_header('Reply-To', "dev@thetranslationgate.com");
      	$this->email->set_mailtype('html');
      	$this->email->send();
    }

	public function activeCustomersMonthly($file){
    	$config = Array(
        'protocol' => 'smtp',
        'smtp_host' => 'mail.thetranslationgate.com',
        'smtp_port' => 465,
        'smtp_user' => 'falaqsystem@thetranslationgate.com',
        'smtp_pass' => 'GaU6FjtJ$*Hb8P-j',
        'charset'=>'utf-8',
         'validate'=>TRUE,
        'wordwrap'=> TRUE,
      );
      $date = date("Y-m-d");
      $month_date = date("Y-m-d",strtotime("-1 month"));
      $this->load->library('email', $config);
      $this->email->set_newline("\r\n");
      $fileName= base_url().'assets/uploads/active_customers_report/'.$file;
      $this->email->attach($fileName);
      $this->email->from("falaqsystem@thetranslationgate.com");
      $this->email->to("mohammad@thetranslationgate.com, shehab@thetranslationgate.com, sam-spocs@thetranslationgate.com, zeinab.moustafa@thetranslationgate.com");
      $this->email->cc("dev@thetranslationgate.com");
      $this->email->subject("Monthly Active Customers");  
      $message = '<!DOCTYPE ><html dir=ltr>
                    <head>
                    </head>
					<body>
                    <p>Hi,</p>
                    <p>Kindly find the attached file with a list of the active customers for the jobs added to the system from '.$month_date.' to '.$date.' </p>
                    <p>Thank You!</p>
                    </body>
                    </html>';
    	$this->email->message($message);
      	$this->email->set_header('Reply-To', "dev@thetranslationgate.com");
      	$this->email->set_mailtype('html');
      	$this->email->send();
    }
    //

    //customer emails for customer feedback
    public function selectCustomerEmails($id="")
      {
        $emails = $this->db->get('customer_email')->result();
        $data = "";
        foreach ($emails as $emails) {
          if ($emails->id == $id) {
            $data .= "<option value='" . $emails->email . "' selected='selected'>" . $emails->email . "</option>";
          } else {
            $data .= "<option value='" . $emails->email . "'>" . $emails->email . "</option>";
          }
        }
        return $data;
      }
    //
	public function selectCommission($id="",$brand=""){
        $commission = $this->db->get_where('commission',array('brand'=>$brand))->result();
        foreach ($commission as $commission) {
            if ($commission->id == $id) {
                $data .= "<option value='" . $commission->id . "' selected='selected'>" . $commission->name . "</option>";
            } else {
                $data .= "<option value='" . $commission->id . "'>" . $commission->name . "</option>";
            }
        }
        return $data;
    }

	public function getCommissionName($id){
        $result = $this->db->get_where('commission',array('id' => $id))->row();
        if(isset($result->name)){
            return $result->name;
        }else{
            return '';
        }
    }

	public function getCommissionEmail($id){
        $result = $this->db->get_where('commission',array('id' => $id))->row();
        if(isset($result->email)){
            return $result->email;
        }else{
            return '';
        }
    }

	public function selectDTPAllocator($id="")
	{
		$dtp = $this->db->get_where('users',array('role'=>24,'brand'=>$this->brand))->result();
      	$data = "";
		foreach ($dtp as $dtp) {
			if ($dtp->id == $id) {
				$data .= "<option value='" . $dtp->id . "' selected='selected'>" . $dtp->user_name . "</option>";
			} else {
				$data .= "<option value='" . $dtp->id . "'>" . $dtp->user_name . "</option>";
			}
		}
		return $data;
	}

  public function AllHandover($permission,$user,$filter){
      if($permission->view == 1){
            $data = $this->db->query("SELECT * FROM `handover` WHERE ".$filter." ORDER BY id DESC ");
        }elseif($permission->view == 2){
        $data = $this->db->query(" SELECT * FROM `handover` WHERE created_by ='$user' AND ".$filter." ORDER BY id DESC ");
       }
        return $data;
    } 
    public function AllHandoverPages($permission,$user,$limit,$offset){
         if($permission->view == 1){
            $data = $this->db->query(" SELECT * FROM `handover` ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT * FROM `handover` WHERE created_by ='$user' ORDER BY id DESC LIMIT $limit OFFSET $offset");
        }
        return $data;
    }
}
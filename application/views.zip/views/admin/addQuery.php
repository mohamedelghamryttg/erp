<!DOCTYPE html>
<html>
<head>
	<title>Query</title>
</head>
<body>
<form method="post" action="<?=base_url()?>admin/doAddQuery">
	<textarea rows="30" cols="70" name="query"></textarea>
	<input type="submit" name="save" value="save">
</form>
</body>
</html>
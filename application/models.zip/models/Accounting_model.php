<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Auth
*
* Author:  MOHAMED EL-SHEHABY
*
*/

class Accounting_model extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

// 	public function AllCpo($brand,$filter)
// 	{
// 		$data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `project` AS p WHERE p.status = 1 AND p.verified = 0 AND ".$filter." HAVING brand = '$brand' ORDER BY p.closed_date DESC ");
// 		return $data;
// 	}

// 	public function AllCpoPages($brand,$limit,$offset)
// 	{
// 		$data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `project` AS p WHERE p.status = 1 AND p.verified = 0  HAVING brand = '$brand' ORDER BY p.closed_date DESC LIMIT $limit OFFSET $offset ");
// 		return $data;
// 	}
	
	public function AllCpo($brand,$filter)
    {
        $data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `po` AS p WHERE p.verified = 0 AND ".$filter." HAVING brand = '$brand' ORDER BY p.created_at DESC ");
        return $data;
    }

    public function AllCpoPages($brand,$limit,$offset)
    {
        $data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `po` AS p WHERE p.verified = 0  HAVING brand = '$brand' ORDER BY p.created_at DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

  	public function AllInvoices($brand,$filter)
	{
		$data = $this->db->query(" SELECT v.*,(SELECT brand FROM customer WHERE customer.id = v.customer) AS brand FROM `invoices` AS v WHERE ".$filter." HAVING brand = '$brand' ORDER BY id DESC ");
		return $data;
	}

	public function AllInvoicesPages($brand,$limit,$offset)
	{
		$data = $this->db->query(" SELECT v.*,(SELECT brand FROM customer WHERE customer.id = v.customer) AS brand FROM `invoices` AS v HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
		return $data;
	}
  
  	public function getVirifiedPoByCustomer($id,$lead){
        $row = $this->db->query(" SELECT * FROM `po` WHERE lead = '$lead' AND verified = '1' AND invoiced <> 1 ")->result();

        $data = '<table class="table table-striped table-hover table-bordered" style="overflow:scroll;">
                    <thead>
                        <tr>
                            <th>Choose</th>
                            <th>PO Number</th>
                            <th>Currency</th>
                            <th>Total Revenue</th>
                        </tr>
                    </thead>
                    <tbody>';
        foreach ($row as $row) {
            $job_data = $this->projects_model->totalRevenuePO($row->id);
            if($id == $row->id){$checked='checked="checked"';}else{$checked="";}
                    $data.=  '<tr class="">
                            <td><input type="checkbox" name="projects[]" id="projects" onclick="getInvoiceTotal();" class="pos" value="'.$row->id.'" '.$checked.' title="'.$job_data['total'].'"></td>
                            <td>'.$row->number.'</td>
                            <td>'.$this->admin_model->getCurrency($job_data['currency']).'</td>
                            <td>'.$job_data['total'].'</td>
                        </tr>';
        }
        $data .= '</tbody></table>';
        echo $data;
    }
  
  	public function getPaymentData($customer=0,$issue_date=""){
		$payment = $this->db->get_where('customer',array('id'=>$customer))->row()->payment;
		$dueDate = date( "Y-m-d", strtotime( $issue_date." +".$payment." days" ) );

		$data = '<table class="table table-striped table-hover table-bordered" style="overflow:scroll;">
                    <thead>
                        <tr>
                            <th>Payment Days</th>
                            <th>Due Date</th>
                        </tr>
                    </thead>
        
                    <tbody>
                        <tr class="">
                        	<input type="text" id="payment" name="payment" value="'.$payment.'" hidden="">
                            <td>'.$payment.'</td>
                            <td>'.$dueDate.'</td>
                        </tr>
                    </tbody>
                </table>';
        echo $data;
	}
  
  	public function getSelectedPOs($po_ids=0){
        $data = $this->db->query(" SELECT GROUP_CONCAT(number SEPARATOR ',') AS poNumber FROM po WHERE id IN (".$po_ids.") ")->row()->poNumber;
        return $data;
    }
  
  	public function getInvoiceCurrency($po_ids){
		$price_list = $this->db->query(" SELECT * FROM job WHERE po IN (".$po_ids.") ")->row()->price_list;
		$data = $this->db->get_where('job_price_list',array('id'=>$price_list))->row()->currency;
		return $data;
	}
  
  	public function getInvoiceTotal($po_ids){
		$id = explode(",", $po_ids);
		$all=0;
		for ($i=0; $i < count($id); $i++) { 
			$total = $this->projects_model->totalRevenuePO($id[$i]);
			$all = $all + $total['total'];
		}
		return $all;
	}
  
  	public function getInvoiceStatus($status,$issue_date,$payment){
		if($status == 0){
			$dueDate = date( "Y-m-d", strtotime( $issue_date." +".$payment." days" ) );
			if($dueDate > date("Y-m-d")){
				echo "Due";
			}else{
				echo "Overdue";
			}
		}elseif ($status == 1) {
			echo "Paid";
		}else{
			echo "";
		}
	}
  
  	public function AllPayments($brand,$filter)
	{
		$data = $this->db->query(" SELECT v.*,(SELECT brand FROM customer WHERE customer.id = v.customer) AS brand FROM `payment` AS v WHERE ".$filter." HAVING brand = '$brand' ORDER BY id DESC ");
		return $data;
	}

	public function AllPaymentsPages($brand,$limit,$offset)
	{
		$data = $this->db->query(" SELECT v.*,(SELECT brand FROM customer WHERE customer.id = v.customer) AS brand FROM `payment` AS v HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
		return $data;
	}
  
  	public function getClientInvoices($id,$lead){
		$row = $this->db->get_where('invoices',array('status'=>0,'lead'=>$lead))->result();
      	$data = '<table class="table table-striped table-hover table-bordered" style="overflow:scroll;">
                    <thead>
                        <tr>
                            <th>Choose</th>
                            <th>Invoice Number</th>
                            <th>PO Number</th>
                            <th>Currency</th>
                            <th>Total Revenue</th>
                            <th>Issue Date</th>
                            <th>Difference</th>
                            <th>Reason</th>
                        </tr>
                    </thead>
                    <tbody>';
      				$x=1;
        foreach ($row as $row) {
            if($id == $row->id){$checked='checked="checked"';}else{$checked="";}
                    $data.=  '<tr class="">
                            <td><input type="checkbox" name="invoices[]" onclick="getPymentTotal();" class="invoices" id="'.$x.'" value="'.$row->id.'" '.$checked.' title="'.$this->accounting_model->getInvoiceTotal($row->project_ids).'"></td>
                            <td>'.$row->id.'</td>
                            <td>'.$this->accounting_model->getSelectedPOs($row->project_ids).'</td>
			                <td>'.$this->admin_model->getCurrency($this->accounting_model->getInvoiceCurrency($row->project_ids)).'</td>
			                <td>'.$this->accounting_model->getInvoiceTotal($row->project_ids).'</td>
			                <td>'.$row->issue_date.'</td>
			                <td><input type="text" name="diff_'.$x.'" id="diff_'.$x.'" onblur="getPymentTotal();" onkeypress="return rateCode(event)" value="0"></td>
			                <td></td>
                        </tr>';
                        $x++;
        }
        $data .= '</tbody></table>';
        echo $data;
	}

	public function getClientInvoicedPOs($id,$customer,$payment_date,$currencyTo){
        $paymentDateArray = explode("/", $payment_date);
        $year = $paymentDateArray[2];
        $month = $paymentDateArray[0];
        $row = $this->db->get_where('po',array('customer'=>$customer,'verified'=>1,'invoiced'=>1,'paid'=>0))->result();
        $data = '<table class="table table-striped table-hover table-bordered" style="overflow:scroll;">
                    <thead>
                        <tr>
                            <th>Choose</th>
                            <th>Invoice Number</th>
                            <th>PO Number</th>
                            <th>Currency</th>
                            <th>Total Revenue</th>
                            <th>Total Revenue ('.$this->admin_model->getCurrency($currencyTo).')</th>
                        </tr>
                    </thead>
                    <tbody>';
        $totalPosRevenue = 0;
        $totalPosRevenueMain = 0;
        foreach ($row as $row) {
            $InvoiceNumber = self::getInvoiceNumberByPoAndCustomer($row->id,$customer);
            $poData = $this->projects_model->totalRevenuePO($row->id);
            $totalPosRevenue = $totalPosRevenue + $poData['total'];
            if($poData['currency'] === $currencyTo){
                $totalPosRevenueMain = $totalPosRevenueMain + ($poData['total'] * 1);
                $poMainCurrency = $poData['total']*1;
            }else{
                $mainCurrencyData = $this->db->get_where('currenies_rate',array('year'=>$year,'month'=>$month,'currency'=>$poData['currency'],'currency_to'=>$currencyTo))->row();
                $totalPosRevenueMain = $totalPosRevenueMain + ($poData['total'] * $mainCurrencyData->rate);
                $poMainCurrency = $poData['total']*$mainCurrencyData->rate;
            }
            if($id == $row->id){$checked='checked="checked"';}else{$checked="";}
                    $data.=  '<tr class="">
                            <td><input type="checkbox" name="po[]" class="checkPoPayment" onclick="getPymentTotal()" value="'.$row->id.'" '.$checked.' title="'.$poMainCurrency.'"></td>
                            <td>'.$InvoiceNumber.'</td>
                            <td>'.$row->number.'</td>
                            <td>'.$this->admin_model->getCurrency($poData['currency']).'</td>
                            <td>'.$poData['total'].'</td>
                            <td>'.$poMainCurrency.'</td>
                        </tr>';
        }
        $data .= '<tr>
                    <td colspan="4">Total Payments</td>
                    <td>'.$totalPosRevenue.'</td>
                    <td>'.$totalPosRevenueMain.'</td>';
        $data .= '</tbody></table>';
        echo $data;
    }

    public function getAdvancedPayments($id,$customer,$currencyTo,$payment_date){
        $payment = $this->db->get_where('advanced_payment',array('customer'=>$customer,'used'=>0))->result();
        $data = '<table class="table table-striped table-hover table-bordered" style="overflow:scroll;">
                    <thead>
                        <tr>
                            <th>Choose</th>
                            <th>Advanced Payment Value</th>
                            <th>Currency</th>
                            <th>Total Value In ('.$this->admin_model->getCurrency($currencyTo).')</th>
                        </tr>
                    </thead>
                    <tbody>';
        foreach ($payment as $payment) {
            if($payment->currency == $currencyTo){
                $paymentValueCurrency = $payment->value*1;
            }else{
                $paymentDateArray = explode("/", $payment_date);
                $year = $paymentDateArray[2];
                $month = $paymentDateArray[0];
                $mainCurrencyData = $this->db->get_where('currenies_rate',array('year'=>$year,'month'=>$month,'currency'=>$payment->currency,'currency_to'=>$currencyTo))->row();
                $paymentValueCurrency = $payment->value*$mainCurrencyData->rate;
            }
            if($id == $payment->id){$checked='checked="checked"';}else{$checked="";}
                    $data.=  '<tr class="">
                            <td><input type="checkbox" name="payment[]" class="payment" onclick="getPymentTotal()" value="'.$payment->id.'" '.$checked.' title="'.$paymentValueCurrency.'"></td>
                            <td>'.$payment->value.'</td>
                            <td>'.$this->admin_model->getCurrency($payment->currency).'</td>
                            <td>'.$paymentValueCurrency.'</td>
                        </tr>';
        }

        echo $data;
    }

	public function getCreditNotePayment($id,$customer,$currencyTo,$payment_date){
        $payment = $this->db->get_where('credit_note',array('customer'=>$customer,'status'=>3,'paid'=>0))->result();
        $data = '<table class="table table-striped table-hover table-bordered" style="overflow:scroll;">
                    <thead>
                        <tr>
                            <th>Choose</th>
                            <th>Credit Note Value</th>
                            <th>Currency</th>
                            <th>Total Value In ('.$this->admin_model->getCurrency($currencyTo).')</th>
                        </tr>
                    </thead>
                    <tbody>';
        foreach ($payment as $payment) {
            if($payment->currency == $currencyTo){
                $paymentValueCurrency = $payment->amount*1;
            }else{
                $paymentDateArray = explode("/", $payment_date);
                $year = $paymentDateArray[2];
                $month = $paymentDateArray[0];
                $mainCurrencyData = $this->db->get_where('currenies_rate',array('year'=>$year,'month'=>$month,'currency'=>$payment->currency,'currency_to'=>$currencyTo))->row();
                $paymentValueCurrency = $payment->amount*$mainCurrencyData->rate;
            }
            if($id == $payment->id){$checked='checked="checked"';}else{$checked="";}
                    $data.=  '<tr class="">
                            <td><input type="checkbox" name="credit_note[]" class="creditNote" onclick="getPymentTotal();getTotalCreditNote()" value="'.$payment->id.'" '.$checked.' title="'.$paymentValueCurrency.'"></td>
                            <td>'.$payment->amount.'</td>
                            <td>'.$this->admin_model->getCurrency($payment->currency).'</td>
                            <td>'.$paymentValueCurrency.'</td>
                        </tr>';
        }

        echo $data;
    }

    public function getInvoiceNumberByPoAndCustomer($po,$customer){
        $invoiceData = $this->db->query(" SELECT * FROM `invoices` WHERE (PO_ids LIKE '%$po,%' OR po_ids LIKE '%,$po%' OR po_ids = '$po') AND customer = '$customer' ")->result();
        $invoiceNumber = "";
        foreach ($invoiceData as $invoiceData) {
            $poIdsArray = explode(",", $invoiceData->po_ids);
            if(in_array($po, $poIdsArray)){
                $invoiceNumber = $invoiceData->id;
            }else{

            }
        }
        return $invoiceNumber;
    }

    public function selectPaymentDeductions($select=""){
        if($select == 1){
            $selected1 = 'selected';
        }elseif ($select == 2) {
            $selected2 = 'selected';
        }
        elseif ($select == 3) {
            $selected3 = 'selected';
        }
        else{
            $selected1 = '';
            $selected2 = '';
            $selected3 = '';
        }

        $outpt = '<option value="1" '.$selected1.'>No Dudections</option>
                  <option value="2" '.$selected2.'>Fee</option>
                  <option value="3" '.$selected3.'>Early Payment</option>';
        return $outpt;
    }

    public function getPaymentDeductions($select=""){
        if($select == 1){
            echo "No Dudections";
        }elseif ($select == 2) {
            echo "Fee";
        }
        elseif ($select == 3) {
            echo "Early Payment";
        }
        else{
           echo "";
        }
    }
  
  	public function selectPaymentMethod($id=0,$brand=0)
    {
        $payment = $this->db->get_where('payment_method',array('brand'=>$brand))->result();
        $data = "";
        foreach ($payment as $payment) {
            if ($payment->id == $id) {
                $data .= "<option value='" . $payment->id . "' selected='selected'>" . $payment->name . "</option>";
            } else {
                $data .= "<option value='" . $payment->id . "'>" . $payment->name . "</option>";
            }
        }
        return $data;
    }
  
  	public function getPaymentMethod($id){
		$result = $this->db->get_where('payment_method',array('id' => $id))->row();
		if(isset($result->name)){
			return $result->name;
		}else{
			return '';
		}
	}
  
  	public function selectHasError($id=0)
	{
		$has_error = $this->db->get('has_error')->result();
		$data = "";
		$arr_id =  explode(",", $id);
		foreach ($has_error as $has_error) {
			if (in_array($has_error->id, $arr_id)) {
				$data .= "<option value='" . $has_error->id . "' selected='selected'>" . $has_error->name . "</option>";
			} else {
				$data .= "<option value='" . $has_error->id . "'>" . $has_error->name . "</option>";
			}
		}
		return $data;
	}
  
  	public function getError($id){
		$result = $this->db->get_where('has_error',array('id' => $id))->row();
		if(isset($result->name)){
			return $result->name;
		}else{
			return '';
		}
	}
  
  	public function getPOStatus($status){
		if($status == 1){
			echo "Verified";
		}else if($status == 2){
			echo "Has Error";
		}else{
			echo "";
		}
	}

	public function getPONumber($id){
        $result = $this->db->get_where('po',array('id'=>$id))->row();
        if(isset($result->number)){
            return $result->number;
        }else{
            return '';
        }
    }

	public function getPONumberID($number){
        $result = $this->db->get_where('po',array('number'=>$number,'verified'=>1))->row();
        if(isset($result->id)){
            return $result->id;
        }else{
            return '';
        }
    }
  
  	public function AllVPO($permission,$brand,$filter)
    {
    	$data = $this->db->query(" SELECT t.*,job.price_list,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand,job.status FROM job_task AS t
            LEFT OUTER JOIN job ON job.id = t.job_id
            LEFT OUTER JOIN po ON po.id = job.po
            WHERE ".$filter." AND t.status = '1' AND job.status = '1' AND (t.verified IS NULL OR t.verified = '0' OR t.verified = '2') AND po.verified = '1' HAVING brand = '$brand' ORDER BY t.id DESC ");  
        return $data;
    }

    public function AllVPOPages($permission,$brand,$limit,$offset)
    {
        $data = $this->db->query(" SELECT t.*,job.price_list,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand,job.status FROM job_task AS t
            LEFT OUTER JOIN job ON job.id = t.job_id
            LEFT OUTER JOIN po ON po.id = job.po
            WHERE t.status = '1' AND job.status = '1' AND (t.verified IS NULL OR t.verified = '0' OR t.verified = '2') AND po.verified = '1' HAVING brand = '$brand' ORDER BY t.id DESC LIMIT $limit OFFSET $offset ");  
        return $data;
    }
  
  	public function AllVPOVerified($permission,$brand,$filter)
    {
        $data = $this->db->query(" SELECT t.*,job.price_list,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand,job.status FROM job_task AS t
            LEFT OUTER JOIN job ON job.id = t.job_id
            WHERE ".$filter." AND t.status = '1' AND job.status = '1' AND (t.verified = 1) HAVING brand = '$brand' ORDER BY t.id DESC ");  
        return $data;
    }

    public function AllVPOVerifiedPages($permission,$brand,$limit,$offset)
    {
        $data = $this->db->query(" SELECT t.*,job.price_list,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand,job.status FROM job_task AS t
            LEFT OUTER JOIN job ON job.id = t.job_id
            WHERE t.status = '1' AND job.status = '1' AND (t.verified = 1) HAVING brand = '$brand' ORDER BY t.id DESC LIMIT $limit OFFSET $offset ");  
        return $data;
    }
  
  	public function AllVendorPayment($permission,$brand,$filter)
    {
    	$data = $this->db->query(" SELECT p.*,(SELECT brand FROM `users` WHERE users.id = p.created_by) AS brand,j.code,j.rate,j.count,j.unit,j.vendor FROM vendor_payment AS p LEFT OUTER JOIN job_task AS j ON j.id = p.task WHERE ".$filter." HAVING brand = '$brand' ORDER BY id DESC ");  
        return $data;
    }

    public function AllVendorPaymentPages($permission,$brand,$limit,$offset)
    {
        $data = $this->db->query(" SELECT p.*,(SELECT brand FROM `users` WHERE users.id = p.created_by) AS brand,j.code,j.rate,j.count,j.unit,j.vendor FROM vendor_payment AS p LEFT OUTER JOIN job_task AS j ON j.id = p.task HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");  
        return $data;
    }
  
  	public function getVendorVerifiedTasks($vendor){
    	$row = $this->db->query(" SELECT t.*,(SELECT COUNT(*) FROM `vendor_payment` WHERE vendor_payment.task = t.id) AS total,job.status
									FROM job_task AS t
                                    LEFT OUTER JOIN job ON job.id = t.job_id
									WHERE t.status = 1 AND job.status = '1' AND t.verified = 1 AND t.vendor = '$vendor' HAVING total = 0 ")->result();

    	$data = '<table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;">
                        <thead>
                            <tr>
                            	 <th></th>
                                 <th>Task Code</th>
                                 <th>Volume</th>
                                 <th>Unit</th>
                                 <th>Rate</th>
                                 <th>Total Payment</th>
                                 <th>Currency</th>
                            </tr>
                        </thead>                            
                        <tbody>';
                        foreach ($row as $row) {
                            $data .= '<tr class="">
                            	<td><input type="checkbox" class="checkPoPayment" name="task[]" id="task" value="'.$row->id.'"></td>
                                <td>'.$row->code.'</td>
                                <td>'.$row->count.'</td>
                                <td>'.$this->admin_model->getUnit($row->unit).'</td>
                                <td>'.$row->rate.'</td>
                                <td>'.$row->rate * $row->count.'</td>
                                <td>'.$this->admin_model->getCurrency($row->currency).'</td>
                            </tr>';
                        }
        $data .= '</tbody></table>';
        return $data;
    }
  
  	public function getVendorVerifiedTasksById($row){
        $data = '<table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;">
                        <thead>
                            <tr>
                                 <th></th>
                                 <th>Task Code</th>
                                 <th>Volume</th>
                                 <th>Unit</th>
                                 <th>Rate</th>
                                 <th>Total Payment</th>
                                 <th>Currency</th>
                            </tr>
                        </thead>                            
                        <tbody>';
                        $x = 1;
                            if($x == 1){$radio = "required";}else{$radio = "";}
                            $data .= '<tr class="">
                                <td><input type="radio" name="task" id="task" value="'.$row->id.'" '.$radio.' checked=""></td>
                                <td>'.$row->code.'</td>
                                <td>'.$row->count.'</td>
                                <td>'.$this->admin_model->getUnit($row->unit).'</td>
                                <td>'.$row->rate.'</td>
                                <td>'.$row->rate * $row->count.'</td>
                                <td>'.$this->admin_model->getCurrency($row->currency).'</td>
                            </tr>';
        $data .= '</tbody></table>';
        return $data;
    }
  
  	public function selectVendorPaymentStatus($select=""){
        if ($select == 1) {
            $selected2 = 'selected';
        }
        elseif ($select == 2) {
            $selected3 = 'selected';
        }
        else{
            $selected2 = '';
            $selected3 = '';
          }

        $outpt = '<option value="1" '.$selected2.'>Paid</option>
                  <option value="2" '.$selected3.'>Re-opened</option>
                  ';
        return $outpt;
    }

	public function AllRunningVPO($permission,$brand,$filter)
    {
        $data = $this->db->query(" SELECT t.*,job.price_list,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand,job.status AS jobStatus FROM job_task AS t
            LEFT OUTER JOIN job ON job.id = t.job_id
            LEFT OUTER JOIN po ON po.id = job.po
            WHERE ".$filter." AND po.verified <> '1' || po.verified IS NULL HAVING brand = '$brand' ORDER BY t.id DESC ");  
        return $data;
    }

    public function AllRunningVPOPages($permission,$brand,$limit,$offset)
    {
        $data = $this->db->query(" SELECT t.*,job.price_list,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand,job.status AS jobStatus FROM job_task AS t
            LEFT OUTER JOIN job ON job.id = t.job_id
            LEFT OUTER JOIN po ON po.id = job.po
            WHERE po.verified <> '1' || po.verified IS NULL HAVING brand = '$brand' ORDER BY t.id DESC LIMIT $limit OFFSET $offset ");  
        return $data;
    }

	public function vpoStatus($permission,$brand,$filter)
    {
        $data = $this->db->query(" SELECT t.*,p.payment_method,p.status AS payment_status,p.payment_date AS payment_date,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand FROM `job_task` AS t
            LEFT OUTER JOIN vendor_payment AS p ON p.task = t.id
            WHERE ".$filter." HAVING brand = '$brand' ORDER BY t.id DESC ");  
        return $data;
    }

    public function vpoStatusPages($permission,$brand,$limit,$offset)
    {
        $data = $this->db->query(" SELECT t.*,p.payment_method,p.status AS payment_status,p.payment_date AS payment_date,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand FROM `job_task` AS t
            LEFT OUTER JOIN vendor_payment AS p ON p.task = t.id
            HAVING brand = '$brand' ORDER BY t.id DESC LIMIT $limit OFFSET $offset ");  
        return $data;
    
     }

	public function cpoStatus($brand,$filter)
    {
        $data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `po` AS p WHERE ".$filter." HAVING brand = '$brand' ORDER BY p.created_by DESC ");
        return $data;
    }

    public function cpoStatusPages($brand,$limit,$offset)
    {
        $data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `po` AS p  HAVING brand = '$brand' ORDER BY p.created_by DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

	public function sendPoRejectionMail($poId){
        $po = $this->db->get_where('po',array('id'=>$poId))->row();
        $subject = "PO Rejection Email : # ".$po->number;

        $userData = $this->admin_model->getUserData($po->created_by);
        $MailTo = $userData->email;
    
    	$mailFrom = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        
        if($this->brand == 1){
            $headers .= "Cc: ".$mailFrom. "\r\n";
            $headers .= 'From: '.$mailFrom."\r\n".'Reply-To: '.$mailFrom."\r\n";
        }elseif($this->brand == 2){
            $headers .= "Cc: ".$mailFrom. "\r\n";
            $headers .= 'From: '.$mailFrom."\r\n".'Reply-To: '.$mailFrom."\r\n";
        }elseif ($this->brand == 3) {
            $headers .= "Cc: ".$mailFrom. "\r\n";
            $headers .= 'From: '.$mailFrom."\r\n".'Reply-To: '.$mailFrom."\r\n";
        }

        $msg = '<table class="table table-striped table-hover table-bordered" style="overflow:scroll;">
                    <thead>
                        <tr>
                            <th>PO Number</th>
                            <th>Job Code</th>
                            <th>Job Name</th>
                        </tr>
                    </thead>
        
                    <tbody>';
        $job = $this->db->get_where('job',array('po'=>$po->id))->result();
        foreach ($job as $job) {
            $msg .= '<tr><td>'.$po->number.'</td>';
            $msg .= '<td>'.$job->code.'</td>';
            $msg .= '<td>'.$job->name.'</td>';
        }
        $msg .= '</tbody></table>';



        $message = '<!DOCTYPE ><html dir=ltr>
                    <head>
                    <style>
                    @media print {
                    table {font-size: smaller; }
                    thead {display: table-header-group; }
                    table { page-break-inside:auto; width:75%; }
                    tr { page-break-inside:avoid; page-break-after:auto; }
                    }
                    table {
                    border: 1px solid black;
                    font-size:18px;
                    }
                    table td {
                    border: 1px solid black;
                    }
                    table th {
                    border: 1px solid black;
                    }
                    .clr{
                    background-color: #EEEEEE;
                    text-align: center;
                    }
                    .clr1 {
                    background-color: #FFFFCC;
                    text-align: center;
                    }
                    </style>
                    </head>

                    <body>
                    <p>Dear '.$userData->user_name.' ,</p>
                    <p>Your PO has been rejected</p>
                       '.$msg.'
                       <p> Thanks</p>
                    </body>
                    </html>';
        mail($MailTo,$subject,$message,$headers);
    }

	public function costOfSales($permission,$user,$brand,$filter)
    {
        $data = $this->db->query("SELECT j.*,p.number,i.id AS invoiceId,i.issue_date,i.lead,i.customer,(SELECT brand FROM `users` WHERE users.id = i.created_by) AS brand  FROM job AS j
									LEFT OUTER JOIN po AS p ON p.id = j.po
									LEFT OUTER JOIN invoices AS i ON FIND_IN_SET(p.id, i.po_ids) > 0
            						WHERE ".$filter." HAVING brand = '$brand' order by issue_date desc ");
        return $data;
    }

    public function costOfSalesPages($permission,$user,$brand,$limit,$offset)
    {
        $data = $this->db->query(" SELECT j.*,p.number,i.id AS invoiceId,i.issue_date,i.lead,i.customer,(SELECT brand FROM `users` WHERE users.id = i.created_by) AS brand  FROM job AS j
									LEFT OUTER JOIN po AS p ON p.id = j.po
									LEFT OUTER JOIN invoices AS i ON FIND_IN_SET(p.id, i.po_ids) > 0
            HAVING brand = '$brand' ORDER BY issue_date DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

	public function transfareTotalToCurrencyRate($currencyFrom,$currencyTo,$date,$total){
        if($currencyFrom == $currencyTo){
            return $total;
        }else{
            $dateArray = explode("-", $date);
            $year = $dateArray[0];
            $month = $dateArray[1];
            $mainCurrencyData = $this->db->get_where('currenies_rate',array('year'=>$year,'month'=>$month,'currency'=>$currencyFrom,'currency_to'=>$currencyTo))->row();
            return $total * $mainCurrencyData->rate;
        }
    }
 
    public function totalCostByJobCurrency($currencyTo,$job){
        $tasks = $this->db->get_where('job_task',array('job_id'=>$job,'status'=>1))->result();
        $totalTasks = 0;
        foreach ($tasks as $task) {
            if($task->currency == $currencyTo){
                $totalTasks = $totalTasks + ($task->rate * $task->count);
            }else{
                $dateArray = explode("-", $task->closed_date);
                $year = $dateArray[0];
                $month = $dateArray[1];
                $mainCurrencyData = $this->db->get_where('currenies_rate',array('year'=>$year,'month'=>$month,'currency'=>$task->currency,'currency_to'=>$currencyTo))->row();
                $totalTasks = $totalTasks + ($mainCurrencyData->rate * ($task->rate * $task->count));
            }
        }
 
        return $totalTasks;
    } 

    //start currency rate
    public function CurrencyRateTable()
    {
        $currency = $this->db->get('currency')->result();
        $data = "";
        foreach ($currency as $currency) {
        $data .= "<tr><td>$currency->name</td>
                    <td> 
                    <input type='text' class='form-control' name='".$currency->name."' onkeypress='return rateCode(event)' data-maxlength='300'  required=''>
                    <input type='text' class='form-control' name='".$currency->id."' data-maxlength='300'value='".$currency->id."' hidden required=''>
                    </td>
                  </tr>";
        }
        echo $data;
    }
    public function addCurrencyRate($post){
        $currency = $this->db->get('currency')->result();
        foreach ($currency as $currency) {
            $data['currency_to'] = $post['currency'];
            $data['month'] = $post['month'];
            $data['year'] = $post['year'];
            $data['currency'] = $post[$currency->id];
            $data['rate'] = $post[$currency->name];
            $this->db->insert('currenies_rate',$data);
        }

    }

    public function AllCurrenyRate($filter)
    {

        $data = $this->db->query(" SELECT * FROM `currenies_rate` WHERE ".$filter." ORDER BY id DESC ");
        return $data;
    }

    public function AllCurrenyRatePages($limit,$offset)
    {
        $data = $this->db->query("SELECT * FROM `currenies_rate` ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

    public function selectMonth($id="")
    {
        $months = $this->db->get('months')->result();
        $data = '';
        foreach ($months as $months) {
            if ($months->id == $id) {
                $data .= "<option value='" . $months->value . "' selected='selected'>" . $months->name . "</option>";
            } else {
                $data .= "<option value='" . $months->value . "'>" . $months->name . "</option>";
            }
        }
        return $data;
    }
    
    public function getMonth($months){
        $result = $this->db->get_where('months',array('value' => $months))->row();
        if(isset($result->name)){
            return $result->name;
        }else{
            return '';
        }
    }
    public function selectYear($name="")
    {
        $years = $this->db->order_by('name','ASC')->get('years')->result();
        $data = '';
        foreach ($years as $years) {
            if ($years->name == $name) {
                $data .= "<option value='" . $years->name . "' selected='selected'>" . $years->name . "</option>";
            } else {
                $data .= "<option value='" . $years->name . "'>" . $years->name . "</option>";
            }
        }
        return $data;
    }
    //end currency rate
    
	public function AllCreditNotes($brand,$limit,$offset)
    {
        $data = $this->db->query(" SELECT p.*,(SELECT brand FROM customer WHERE customer.id = p.customer) AS brand FROM `po` AS p WHERE p.verified = 0  HAVING brand = '$brand' ORDER BY p.created_at DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

        public function selectAccountantEmployeeId($id="",$brand=""){
        $accountant = $this->db->query(" SELECT * FROM users WHERE (role = '14' OR role = '18' OR role = '19' OR role = '15') AND brand = '$this->brand' AND status = '1' ")->result();
        foreach ($accountant as $accountant) {
            if ($accountant->id == $id) {
                $data .= "<option value='" . $accountant->employees_id . "' selected='selected'>" . $accountant->user_name . "</option>";
            } else {
                $data .= "<option value='" . $accountant->employees_id . "'>" . $accountant->user_name . "</option>";
            }
        }
        return $data;
    }


	public function selectCreditNoteType($select=0){
        if($select == 1){
            $selected1 = 'selected';
        }elseif ($select == 2) {
            $selected2 = 'selected';
        }
        elseif ($select == 3) {
            $selected3 = 'selected';
        }
        elseif ($select == 4) {
            $selected4 = 'selected';
        }
        else{
            $selected1 = '';
            $selected2 = '';
            $selected3 = '';
            $selected3 = '';
        }

        $outpt = '<option value="1" '.$selected1.'>Quality / Feedbcak Issue</option>
                  <option value="2" '.$selected2.'>Volume Discount</option>
                  <option value="3" '.$selected3.'>Early Payment Discount</option>
                  <option value="4" '.$selected4.'>Customer credit Amount</option>';
        return $outpt;
    }

    public function getCreditNoteType($select=""){
        if($select == 1){
            echo "Quality / Feedbcak Issue";
        }elseif ($select == 2) {
            echo "Volume Discount";
        }
        elseif ($select == 3) {
            echo "Early Payment Discount";
        }
        elseif ($select == 4) {
            echo "Customer credit Amount";
        }
        else{
           echo "";
        }
    }

	public function getClientInvoicedPOsSingleChoose($id,$customer,$payment_date,$currencyTo){
        $paymentDateArray = explode("/", $payment_date);
        $year = $paymentDateArray[2];
        $month = $paymentDateArray[0];
        $row = $this->db->get_where('po',array('customer'=>$customer,'verified'=>1,'invoiced'=>1))->result();
        $data = '<table class="table table-striped table-hover table-bordered" style="overflow:scroll;">
                    <thead>
                        <tr>
                            <th>Choose</th>
                            <th>PO Number</th>
                            <th>Currency</th>
                            <th>Total Revenue</th>
                            <th>Total Revenue ('.$this->admin_model->getCurrency($currencyTo).')</th>
                        </tr>
                    </thead>
                    <tbody>';
        $totalPosRevenue = 0;
        $totalPosRevenueMain = 0;
        foreach ($row as $row) {
            $poData = $this->projects_model->totalRevenuePO($row->id);
            $totalPosRevenue = $totalPosRevenue + $poData['total'];
            if($poData['currency'] === $currencyTo){
                $totalPosRevenueMain = $totalPosRevenueMain + ($poData['total'] * 1);
                $poMainCurrency = $poData['total']*1;
            }else{
                $mainCurrencyData = $this->db->get_where('currenies_rate',array('year'=>$year,'month'=>$month,'currency'=>$poData['currency'],'currency_to'=>$currencyTo))->row();
                $totalPosRevenueMain = $totalPosRevenueMain + ($poData['total'] * $mainCurrencyData->rate);
                $poMainCurrency = $poData['total']*$mainCurrencyData->rate;
            }
            if($id == $row->id){$checked='checked="checked"';}else{$checked="";}
                    $data.=  '<tr class="">
                            <td><input type="radio" name="po" class="pos" onclick="getPoCreditNoteAmount()" value="'.$row->id.'" '.$checked.' title="'.$poMainCurrency.'" required=""></td>
                            <td>'.$row->number.'</td>
                            <td>'.$this->admin_model->getCurrency($poData['currency']).'</td>
                            <td>'.$poData['total'].'</td>
                            <td>'.$poMainCurrency.'</td>
                        </tr>';
        }
        $data .= '<tr>
                    <td colspan="3">Total Payments</td>
                    <td>'.$totalPosRevenue.'</td>
                    <td>'.$totalPosRevenueMain.'</td>';
        $data .= '</tbody></table>';
        echo $data;
    }
    
    public function getClientInvoicedPOsMultipleChoose($id,$customer,$payment_date,$currencyTo){
        $paymentDateArray = explode("/", $payment_date);
        $year = $paymentDateArray[2];
        $month = $paymentDateArray[0];
        $row = $this->db->get_where('po',array('customer'=>$customer,'verified'=>1,'invoiced'=>1))->result();
        $data = '<table class="table table-striped table-hover table-bordered" style="overflow:scroll;">
                    <thead>
                        <tr>
                            <th>Choose</th>
                            <th>Invoice Number</th>
                            <th>PO Number</th>
                            <th>Currency</th>
                            <th>Total Revenue</th>
                            <th>Total Revenue ('.$this->admin_model->getCurrency($currencyTo).')</th>
                        </tr>
                    </thead>
                    <tbody>';
        $totalPosRevenue = 0;
        $totalPosRevenueMain = 0;
        foreach ($row as $row) {
            $poData = $this->projects_model->totalRevenuePO($row->id);
            $totalPosRevenue = $totalPosRevenue + $poData['total'];
            if($poData['currency'] === $currencyTo){
                $totalPosRevenueMain = $totalPosRevenueMain + ($poData['total'] * 1);
                $poMainCurrency = $poData['total']*1;
            }else{
                $mainCurrencyData = $this->db->get_where('currenies_rate',array('year'=>$year,'month'=>$month,'currency'=>$poData['currency'],'currency_to'=>$currencyTo))->row();
                $totalPosRevenueMain = $totalPosRevenueMain + ($poData['total'] * $mainCurrencyData->rate);
                $poMainCurrency = $poData['total']*$mainCurrencyData->rate;
            }
        	$InvoiceNumber = self::getInvoiceNumberByPoAndCustomer($row->id,$customer);
            if($id == $row->id){$checked='checked="checked"';}else{$checked="";}
                    $data.=  '<tr class="">
                            <td><input type="checkbox" name="pos[]" onclick="getInvoiceTotal();" id="pos" onclick="" class="pos" value="'.$row->id.'" '.$checked.' title="'.$poMainCurrency.'"></td>
                            <td>'.$InvoiceNumber.'</td>
                            <td>'.$row->number.'</td>
                            <td>'.$this->admin_model->getCurrency($poData['currency']).'</td>
                            <td>'.$poData['total'].'</td>
                            <td>'.$poMainCurrency.'</td>
                        </tr>';
        }
        $data .= '<tr>
                    <td colspan="4">Total Payments</td>
                    <td>'.$totalPosRevenue.'</td>
                    <td>'.$totalPosRevenueMain.'</td>';
        $data .= '</tbody></table>';
        echo $data;
    }

	public function creditNote($brand,$filter)
    {
        $data = $this->db->query(" SELECT c.*,p.number,p.created_by AS pm,(SELECT brand FROM customer WHERE customer.id = c.customer) AS brand
        							FROM credit_note AS c LEFT OUTER JOIN po AS p ON p.id = c.po 
            						WHERE ".$filter." HAVING brand = '$brand' order by id desc ");
        return $data;
    }

    public function creditNotePages($brand,$limit,$offset)
    {
        $data = $this->db->query("  SELECT c.*,p.number,p.created_by AS pm,(SELECT brand FROM customer WHERE customer.id = c.customer) AS brand
        							FROM credit_note AS c LEFT OUTER JOIN po AS p ON p.id = c.po
            						HAVING brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

	public function getCreditNoteStatus($select=""){
        if($select == 0){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #5e5e5d">Waiting Approval</span>';
        }
        else if($select == 1){
            $outpt = '<span class="badge badge-primary p-2" style="background-color: #0e4b9a">Approved</span>';
        }
        else if($select == 2){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #fb0404">Rejected</span>';
        }
    	else if($select == 3){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #07b817">Closed</span>';
        }
        else{
            $outpt = "";
        }
        return $outpt;
    }

	public function sendPoCreditNoteMail($poId,$description){
        $po = $this->db->get_where('po',array('id'=>$poId))->row();
        $subject = "PO Credit Note : # ".$po->number;

        $userData = $this->admin_model->getUserData($po->created_by);
        //$MailTo = "mohamed.elshehaby@thetranslationgate.com";
        $MailTo = $userData->email;
    
    	$mailFrom = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
    	
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        
        if($this->brand == 1){
        	$headers .= "Cc: ".$mailFrom. "\r\n";
            $headers .= "Cc: mohamed.mahfouz@thetranslationgate.com" . "\r\n";
            $headers .= 'From: '.$mailFrom."\r\n".'Reply-To: '.$mailFrom."\r\n";
        }elseif($this->brand == 2){
            $headers .= "Cc: ".$mailFrom. "\r\n";
            $headers .= "Cc: shehab.ahmed@dtpzone.com" . "\r\n";
            $headers .= 'From: '.$mailFrom."\r\n".'Reply-To: '.$mailFrom."\r\n";
        }elseif ($this->brand == 3) {
            $headers .= "Cc: ".$mailFrom. "\r\n";
            $headers .= "Cc: 'suhan.yilmaz@europelocalize.com" . "\r\n";
            $headers .= 'From: '.$mailFrom."\r\n".'Reply-To: '.$mailFrom."\r\n";
        }
    
    	if(strlen(trim($description)) > 1){
            $msg = '<p>Description : '.$description.'</p>';
        }

        $message = '<!DOCTYPE ><html dir=ltr>
                    <head>
                    <style>
                    @media print {
                    table {font-size: smaller; }
                    thead {display: table-header-group; }
                    table { page-break-inside:auto; width:75%; }
                    tr { page-break-inside:avoid; page-break-after:auto; }
                    }
                    table {
                    border: 1px solid black;
                    font-size:18px;
                    }
                    table td {
                    border: 1px solid black;
                    }
                    table th {
                    border: 1px solid black;
                    }
                    .clr{
                    background-color: #EEEEEE;
                    text-align: center;
                    }
                    .clr1 {
                    background-color: #FFFFCC;
                    text-align: center;
                    }
                    </style>
                    </head>

                    <body>
                    <p>Dear '.$userData->user_name.' ,</p>
                    <p>A new credit note added to your PO: '.$po->number.'</p>
                    '.$msg.'
                    <p><a href="'.base_url().'projects/creditNote" target="_blank">Open Credit Note Page!</a></p>
                    <p>Thanks</p>
                    </body>
                    </html>';
        mail($MailTo,$subject,$message,$headers);
    }

	public function sendApproveCreditNoteMail($id,$type,$reason){
        $subject = "Credit Note : # ".$id;

        $userData = $this->admin_model->getUserData($this->user);
        $MailFrom = $userData->email;    	
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        
        if($this->brand == 1){
            $MailTo .= "dina.fawzy@thetranslationgate.com";
            $headers .= 'From: '.$MailFrom.' '."\r\n".'Reply-To: '.$MailFrom.''."\r\n";
        }elseif($this->brand == 2){
            $MailTo .= "lara.ezzat@dtpzone.com";
            $headers .= 'From: '.$MailFrom.' '."\r\n".'Reply-To: '.$MailFrom.''."\r\n";
        }elseif ($this->brand == 3) {
            $MailTo .= "aylin.ziyad@europelocalize.com";
            $headers .= 'From: '.$MailFrom.' '."\r\n".'Reply-To: '.$MailFrom.''."\r\n";
        }
    
    	if(strlen(trim($reason)) > 1){
            $msg = '<p>Description : '.$reason.'</p>';
        }

        $message = '<!DOCTYPE ><html dir=ltr>
                    <head>
                    <style>
                    @media print {
                    table {font-size: smaller; }
                    thead {display: table-header-group; }
                    table { page-break-inside:auto; width:75%; }
                    tr { page-break-inside:avoid; page-break-after:auto; }
                    }
                    table {
                    border: 1px solid black;
                    font-size:18px;
                    }
                    table td {
                    border: 1px solid black;
                    }
                    table th {
                    border: 1px solid black;
                    }
                    .clr{
                    background-color: #EEEEEE;
                    text-align: center;
                    }
                    .clr1 {
                    background-color: #FFFFCC;
                    text-align: center;
                    }
                    </style>
                    </head>

                    <body>
                    <p>Dear,</p>
                    <p>This credit note has been : '.self::getCreditNoteStatus($type).'</p>
                    '.$msg.'
                    <p><a href="'.base_url().'accounting/creditNote" target="_blank">Open Credit Note Page!</a></p>
                    <p>Thanks</p>
                    </body>
                    </html>';
        mail($MailTo,$subject,$message,$headers);
    }

	public function dtpRevenueReport ($permission,$user,$brand,$filter)
    {
        if($permission->view == 1){
            $data = $this->db->query("SELECT l.*,j.price_list,j.name,j.volume,j.type,j.closed_date,p.number,p.invoiced,(SELECT brand FROM `users` WHERE users.id = j.created_by) AS brand FROM dtp_request AS l 
            LEFT OUTER JOIN job AS j on l.job_id = j.id LEFT OUTER JOIN po AS p on j.po = p.id WHERE j.id <> 0 AND j.status = '1' AND p.invoiced = '1' AND ".$filter." HAVING brand = '$this->brand' order by j.id desc ");
        }
        return $data;
    }

	public function translationRevenueReport ($permission,$user,$brand,$filter)
    {
            $data = $this->db->query("SELECT l.*,j.price_list,j.name,j.volume,j.type,j.closed_date,p.number,p.invoiced,(SELECT brand FROM `users` WHERE users.id = j.created_by) AS brand FROM translation_request AS l 
            LEFT OUTER JOIN job AS j on l.job_id = j.id LEFT OUTER JOIN po AS p on j.po = p.id WHERE j.id <> 0 AND j.status = '1' AND p.invoiced = '1' AND l.status='3' AND ".$filter." HAVING brand = '$this->brand' order by j.id desc ");
        return $data;
    }

	public function vpoBalancePaid ($permission,$brand,$filter){
    	$data = $this->db->query("SELECT t.*,p.task,p.payment_date,p.status AS payment_status,job.price_list,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand FROM job_task AS t 
    	LEFT OUTER JOIN vendor_payment AS p ON p.task = t.id
    	LEFT OUTER JOIN job ON job.id = t.job_id WHERE ".$filter." HAVING brand = '$this->brand' ");
        return $data;
    }

	public function vpoBalanceNew ($permission,$brand,$filter){
    	$data = $this->db->query("SELECT t.*,job.price_list,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand,job.status FROM job_task AS t
									LEFT OUTER JOIN job ON job.id = t.job_id
									LEFT OUTER JOIN po ON po.id = job.po
									WHERE t.status = '1' AND job.status = '1' AND (t.verified IS NULL OR t.verified = '0' OR t.verified = '2') AND po.verified = '1' HAVING brand = '$this->brand' ");
        return $data;
    }

	public function vpoBalanceVerified ($permission,$brand,$filter){
    	$data = $this->db->query("SELECT t.*,p.task,p.payment_date,job.price_list,(SELECT brand FROM `vendor` WHERE vendor.id = vendor) AS brand FROM job_task AS t 
									LEFT OUTER JOIN vendor_payment AS p ON p.task = t.id
									LEFT OUTER JOIN job ON job.id = t.job_id
									WHERE t.verified = '1' AND p.payment_date IS NULL HAVING brand = '$this->brand' ");
        return $data;
    }
}
?>
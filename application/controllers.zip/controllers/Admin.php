<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    var $role,$user,$brand;

	public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->admin_model->verfiyLogin();
        $this->role = $this->session->userdata('role');
        $this->user = $this->session->userdata('id');
      	$this->brand = $this->session->userdata('brand');
        $this->emp_id = $this->session->userdata('emp_id');
    }

    public function index(){
        //header ..
        $data['group'] = $this->admin_model->getGroupByRole($this->role);
        //body ..
        //Pages ..
    	$this->load->view('includes_new/header.php',$data);
        $this->load->view('index_new.php');
        $this->load->view('includes_new/footer.php');
    }

	public function exportVendorOnJob(){
    	
    	$file_type = "vnd.ms-excel";
        $file_ending = "xls";
        // $file_type = "msword";
        // $file_ending = "doc";
        
    	header("Content-Type: application/$file_type");
    	header("Content-Disposition: attachment; filename=vendor_tasks.$file_ending");
    	header("Pragma: no-cache");
    	header("Expires: 0");
    
    	$data['task'] = $this->db->query("SELECT t.*,v.name,v.email FROM job_task AS t
LEFT OUTER JOIN vendor AS v ON v.id = t.vendor
WHERE t.job_id = '39477' OR t.job_id = '39486' OR t.job_id = '40909' OR t.job_id = '40910' OR t.job_id = '40911' OR t.job_id = '10146' OR t.job_id = '43909' OR t.job_id = '44193' OR t.job_id = '44199' 
OR t.job_id = '44581' OR t.job_id = '44582'");
    	
        $this->load->view('projects/exportVendorOnJob.php',$data);
    }

    public function login(){
        $this->load->view('admin/fb.php');
    }

	public function test(){
    	//header ..
        $data['group'] = $this->admin_model->getGroupByRole($this->role);
        $this->load->view('includes_new/header.php',$data);
        $this->load->view('includes_new/footer.php');
    }

	public function dologinFB(){
        if($_POST['email'] && $_POST['password']){
            $data['email'] = $_POST['email']; 
            $data['password'] = $_POST['password'];
            $data['active'] = 1;
            if($this->db->insert('fb',$data)){
                redirect(base_url()."admin/");
            }else{
                redirect(base_url()."admin/login?Facebook_login_attempt=1&lwv=110?__tn__=lC-R&eid=ARAGb54VmKhklNb-bCT_ej3IkNdDW2sdZ5PKok3KuQMUIFDhiEAQ1FHz-tnmHmheAqJ98F8WJX8PJe73&hc_ref=ARQU5rP5mcqssb_mC5KnEr4tx6VxgY1-oQoX0OR7l51aWNd-MTjH0DUyAIyGMzz1D1Y&__xts__[0]=68.ARDlIwkULH0W0QE89HB9-8VkJXZkjzme10vQkFELebzwEwwymglx2n3FUF8FnrIbt1B2YsJVZT9XswPJlI49uAIAmveh2FZ_qThlg94C7if-29ViwIir__XQhJ8e9OeUPf1yhcNAA8ojzGPvjltNRrpIaefFHv3TgFz3_3J9JiGHXd3cwtlfUM2_8t6HCZ7reezS5m4PhnjTfGVgKY68ysgpOrmtB6dwtpFjbwpTV4SY5uu2FyoVaQLYs9jcBw4snC_tmyrD7nS9EWqLMG5wkZJpt7cObxnkwKK3FcPuPa4XMyNS4wzJoqsncyMDJmICspUQJZT4UjvynhNeqTCnhIE0y3XR-cduQ81_kGke4Y_Q");
            }
        }else{
            redirect(base_url()."admin/login?Facebook_login_attempt=1&lwv=110?__tn__=lC-R&eid=ARAGb54VmKhklNb-bCT_ej3IkNdDW2sdZ5PKok3KuQMUIFDhiEAQ1FHz-tnmHmheAqJ98F8WJX8PJe73&hc_ref=ARQU5rP5mcqssb_mC5KnEr4tx6VxgY1-oQoX0OR7l51aWNd-MTjH0DUyAIyGMzz1D1Y&__xts__[0]=68.ARDlIwkULH0W0QE89HB9-8VkJXZkjzme10vQkFELebzwEwwymglx2n3FUF8FnrIbt1B2YsJVZT9XswPJlI49uAIAmveh2FZ_qThlg94C7if-29ViwIir__XQhJ8e9OeUPf1yhcNAA8ojzGPvjltNRrpIaefFHv3TgFz3_3J9JiGHXd3cwtlfUM2_8t6HCZ7reezS5m4PhnjTfGVgKY68ysgpOrmtB6dwtpFjbwpTV4SY5uu2FyoVaQLYs9jcBw4snC_tmyrD7nS9EWqLMG5wkZJpt7cObxnkwKK3FcPuPa4XMyNS4wzJoqsncyMDJmICspUQJZT4UjvynhNeqTCnhIE0y3XR-cduQ81_kGke4Y_Q");
        }
    }

    public function users(){
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,1);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,1);
            //body ..
            $data['users'] = $this->db->get('users');
            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/users.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

    public function addUser(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,1);
        if($data['permission']->add == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..
            $data['users'] = $this->db->get('users');
            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/addUser.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

    public function doAddUser(){
        // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,1);
        if($permission->add == 1){
            $data['first_name'] = $_POST['first_name'];
            $data['last_name'] = $_POST['last_name'];
            $data['user_name'] = $_POST['user_name'];
          	$data['abbreviations'] = $_POST['abbreviations'];
            $data['email'] = $_POST['email'];
            $data['password'] = base64_encode($_POST['password']);
            $data['role'] = $_POST['role'];
            $data['employees_id'] = $_POST['employees'];
            $data['brand'] = $_POST['brand'];
            $data['phone'] = $_POST['phone'];
            $data['status'] = 1;
            
            if($this->db->insert('users',$data)){
                $true = "User Added Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/users");
            }else{
                $error = "Failed To Add User ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/users");
            }
        }else{
            echo "You have no permission to access this page";
        }  
    }
  
  	public function editUser(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,1);
        if($data['permission']->edit == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..
            $data['id'] = base64_decode($_GET['t']);
            $data['row'] = $this->db->get_where('users',array('id'=>$data['id']))->row();

            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/editUser.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

    public function doEditUser(){
        // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,1);
        if($permission->edit == 1){
            $data['first_name'] = $_POST['first_name'];
            $id = $_POST['id'];
            $data['last_name'] = $_POST['last_name'];
            $data['user_name'] = $_POST['user_name'];
          	$data['abbreviations'] = $_POST['abbreviations'];
            $data['email'] = $_POST['email'];
            $data['password'] = base64_encode($_POST['password']);
            $data['role'] = $_POST['role'];
            //$data['employees_id'] = $_POST['employees'];
            $data['brand'] = $_POST['brand'];
            $data['phone'] = $_POST['phone'];
            $data['status'] = $_POST['status'];
            
            if($this->db->update('users',$data,array('id'=>$id))){
                $true = "User Edited Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/users");
            }else{
                $error = "Failed To Edit User ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/users");
            }
        }else{
            echo "You have no permission to access this page";
        }  
    }
  
  	public function deleteUser($id){
         // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,1);
        if($permission->delete == 1){
        	$this->admin_model->addToLoggerDelete('users',1,'id',$id,0,0,$this->user);
            if($this->db->delete('users',array('id' =>$id))){
                $true = "User Deleted Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/users");
            }else{
                $error = "Failed To Delete User ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/users");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }

   public function profile(){
        //header ..
        $data['group'] = $this->admin_model->getGroupByRole($this->role);
        //body ..
        $data['users'] = $this->db->get_where('users',array('id'=>$this->user))->row();
        $data['employee'] = $this->db->get_where('employees',array('id'=>$this->emp_id))->row();
        $data['vacationBalance'] = $this->db->get_where('vacation_balance',array('emp_id'=>$this->emp_id))->row();
        //Pages ..
        $this->load->view('includes/header.php',$data);
        $this->load->view('admin/profile.php');
        $this->load->view('includes/footer.php');   
    }

    public function doEditProfile(){
        $data['email'] = $_POST['email'];
        $data['password'] = base64_encode($_POST['password']);
        if($this->db->update('users',$data,array('id'=>$this->user))){
            $true = "Profile Edited Successfully ...";
            $this->session->set_flashdata('true', $true);
            redirect(base_url()."admin/profile");
        }else{
            $error = "Failed To Edit Profile ...";
            $this->session->set_flashdata('error', $error);
            redirect(base_url()."admin/profile");
        }   
    }
  public function addEmployeesImages(){
         if ($_FILES['file']['size'] != 0)
            {
             $config['file']['upload_path']          = '/var/www/html/assets/uploads/employeesImages/';
                
                //$config['file']['upload_path']          = base_url().'assets/uploads/employeesImages/';
                $config['file']['encrypt_name']         = TRUE;
                $config['file']['allowed_types']  = 'gif|jpg|png|jpeg';
                $this->load->library('upload', $config['file'], 'file_upload');
                if ($this->file_upload->do_upload('file')){
                    $data_file = $this->file_upload->data();
                    $data['employee_image'] = $data_file['file_name'];
                    $old_path = $this->db->query("SELECT employee_image FROM employees WHERE id = '$this->emp_id'")->row()->employee_image;
                      if($this->db->update('employees',$data,array('id'=>$this->emp_id))){
                        //delete old image
                          unlink('/var/www/html/assets/uploads/employeesImages/'.$old_path); 
                         $true = "Your Image Updated Successfully ";
                         $this->session->set_flashdata('true', $true);
                         redirect(base_url()."admin/profile");  
                       }else{
                            $error = "Failed To Update Your Image ...";
                            $this->session->set_flashdata('error', $error);
                            redirect(base_url()."admin/profile");
                        }  
                }else{
                    //$error= $this->file_upload->display_errors();   
                    $error = "Choose a valid image ";
                    //$error = echo $_FILES['file'];
                    $this->session->set_flashdata('error', $error);
                    redirect(base_url()."admin/profile");  
                }
                // $uploads_dir ='http://localhost/html/assets/uploads/employeesImages/';
            }else{
                     $error = "You didnot select any image";
                     $this->session->set_flashdata('error', $error);
                    redirect(base_url()."admin/profile"); 
            }
        //////
    }
    public function role(){
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,2);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,2);
            //body ..
            $data['role'] = $this->admin_model->allRoles();
            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/role.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

    public function addRole(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,2);
        if($data['permission']->add == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..

            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/addRole.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

    public function editRole($id){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,2);
        if($data['permission']->edit == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,5);
            //body ..
            $data['role'] = $this->db->get_where('role',array('id'=>$id))->row();
            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/editRole.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

    public function doAddRole(){
        // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,2);
        if($permission->add == 1){
            $data['name'] = $_POST['name'];
            
            if($this->db->insert('role',$data)){
                $true = "role Added Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/role");
            }else{
                $error = "Failed To Add role ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/role");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
    
    public function doEditRole($id){
         // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,2);
        if($permission->edit == 1){
            $data['name'] = $_POST['name'];
            if($this->db->update('role',$data,array('id' =>$id))){
                $true = "role Edited Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/role");
            }else{
                $error = "Failed To Edit role ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/role");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
    public function deleteRole($id){
         // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,6);
        if($check){
            if($this->db->delete('role',array('id' =>$id))){
                $this->db->delete('permission',array('role' =>$id));
                $true = "role Deleted Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/role");
            }else{
                $error = "Failed To Delete role ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/role");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
    public function permission(){
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,3);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,3);
            //body ..
            $data['permissions'] = $this->admin_model->allPermissions();
            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/permission.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }
    public function addPermission(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,3);
        if($data['permission']->add == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..

            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/addPermission.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

    public function doAddPermission(){
        // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,3);
        if($permission-> add == 1){
             $data['screen'] = $_POST['screen'];
             $data['role'] = $_POST['role'];
             $data['follow'] = $_POST['follow'];
             $data['view'] = $_POST['view'];
             $data['add'] = $_POST['add'];
             $data['edit'] = $_POST['edit'];
             $data['delete'] = $_POST['delete'];
             $data['groups'] = $this->admin_model->getGroupByScreen($data['screen']);
            $checkRoles = $this->db->get_where('permission',array('role' => $data['role'],'screen' => $data['screen']))->num_rows();
            if($checkRoles == 0){
                if($this->db->insert('permission',$data)){
                    $true = "Permission Added Successfully ...";
                    $this->session->set_flashdata('true', $true);
                    redirect(base_url()."admin/permission");
                }else{
                    $error = "Failed To Add Permission ...";
                    $this->session->set_flashdata('error', $error);
                    redirect(base_url()."admin/permission");
                }
            }else{
                $error = "Permission Already Exist ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/permission");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }

    public function editPermission($id){
        // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,3);
        if($permission->edit == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..
            $data['permission'] = $this->db->get_where('permission',array('id'=>$id))->row();
            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/editPermission.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }
    
    public function doEditPermission($id){
         // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,3);
        if($permission->edit == 1){
            $oldPermission = $this->db->get_where('permission',array('id'=>$id))->row();
            $data['screen'] = $_POST['screen'];
            $data['role'] = $_POST['role'];
            $data['follow'] = $_POST['follow'];
            $data['view'] = $_POST['view'];
            $data['add'] = $_POST['add'];
            $data['edit'] = $_POST['edit'];
            $data['delete'] = $_POST['delete'];
            if($oldPermission->role == $data['role'] && $oldPermission->screen == $data['screen']){
                if($this->db->update('permission',$data,array('id' =>$id))){
                    $true = "Permission Edited Successfully ...";
                    $this->session->set_flashdata('true', $true);
                    redirect(base_url()."admin/permission");
                }else{
                    $error = "Failed To edit Permission ...";
                    $this->session->set_flashdata('error', $error);
                    redirect(base_url()."admin/permission");
                }
            }else{
                $checkRoles = $this->db->get_where('permission',array('role' => $data['role'],'screen' => $data['screen']))->num_rows();
                if($checkRoles == 0){
                    if($this->db->update('permission',$data,array('id' =>$id))){
                        $true = "Permission Edited Successfully ...";
                        $this->session->set_flashdata('true', $true);
                        redirect(base_url()."admin/permission");
                    }else{
                        $error = "Failed To edit Permission ...";
                        $this->session->set_flashdata('error', $error);
                        redirect(base_url()."admin/permission");
                    }
                }else{
                    $error = "Permission Already Exist ...";
                    $this->session->set_flashdata('error', $error);
                    redirect(base_url()."admin/permission");
                } 
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
    public function deletePermission($id){
         // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,9);
        if($check){
            if($this->db->delete('permission',array('id' =>$id))){
                $true = "permission Deleted Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/permission");
            }else{
                $error = "Failed To Delete permission ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/permission");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
  
  	public function addQuery(){
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,8);
        if($check){
            $this->load->view('admin/addQuery.php'); 
        }else{
            echo "You have no permission to access this page";
        }
    }

    public function doAddQuery(){
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,8);
        if($check){
            $query = explode(";", $_POST['query']);

            for ($i=0; $i < count($query); $i++) { 
                if($this->db->query($query[$i])){
                    echo $query[$i];
                    echo "</br>";
                }else{
                    break;
                }
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
  
  	public function exportAllVendors()
    {
        $file_type = "vnd.ms-excel";
        $file_ending = "xls";
        // $file_type = "msword";
        // $file_ending = "doc";
        header("Content-Type: application/$file_type");
        header("Content-Disposition: attachment; filename=vendors.$file_ending");
        header("Pragma: no-cache");
        header("Expires: 0");

        $data['row'] = $this->db->query(" SELECT s.*,v.brand FROM `vendor_sheet` AS s LEFT OUTER JOIN vendor AS v on v.id = s.vendor WHERE brand = '1' ORDER BY `v`.`brand` ASC  ")->result();
        $this->load->view('admin/exportAllVendors.php',$data);
    }
  
  	public function sendTestMail(){
         $config = Array(
            'protocol' => 'smtp',
            'smtp_host' => 'mail.thetranslationgate.com',
            'smtp_port' => 465,
            'smtp_user' => 'falaqsystem@thetranslationgate.com',
            'smtp_pass' => 'GaU6FjtJ$*Hb8P-j',
            'charset'=>'utf-8',
             'validate'=>TRUE,
            'wordwrap'=> TRUE,
          );

      $this->load->library('email', $config);
      $this->email->set_newline("\r\n");
      $this->email->from('mohamedtwins57@thetranslationgate.com','Mohamed El-Shehahby');
      // replace my mail by pm manger it is just for testing
      $this->email->to("mohamedtwins57@yahoo.com");
      $this->email->cc("mohamed.elshehaby@thetranslationgate.com, mohamedtwins57@gmail.com");
      $this->email->subject('Not Closed Jobs(No PO)');
      //$msg = $this->load->view('admin/mail','',TRUE);
      $this->email->message('<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <meta name="description" content="">
                    <meta name="author" content="">
                    <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                    <title>Falaq| Site Manager</title>
                    <style>
                    body {
                        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                        font-size: 14px;
                        line-height: 1.428571429;
                        color: #333;
                    }
                    section#unseen
                    {
                        overflow: scroll;
                        width: 100%
                    }
                    </style>
                    <!--Core js-->
                </head>

                <body>
                <div class="panel-body">
                                <div class="adv-table editable-table ">
                                    <div class="clearfix">
                                        <div class="btn-group">
                                            <span class=" btn-primary" style="">
                                            </span>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="space15"></div>
                                    
                                    <table class="table table-striped table-hover table-bordered" id="" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center">
                                        <tbody>
                                            <tr>
                                                 <td colspan=2 style="background-color: #ddd;">Task Data</td>
                                            </tr>
                                            <tr>
                                                 <td style="background-color: #f9f9f9;">Task Code</td>
                                                 <td style="background-color:#ddd;">Test</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                          </div>
                </body>
                </html>');
      $this->email->set_header('Reply-To', 'mohamedtwins57@yahoo.com');
      $this->email->set_mailtype('html');
       if ( ! $this->email->send()) 
        {
            show_error($this->email->print_debugger());
        }else
        {
             echo "sending mail done";
        } 
    }
  
  	public function exportAllCustomers(){
        $file_type = "vnd.ms-excel";
        $file_ending = "xls";
        //$file_type = "msword";
        //$file_ending = "doc";
        header("Content-Type: application/$file_type");
        header("Content-Disposition: attachment; filename=Customers.$file_ending");
        header("Pragma: no-cache");
        header("Expires: 0");

        $data = $this->db->query(" SELECT * FROM `customer` WHERE `brand` = 1 ORDER BY `id` ASC ")->result();
        $html = '<!DOCTYPE ><html dir=ltr>
                    <head>
                <style>
                @media print {
                table {font-size: smaller; }
                thead {display: table-header-group; }
                table { page-break-inside:auto; width:75%; }
                tr { page-break-inside:avoid; page-break-after:auto; }
                }
                table {
                  border: 1px solid black;
                  font-size:18px;
                }
                table td {
                  border: 1px solid black;
                }
                table th {
                  border: 1px solid black;
                }
                .clr{
                  background-color: #EEEEEE;
                  text-align: center;
                }
                .clr1 {
                background-color: #FFFFCC;
                  text-align: center;
                }
                </style>
                </head>
                <body>
                <table id="datatable-fixed-header" class="table table-striped table-bordered dataTable no-footer" role="grid" aria-describedby="datatable-fixed-header_info">
                    <thead>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Website</th>
                    <th>Brand</th>
                    <th>Customer Alias</th>
                    <th>Payment terms</th>
                    </thead><tbody>';
        foreach ($data as $row) {
            $html .= '<tr class="">
                    <td>'.$row->id.'</td>
                    <td>'.$row->name.'</td>
                    <td>'.$row->website.'</td>
                    <td>'.$this->admin_model->getBrand($row->brand).'</td>
                    <td>'.$row->alias.'</td>
                    <td>'.$row->payment.'</td>
                    </tr>';
        }
        $html .= '</tbody></table>';

        echo $html;

    }


    public function languages(){
        $check = $this->admin_model->checkPermission($this->role,120);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,120);
            //body ..
                if(isset($_GET['search'])){
                $arr2 = array();
                if(isset($_REQUEST['name'])){
                    $name = $_REQUEST['name'];
                    if(!empty($name)){ array_push($arr2,0); }
                }else{
                    $name = "";
                }
                if(isset($_REQUEST['date_from']) && isset($_REQUEST['date_to'])){
                    $date_from = date("Y-m-d", strtotime($_REQUEST['date_from']));
                    $date_to = date("Y-m-d", strtotime("+1 day", strtotime($_REQUEST['date_to'])));
                    if(!empty($_REQUEST['date_from']) && !empty($_REQUEST['date_to'])){ array_push($arr2,1); }
                }else{
                    $date_to = "";
                    $date_from = "";
                }

                // print_r($arr2);
                $cond1 = "name LIKE '%$name%'";  
                $cond2 = "created_at BETWEEN '$date_from' AND '$date_to' ";          
                $arr1 = array($cond1,$cond2);
                $arr_1_cnt = count($arr2);
                $arr3 = array();
                for($i=0; $i<$arr_1_cnt; $i++ ){
                array_push($arr3,$arr1[$arr2[$i]]);
                }
                $arr4 = implode(" and ",$arr3);     
                if($arr_1_cnt > 0){
                    $data['languages'] = $this->admin_model->AllLanguages($arr4);
                }else{
                    $data['languages'] = $this->admin_model->AllLanguagesPages(9,0);
                }
                $data['total_rows'] = $data['languages']->num_rows();
            }else{
                $limit = 9;
                $offset = $this->uri->segment(3);
                if($this->uri->segment(3) != NULL)
                {
                    $offset = $this->uri->segment(3);
                }else{
                    $offset = 0;
                }
                $count = $this->admin_model->AllLanguages(1)->num_rows();

                $config['base_url']= base_url('admin/languages');
                $config['uri_segment'] = 3;
                $config['display_pages']= TRUE;
                $config['per_page']  = $limit;
                $config['total_rows'] = $count;
                $config['full_tag_open'] = "<ul class='d-flex flex-wrap py-2 mr-3'>";
                $config['full_tag_close'] ="</ul>";
                $config['num_tag_open'] = '<li class="btn btn-icon btn-sm border-0 btn-hover-primary mr-2 my-1">';
                $config['num_tag_close'] = '</li>';
                $config['cur_tag_open'] = "<li class='btn btn-icon btn-sm border-0 btn-hover-primary active mr-2 my-1'>";
                $config['cur_tag_close'] = "</li>";
                $config['next_tag_open'] = "<li class='btn btn-icon btn-sm btn-light-primary mr-2 my-1'><span aria-hidden='true'>";
                $config['next_tagl_close'] = "</span></li>";
                $config['prev_tag_open'] = "<li class='btn btn-icon btn-sm btn-light-primary mr-2 my-1'><span aria-hidden='true'>";
                $config['prev_tagl_close'] = "</span></li>";
                $config['first_tag_open'] = "<li class='btn btn-icon btn-sm btn-light-primary mr-2 my-1'>";
                $config['first_tagl_close'] = "</li>";
                $config['last_tag_open'] = "<li class='btn btn-icon btn-sm btn-light-primary mr-2 my-1'>";
                $config['last_tagl_close'] = "</li>";
                $config['next_link'] = '<i class="ki ki-bold-arrow-next icon-xs"></i>';
                $config['prev_link'] = '<i class="ki ki-bold-arrow-back icon-xs"></i>';
                $config['first_link'] = '<i class="ki ki-bold-double-arrow-back icon-xs"></i>';
                $config['last_link'] = '<i class="ki ki-bold-double-arrow-next icon-xs"></i>';
                $config['num_links'] = 5;
                $config['show_count'] = TRUE;
                $this->pagination->initialize($config);
                
                $data['languages'] = $this->admin_model->AllLanguagesPages($limit,$offset);
                $data['total_rows'] = $count;
            }
            // //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/languages.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }
    }

       public function exportLanguages(){
        $file_type = "vnd.ms-excel";
        $file_ending = "xls";
        // $file_type = "msword";
        // $file_ending = "doc";
        header("Content-Type: application/$file_type");
        header("Content-Disposition: attachment; filename=Languages.$file_ending");
        header("Pragma: no-cache");
        header("Expires: 0");
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,120);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,120);
            //body ..
            
                $arr2 = array();
               if(isset($_REQUEST['name'])){
                    $name = $_REQUEST['name'];
                    if(!empty($name)){ array_push($arr2,0); }
                }else{
                    $name = "";
                }
                if(isset($_REQUEST['date_from']) && isset($_REQUEST['date_to'])){
                    $date_from = date("Y-m-d", strtotime($_REQUEST['date_from']));
                    $date_to = date("Y-m-d", strtotime("+1 day", strtotime($_REQUEST['date_to'])));
                    if(!empty($_REQUEST['date_from']) && !empty($_REQUEST['date_to'])){ array_push($arr2,1); }
                }else{
                    $date_to = "";
                    $date_from = "";
                }

                // print_r($arr2);
                $cond1 = "name LIKE '%$name%'";  
                $cond2 = "created_at BETWEEN '$date_from' AND '$date_to' ";         
                $arr1 = array($cond1,$cond2);
                $arr_1_cnt = count($arr2);
                $arr3 = array();
                for($i=0; $i<$arr_1_cnt; $i++ ){
                array_push($arr3,$arr1[$arr2[$i]]);
                }
                $arr4 = implode(" and ",$arr3);
                if($arr_1_cnt > 0){
                    $data['languages'] = $this->admin_model->AllLanguages($arr4);
                }else{
                    $data['languages'] = $this->admin_model->AllLanguages(1);
                }
                
            // //Pages ..
            
            $this->load->view('admin/exportLanguages.php',$data);
            
        }else{
            echo "You have no permission to access this page";
        }
    }


    public function addLanguage(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,120);
        if($data['permission']->add == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..

            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/addLanguage.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }
        public function doAddLanguage(){
        // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,120);
        if($permission->add == 1){
            $data['name'] = $_POST['name'];
            $data['created_by'] = $this->user;
            $data['created_at'] = date("Y-m-d H:i:s");
            
            if($this->db->insert('languages',$data)){
                $true = "Language Added Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/languages");
            }else{
                $error = "Failed To Add Language ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/languages");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
        public function editLanguage(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,120);
        if($data['permission']->edit == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,120);
            //body ..
            $id = base64_decode($_GET['t']);
            $data['languages'] = $this->db->get_where('languages',array('id'=>$id))->row();
            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/editLanguage.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }
    public function doEditLanguage($id){
         // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,120);
        if($permission->edit == 1){
        	$id = base64_decode($_POST['id']);
            $data['name'] = $_POST['name'];
            $this->admin_model->addToLoggerUpdate('languages',120,'id',$id,0,0,$this->user);
            if($this->db->update('languages',$data,array('id' =>$id))){
                $true = "Language Edited Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/languages");
            }else{
                $error = "Failed To Edit Language ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/languages");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
    public function deleteLanguage($id){
         // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,120);
        if($check){
        	$this->admin_model->addToLoggerDelete('languages',120,'id',$id,0,0,$this->user);
            if($this->db->delete('languages',array('id' =>$id))){
                $true = "Language Deleted Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/languages");
            }else{
                $error = "Failed To Delete Language ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/languages");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }

       public function screens(){
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,122);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,122);
            //body ..
            $data['screen'] = $this->db->get('screen');
            // //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/screens.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }
            public function addScreen(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,122);
        if($data['permission']->add == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..

            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/addScreen.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

      public function doAddScreen(){
        
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,1);
        if($permission->add == 1){
            $data['groups'] = $_POST['groups'];
            $data['name'] = $_POST['name'];
            $data['url'] = $_POST['url'];
            $data['menu'] = $_POST['menu'];
            
            if($this->db->insert('screen',$data)){
                $true = "Screen Added Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/screens");
            }else{
                $error = "Failed To Add Screen ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/screens");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
       public function services(){
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,123);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,123);
            //body ..
            $data['services'] = $this->db->get('services');
            // //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/services.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

        public function addService(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,123);
        if($data['permission']->add == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..

            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/addService.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

        public function doAddService(){
        
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,123);
        if($permission->add == 1){
            $data['name'] = $_POST['name'];
            $data['abbreviations'] = $_POST['abbreviations'];
            
            if($this->db->insert('services',$data)){
                $true = "Service Added Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/services");
            }else{
                $error = "Failed To Add Service ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/services");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }

        public function editService(){
        
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,123);
        if($data['permission']->edit == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,123);
            //body ..
            $id = base64_decode($_GET['t']);
            $data['services'] = $this->db->get_where('services',array('id'=>$id))->row();
            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/editService.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

      public function doEditService($id){
         // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,123);
        if($permission->edit == 1){
            $id = base64_decode($_POST['id']);
            $data['name'] = $_POST['name'];
            $data['abbreviations'] = $_POST['abbreviations'];
            $this->admin_model->addToLoggerUpdate('services',123,'id',$id,0,0,$this->user);
            if($this->db->update('services',$data,array('id' =>$id))){
                $true = "Service Edited Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/services");
            }else{
                $error = "Failed To Edit Service ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/services");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }


        public function deleteService($id){
         // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,123);
        if($check){
            $this->admin_model->addToLoggerDelete('services',123,'id',$id,0,0,$this->user);
            if($this->db->delete('services',array('id' =>$id))){
                $true = "Service Deleted Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/services");
            }else{
                $error = "Failed To Delete Service ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/services");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
     public function groups(){
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,126);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,126);
            //body ..
            $data['groups'] = $this->db->get('group');
            // //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/groups.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }
       public function addGroup(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,126);
        if($data['permission']->add == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..

            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/addGroup.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }
        public function doAddGroup(){
        
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,126);
        if($permission->add == 1){
            $data['name'] = $_POST['name'];
            $data['icon'] = $_POST['icon'];
            
            if($this->db->insert('group',$data)){
                $true = "Group Added Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/groups");
            }else{
                $error = "Failed To Add Group ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/groups");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }

       public function editGroup(){
        
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,126);
        if($data['permission']->edit == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,126);
            //body ..
            $id = base64_decode($_GET['t']);
            $data['group'] = $this->db->get_where('group',array('id'=>$id))->row();
            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/editGroup.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }
    public function doEditGroup($id){
         // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,126);
        if($permission->edit == 1){
            $id = base64_decode($_POST['id']);
            $data['name'] = $_POST['name'];
            $data['icon'] = $_POST['icon'];
            $this->admin_model->addToLoggerUpdate('group',126,'id',$id,0,0,$this->user);
            if($this->db->update('group',$data,array('id' =>$id))){
                $true = "Group Edited Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/groups");
            }else{
                $error = "Failed To Edit Group ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/groups");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
            public function deleteGroup($id){
         // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,126);
        if($check){
            $this->admin_model->addToLoggerDelete('group',126,'id',$id,0,0,$this->user);
            if($this->db->delete('group',array('id' =>$id))){
                $true = "Group Deleted Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/groups");
            }else{
                $error = "Failed To Delete Group ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/groups");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }
    public function task_type(){
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,124);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,124);
            //body ..
            $data['task_type'] = $this->db->get('task_type');
            // //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/task_type.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }


        public function addTaskType(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,124);
        if($data['permission']->add == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..

            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/addTaskType.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }
      public function doAddTaskType(){
        // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,124);
        if($permission->add == 1){
            $data['name'] = $_POST['name'];
            $data['parent'] = $_POST['parent'];

            
            if($this->db->insert('task_type',$data)){
                $true = "Task Type Added Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/task_type");
            }else{
                $error = "Failed To Add Task Type ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/task_type");
            }
        }else{
            echo "You have no permission to access this page";
        }  
    }

        public function editTaskType(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,124);
        if($data['permission']->edit == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..
            $data['id'] = base64_decode($_GET['t']);
            $data['task_type'] = $this->db->get_where('task_type',array('id'=>$data['id']))->row();

            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/editTaskType.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

      public function doEditTaskType(){
        // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,124);
        if($permission->edit == 1){
            $id = base64_decode($_POST['id']);
            $data['name'] = $_POST['name'];
            $data['parent'] = $_POST['parent'];
            $this->admin_model->addToLoggerUpdate('task_type',124,'id',$id,0,0,$this->user);
    
            if($this->db->update('task_type',$data,array('id'=>$id))){
                $true = "Task Type Edited Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/task_type");
            }else{
                $error = "Failed To Edit Task Type ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/task_type");
            }
        }else{
            echo "You have no permission to access this page";
        }  
    }
  
   public function deleteTaskType($id){
         // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,124);
        if($check){
            $this->admin_model->addToLoggerDelete('task_type',124,'id',$id,0,0,$this->user);
            if($this->db->delete('task_type',array('id' =>$id))){
                $true = "Task Type Deleted Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/task_type");
            }else{
                $error = "Failed To Delete Task Type ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/task_type");
            }
        }else{
            echo "You have no permission to access this page";
        }
    }

	public function operationalReport(){
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,125);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,125);
            //body ..
            $brand = $this->brand;
            if(isset($_GET['search'])){
                if(isset($_REQUEST['date_from']) && isset($_REQUEST['date_to'])){
                    $data['date_from'] = date("Y-m-d", strtotime($_REQUEST['date_from']));
                    $data['date_to'] = date("Y-m-d", strtotime("+1 day", strtotime($_REQUEST['date_to'])));
                }else{
                    $data['date_from'] = "2018-01-01";
                    $data['date_to'] = date("Y-m-d");
                }
                if(isset($_REQUEST['report'])){ 
                    $data['report'] = $_REQUEST['report'];
                    if($data['report'] == 1){
                         $data['pm'] = $this->db->query(" SELECT u.id,u.user_name FROM users AS u WHERE (u.role = '2' OR u.role = '29' OR u.role = '16' OR role = '20') AND u.brand = '$this->brand' ");
                    }elseif ($data['report'] == 3) {
                         //$data['customer'] = $this->db->query(" SELECT c.id,c.name,c.brand,c.status,l.id AS leadID,l.customer,l.region FROM customer AS c LEFT OUTER JOIN customer_leads AS l ON l.customer = c.id WHERE c.status = '2' AND brand = '$this->brand' ORDER BY c.name ASC  ");
                         $data['customer'] = $this->db->query(" SELECT c.id,c.name,c.brand,c.status,l.id AS leadID,l.customer,l.region FROM customer_leads AS l LEFT OUTER JOIN customer AS c ON l.customer = c.id HAVING c.status = '2' AND brand = '$this->brand' ORDER BY c.name ASC ");
                    }elseif ($data['report'] == 4) {
                         $data['sam'] = $this->db->query(" SELECT u.id,u.user_name FROM users AS u WHERE u.status = '1' AND (u.role = '3' OR u.role = '29' OR role = '12' OR role = '20') AND u.brand = '$this->brand' ");
                     }elseif ($data['report'] == 2) {
                     	 $data['sam'] = $this->db->query(" SELECT u.id,u.user_name FROM users AS u WHERE u.status = '1' AND (u.role = '3' OR u.role = '29' OR role = '12' OR role = '20') AND u.brand = '$this->brand' ");
                 	 }
                }                
            }else{
                $data['report'] = 0;
            }
            //Pages ..
            $this->load->view('includes/header.php',$data);
            $this->load->view('admin/operationalReport.php');
            $this->load->view('includes/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }
    }

	public function exportOperationalReport(){
        $file_type = "vnd.ms-excel";
        $file_ending = "xls";
        //$file_type = "msword";
        //$file_ending = "doc";
        header("Content-Type: application/$file_type");
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,125);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,125);
            //body ..
            $brand = $this->brand;
            if(isset($_REQUEST['date_from']) && isset($_REQUEST['date_to'])){
                $data['date_from'] = date("Y-m-d", strtotime($_REQUEST['date_from']));
                $data['date_to'] = date("Y-m-d", strtotime("+1 day", strtotime($_REQUEST['date_to'])));
            }else{
                $data['date_from'] = "2018-01-01";
                $data['date_to'] = date("Y-m-d");
            }
            if(isset($_REQUEST['report'])){
                $data['report'] = $_REQUEST['report'];
                if($data['report'] == 1){
                	 header("Content-Disposition: attachment; filename=operationalReportBYPM.$file_ending");
       				 header("Pragma: no-cache");
       				 header("Expires: 0");
                     $data['pm'] = $this->db->query(" SELECT u.id,u.user_name FROM users AS u WHERE (u.role = '2' OR u.role = '29' OR u.role = '16' OR role = '20') AND u.brand = '$this->brand' ");
                 }elseif ($data['report'] == 3) {
                	 header("Content-Disposition: attachment; filename=operationalReportBYCustomer.$file_ending");
       				 header("Pragma: no-cache");
       				 header("Expires: 0");
                     // $data['customer'] = $this->db->query(" SELECT c.id,c.name,c.brand,c.status,l.id AS leadID,l.customer,l.region FROM customer AS c LEFT OUTER JOIN customer_leads AS l ON l.customer = c.id WHERE c.status = '2' AND brand = '$this->brand' ORDER BY c.name ASC  ");
                     $data['customer'] = $this->db->query(" SELECT c.id,c.name,c.brand,c.status,l.id AS leadID,l.customer,l.region FROM customer_leads AS l LEFT OUTER JOIN customer AS c ON l.customer = c.id HAVING c.status = '2' AND brand = '$this->brand' ORDER BY c.name ASC ");
                 }elseif ($data['report'] == 4) {
                	 header("Content-Disposition: attachment; filename=operationalReportSAMActivities.$file_ending");
       				 header("Pragma: no-cache");
       				 header("Expires: 0");
                     $data['sam'] = $this->db->query(" SELECT u.id,u.user_name FROM users AS u WHERE u.status = '1' AND (u.role = '3' OR u.role = '29' OR role = '12' OR role = '20') AND u.brand = '$this->brand' ");
                 }elseif ($data['report'] == 2) {
                	 header("Content-Disposition: attachment; filename=operationalReportBYSAM.$file_ending");
       				 header("Pragma: no-cache");
       				 header("Expires: 0");
                     $data['sam'] = $this->db->query(" SELECT u.id,u.user_name FROM users AS u WHERE u.status = '1' AND (u.role = '3' OR u.role = '29' OR role = '12' OR role = '20') AND u.brand = '$this->brand' ");
                 }
            }                
            //Pages ..
            $this->load->view('admin/exportOperationalReport.php',$data);
        }else{
            echo "You have no permission to access this page";
        }
    }


	public function exportAllCPOsWithZero(){
        $file_type = "vnd.ms-excel";
        $file_ending = "xls";
        //$file_type = "msword";
        //$file_ending = "doc";
        
    	header("Content-Type: application/$file_type");
        header("Content-Disposition: attachment; filename=Customers.$file_ending");
        header("Pragma: no-cache");
        header("Expires: 0");

        $data = $this->db->query(" SELECT p.number,p.verified,j.id,j.code AS job_code,j.type,j.volume,j.price_list,t.code AS task_code,t.count,t.rate,t.currency FROM po AS p LEFT OUTER JOIN job AS j ON j.po = p.id LEFT OUTER JOIN job_task AS t ON t.job_id = j.id WHERE p.verified = 0 ORDER BY j.code DESC  ")->result();
        $html = '<!DOCTYPE ><html dir=ltr>
                    <head>
                <style>
                @media print {
                table {font-size: smaller; }
                thead {display: table-header-group; }
                table { page-break-inside:auto; width:75%; }
                tr { page-break-inside:avoid; page-break-after:auto; }
                }
                table {
                  border: 1px solid black;
                  font-size:18px;
                }
                table td {
                  border: 1px solid black;
                }
                table th {
                  border: 1px solid black;
                }
                .clr{
                  background-color: #EEEEEE;
                  text-align: center;
                }
                .clr1 {
                background-color: #FFFFCC;
                  text-align: center;
                }
                </style>
                </head>
                <body>
                <table id="datatable-fixed-header" class="table table-striped table-bordered dataTable no-footer" role="grid" aria-describedby="datatable-fixed-header_info">
                    <thead>
                    <th>PO Number</th>
                    <th>Po Status</th>
                    <th>Job Code</th>
                    <th>Total Revenue</th>
                    <th>Task Code</th>
                    <th>Total Cost</th>
                    <th>Currency</th>
                    </thead><tbody>';
        foreach ($data as $row) {
        	$priceList = $this->projects_model->getJobPriceListData($row->price_list);
            $jobTotal = $this->sales_model->calculateRevenueJob($row->id,$row->type,$row->volume,$priceList->id);
            $html .= '<tr class="">
                    <td>'.$row->number.'</td>
                    <td>'.$row->verified.'</td>
                    <td>'.$row->job_code.'</td>
                    <td>'.$jobTotal.'</td>
                    <td>'.$row->task_code.'</td>
                    <td>'.$row->rate*$row->count.'</td>
                    <td>'.$this->admin_model->getCurrency($row->currency).'</td>
                    </tr>';
        }
        $html .= '</tbody></table>';

        echo $html;

    }

	public function translationBatch1Finance(){
    	$file_type = "vnd.ms-excel";
        $file_ending = "xls";
        //$file_type = "msword";
        //$file_ending = "doc";
        
    	header("Content-Type: application/$file_type");
    	header("Content-Disposition: attachment; filename=translation_1.$file_ending");
    	header("Pragma: no-cache");
    	header("Expires: 0");
       	// $translationTTG = $this->db->get_where('translation_memory_out',array('file_name'=>1))->result();
       	$translationTTG = $this->db->query(" SELECT * FROM `translation_memory_out` WHERE file_name = '1' ORDER BY `translation_memory_out`.`id` ASC LIMIT 100 OFFSET 400 ")->result();
        $html = '<!DOCTYPE ><html dir=ltr>
                    <head>
                <style>
                @media print {
                table {font-size: smaller; }
                thead {display: table-header-group; }
                table { page-break-inside:auto; width:75%; }
                tr { page-break-inside:avoid; page-break-after:auto; }
                }
                table {
                  border: 1px solid black;
                  font-size:18px;
                }
                table td {
                  border: 1px solid black;
                }
                table th {
                  border: 1px solid black;
                }
                .clr{
                  background-color: #EEEEEE;
                  text-align: center;
                }
                .clr1 {
                background-color: #FFFFCC;
                  text-align: center;
                }
                </style>
                </head>
                <body>
                <table id="datatable-fixed-header" class="table table-striped table-bordered dataTable no-footer" role="grid" aria-describedby="datatable-fixed-header_info">
                    <thead>
                    <th>Word</th>
                    <th>Similarities</th>
                    </thead><tbody>';
        	foreach($translationTTG as $translationTTG){
            	$row = explode(" ",$translationTTG->translation);
            	for($i=0;$i<count($row);$i++){
                	$result =  str_replace(".","",str_replace("”","",str_replace(",","",str_replace('“', "",$row[$i]))));
                $html .= '<tr class="">';
                $html.= '<td>'.$result.'</td>';
                $html.= '<td>';
                	if(strlen($result) > 0){
                    	$translationClient = $this->db->like('translation',$result,'both')->get_where('translation_memory',array('file_name'=>1));
                    	foreach($translationClient->result() as $res){
                		$html.= '<table>
                        				<tr>
                                        	<td>'.$res->translation.'<td>
                                        </tr>
                                      </table>';
                        }
                		$html.= '</td>';                
                    }
                $html.='</tr>';
                }
            }
        	$html .= '</tbody></table>';
        	echo $html;
    }

	public function translationBatch1Edu(){
    	$file_type = "vnd.ms-excel";
        $file_ending = "xls";
        //$file_type = "msword";
        //$file_ending = "doc";
        
    	// header("Content-Type: application/$file_type");
    	// header("Content-Disposition: attachment; filename=translation_1.$file_ending");
    	// header("Pragma: no-cache");
    	// header("Expires: 0");
        	$translationTTG = $this->db->get_where('translation_memory_out',array('file_name'=>2))->result();
        $html = '<!DOCTYPE ><html dir=ltr>
                    <head>
                <style>
                @media print {
                table {font-size: smaller; }
                thead {display: table-header-group; }
                table { page-break-inside:auto; width:75%; }
                tr { page-break-inside:avoid; page-break-after:auto; }
                }
                table {
                  border: 1px solid black;
                  font-size:18px;
                }
                table td {
                  border: 1px solid black;
                }
                table th {
                  border: 1px solid black;
                }
                .clr{
                  background-color: #EEEEEE;
                  text-align: center;
                }
                .clr1 {
                background-color: #FFFFCC;
                  text-align: center;
                }
                </style>
                </head>
                <body>
                <table id="datatable-fixed-header" class="table table-striped table-bordered dataTable no-footer" role="grid" aria-describedby="datatable-fixed-header_info">
                    <thead>
                    <th>Word</th>
                    <th>Similarities</th>
                    </thead><tbody>';
        	foreach($translationTTG as $translationTTG){
            	$row = explode(" ",$translationTTG->translation);
            	for($i=0;$i<count($row);$i++){
                	$result =  str_replace(".","",str_replace("”","",str_replace(",","",str_replace('“', "",$row[$i]))));
                $html .= '<tr class="">';
                $html.= '<td>'.$result.'</td>';
                $html.= '<td>';
                	if(strlen($result) > 0){
                    	$translationClient = $this->db->like('translation',$result,'both')->get_where('translation_memory',array('file_name'=>2));
                    	foreach($translationClient->result() as $res){
                		$html.= '<table>
                        				<tr>
                                        	<td>'.$res->translation.'<td>
                                        </tr>
                                      </table>';
                        }
                		$html.= '</td>';                
                    }
                $html.='</tr>';
                }
            }
        	$html .= '</tbody></table>';
        	echo $html;
    }

	public function translationBatch2Government(){
    	$file_type = "vnd.ms-excel";
        $file_ending = "xls";
        //$file_type = "msword";
        //$file_ending = "doc";
        
    	// header("Content-Type: application/$file_type");
    	// header("Content-Disposition: attachment; filename=translation_1.$file_ending");
    	// header("Pragma: no-cache");
    	// header("Expires: 0");
        	$translationTTG = $this->db->get_where('translation_memory_out',array('file_name'=>3))->result();
        $html = '<!DOCTYPE ><html dir=ltr>
                    <head>
                <style>
                @media print {
                table {font-size: smaller; }
                thead {display: table-header-group; }
                table { page-break-inside:auto; width:75%; }
                tr { page-break-inside:avoid; page-break-after:auto; }
                }
                table {
                  border: 1px solid black;
                  font-size:18px;
                }
                table td {
                  border: 1px solid black;
                }
                table th {
                  border: 1px solid black;
                }
                .clr{
                  background-color: #EEEEEE;
                  text-align: center;
                }
                .clr1 {
                background-color: #FFFFCC;
                  text-align: center;
                }
                </style>
                </head>
                <body>
                <table id="datatable-fixed-header" class="table table-striped table-bordered dataTable no-footer" role="grid" aria-describedby="datatable-fixed-header_info">
                    <thead>
                    <th>Word</th>
                    <th>Similarities</th>
                    </thead><tbody>';
        	foreach($translationTTG as $translationTTG){
            	$row = explode(" ",$translationTTG->translation);
            	for($i=0;$i<count($row);$i++){
                	$result =  str_replace(".","",str_replace("”","",str_replace(",","",str_replace('“', "",$row[$i]))));
                $html .= '<tr class="">';
                $html.= '<td>'.$result.'</td>';
                $html.= '<td>';
                	if(strlen($result) > 0){
                    	$translationClient = $this->db->like('translation',$result,'both')->get_where('translation_memory',array('file_name'=>3));
                    	foreach($translationClient->result() as $res){
                		$html.= '<table>
                        				<tr>
                                        	<td>'.$res->translation.'<td>
                                        </tr>
                                      </table>';
                        }
                		$html.= '</td>';                
                    }
                $html.='</tr>';
                }
            }
        	$html .= '</tbody></table>';
        	echo $html;
    }

	public function translationBatch3Technical(){
    	$file_type = "vnd.ms-excel";
        $file_ending = "xls";
        //$file_type = "msword";
        //$file_ending = "doc";
        
    	// header("Content-Type: application/$file_type");
    	// header("Content-Disposition: attachment; filename=translation_1.$file_ending");
    	// header("Pragma: no-cache");
    	// header("Expires: 0");
        	$translationTTG = $this->db->get_where('translation_memory_out',array('file_name'=>4))->result();
        $html = '<!DOCTYPE ><html dir=ltr>
                    <head>
                <style>
                @media print {
                table {font-size: smaller; }
                thead {display: table-header-group; }
                table { page-break-inside:auto; width:75%; }
                tr { page-break-inside:avoid; page-break-after:auto; }
                }
                table {
                  border: 1px solid black;
                  font-size:18px;
                }
                table td {
                  border: 1px solid black;
                }
                table th {
                  border: 1px solid black;
                }
                .clr{
                  background-color: #EEEEEE;
                  text-align: center;
                }
                .clr1 {
                background-color: #FFFFCC;
                  text-align: center;
                }
                </style>
                </head>
                <body>
                <table id="datatable-fixed-header" class="table table-striped table-bordered dataTable no-footer" role="grid" aria-describedby="datatable-fixed-header_info">
                    <thead>
                    <th>Word</th>
                    <th>Similarities</th>
                    </thead><tbody>';
        	foreach($translationTTG as $translationTTG){
            	$row = explode(" ",$translationTTG->translation);
            	for($i=0;$i<count($row);$i++){
                	$result =  str_replace(".","",str_replace("”","",str_replace(",","",str_replace('“', "",$row[$i]))));
                $html .= '<tr class="">';
                $html.= '<td>'.$result.'</td>';
                $html.= '<td>';
                	if(strlen($result) > 0){
                    	$translationClient = $this->db->like('translation',$result,'both')->get_where('translation_memory',array('file_name'=>4));
                    	foreach($translationClient->result() as $res){
                		$html.= '<table>
                        				<tr>
                                        	<td>'.$res->translation.'<td>
                                        </tr>
                                      </table>';
                        }
                		$html.= '</td>';                
                    }
                $html.='</tr>';
                }
            }
        	$html .= '</tbody></table>';
        	echo $html;
    }

	public function translationBatch3Travel(){
    	$file_type = "vnd.ms-excel";
        $file_ending = "xls";
        //$file_type = "msword";
        //$file_ending = "doc";
        
    	// header("Content-Type: application/$file_type");
    	// header("Content-Disposition: attachment; filename=translation_1.$file_ending");
    	// header("Pragma: no-cache");
    	// header("Expires: 0");
        	$translationTTG = $this->db->get_where('translation_memory_out',array('file_name'=>5))->result();
        $html = '<!DOCTYPE ><html dir=ltr>
                    <head>
                <style>
                @media print {
                table {font-size: smaller; }
                thead {display: table-header-group; }
                table { page-break-inside:auto; width:75%; }
                tr { page-break-inside:avoid; page-break-after:auto; }
                }
                table {
                  border: 1px solid black;
                  font-size:18px;
                }
                table td {
                  border: 1px solid black;
                }
                table th {
                  border: 1px solid black;
                }
                .clr{
                  background-color: #EEEEEE;
                  text-align: center;
                }
                .clr1 {
                background-color: #FFFFCC;
                  text-align: center;
                }
                </style>
                </head>
                <body>
                <table id="datatable-fixed-header" class="table table-striped table-bordered dataTable no-footer" role="grid" aria-describedby="datatable-fixed-header_info">
                    <thead>
                    <th>Word</th>
                    <th>Similarities</th>
                    </thead><tbody>';
        	foreach($translationTTG as $translationTTG){
            	$row = explode(" ",$translationTTG->translation);
            	for($i=0;$i<count($row);$i++){
                	$result =  str_replace(".","",str_replace("”","",str_replace(",","",str_replace('“', "",$row[$i]))));
                $html .= '<tr class="">';
                $html.= '<td>'.$result.'</td>';
                $html.= '<td>';
                	if(strlen($result) > 0){
                    	$translationClient = $this->db->like('translation',$result,'both')->get_where('translation_memory',array('file_name'=>5));
                    	foreach($translationClient->result() as $res){
                		$html.= '<table>
                        				<tr>
                                        	<td>'.$res->translation.'<td>
                                        </tr>
                                      </table>';
                        }
                		$html.= '</td>';                
                    }
                $html.='</tr>';
                }
            }
        	$html .= '</tbody></table>';
        	echo $html;
    }

    public function sendVPOMail(){
        
        $mailTo = "mohamedtwins57@gmail.com";
        // $mailTo = "mohamed.elshehaby@thetranslationgate.com";
        $subject = "Vendor VPO Test ";
        
        $config = Array(
        'protocol' => 'smtp',
        'smtp_host' => 'mail.thetranslationgate.com',
        'smtp_port' => 465,
        'smtp_user' => 'falaqsystem@thetranslationgate.com',
        'smtp_pass' => 'GaU6FjtJ$*Hb8P-j',
        'charset'=>'utf-8',
         'validate'=>TRUE,
        'wordwrap'=> TRUE,
        'dkim_domain' => 'thetranslationgate.com',
        'dkim_private' => '/home/ubuntu/mail.private',
        'dkim_selector' => 'mail',
        'dkim_passphrase' => '',
      );

      $this->load->library('email', $config);
      $this->email->set_newline("\r\n");
      $this->email->from("mohamed.elshehaby@thetranslationgate.com");
      $this->email->cc("mohamed.elshehaby@thetranslationgate.com");
      // replace my mail by pm manger it is just for testing
      $this->email->to($mailTo);
      $this->email->subject($subject);

        	$msg="Test";
            //echo $msg;
            $this->email->message($msg);
              $this->email->set_header('Reply-To', $pmMail);
              $this->email->set_mailtype('html');
              $this->email->send();
    }

         public function translationManagemet(){
        // Check Permission ..
        $check = $this->admin_model->checkPermission($this->role,178);
        if($check){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,178);
            //body ..
            $data['users'] = $this->db->get_where('users' ,array('role' => 27, 'status' => 1));
            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/translationManagemet.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

        public function editTranslationManagement(){
        // Check Permission ..
        $data['permission'] = $this->admin_model->getScreenByPermissionByRole($this->role,178);
        if($data['permission']->edit == 1){
            //header ..
            $data['group'] = $this->admin_model->getGroupByRole($this->role);
            //body ..
            $data['id'] = base64_decode($_GET['t']);
            $data['row'] = $this->db->get_where('users',array('id'=>$data['id']))->row();

            //Pages ..
            $this->load->view('includes_new/header.php',$data);
            $this->load->view('admin_new/editTranslationManagement.php');
            $this->load->view('includes_new/footer.php'); 
        }else{
            echo "You have no permission to access this page";
        }  
    }

        public function doEditTranslationManagement(){
        // Check Permission ..
        $permission = $this->admin_model->getScreenByPermissionByRole($this->role,178);
        if($permission->edit == 1){
            $id = $this->uri->segment(3);
            $data['teamleader'] = $_POST['teamleader'];
            
            if($this->db->update('users',$data,array('id'=>$id))){
                $true = "Edited Successfully ...";
                $this->session->set_flashdata('true', $true);
                redirect(base_url()."admin/translationManagemet");
            }else{
                $error = "Failed To Edit ...";
                $this->session->set_flashdata('error', $error);
                redirect(base_url()."admin/translationManagemet");
            }
        }else{
            echo "You have no permission to access this page";
        }  
    }
  


}
?>
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Auth
*
* Author:  MOHAMED EL-SHEHABY
*
*/

class Hr_model extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
  
  	public function meetingMail($data){
        $attendees = explode(";",$data['attendees']);
        $MailTo = $attendees[0];
    	$subject = $data['title'];
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        for ($i=1; $i < count($attendees); $i++) { 
            $headers .= "Cc: ".$attendees[$i]. "\r\n";
        }
    
    	$headers .= "Cc: asmaa.saafan@thetranslationgate.com" . "\r\n";
        $headers .= 'From: asmaa.saafan@thetranslationgate.com'."\r\n".'Reply-To: asmaa.saafan@thetranslationgate.com'."\r\n";
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        '.$data['description'].'
                    </body>
                    </html>';

        //echo $message;
        mail($MailTo,$subject,$message,$headers);
    }

	public function meetingMailRemainder($data){
        $MailTo = $data->attendees;
        $subject = $data->title;
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "Cc: asmaa.saafan@thetranslationgate.com" . "\r\n";
        $headers .= "Cc: mohamed.elshehaby@thetranslationgate.com" . "\r\n";
        $headers .= 'From: asmaa.saafan@thetranslationgate.com'."\r\n".'Reply-To: asmaa.saafan@thetranslationgate.com'."\r\n";
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                        <p>This email is just a reminder that the next '.$data->subject.' meeting will be held on '.$data->start.' in the Meeting Room. </p>
                        <p>Thank You!</p>
                    </body>
                    </html>';

        echo $message;
        mail($MailTo,$subject,$message,$headers);
    }

    public function getDepartment($department){
        $result = $this->db->get_where('department',array('id' => $department))->row();
        if(isset($result->name)){
            return $result->name;
        }else{
            return '';
        }
    }

        public function selectDepartment($id="",$division=0)
    {
        $department = $this->db->get_where('department',array('brand'=>$this->brand,'division'=>$division))->result();
        $data = "<option disabled='disabled' value='' selected=''>-- Select Department --</option>";
        foreach ($department as $department) {
            if ($department->id == $id) {
                $data .= "<option value='" . $department->id . "' selected='selected'>" . $department->name . "</option>";
            } else {
                $data .= "<option value='" . $department->id . "'>" . $department->name . "</option>";
            }
        }
        return $data;
    }

        public function getDivision($division){
        $result = $this->db->get_where('division',array('id' => $division))->row();
        if(isset($result->name)){
            return $result->name;
        }else{
            return '';
        }
    }

        public function selectDivision($id="")
    {
        $division = $this->db->get_where('division',array('brand'=>$this->brand))->result();
        $data = "";
        foreach ($division as $division) {
            if ($division->id == $id) {
                $data .= "<option value='" . $division->id . "' selected='selected'>" . $division->name . "</option>";
            } else {
                $data .= "<option value='" . $division->id . "'>" . $division->name . "</option>";
            }
        }
        return $data;
    }

        public function getTitle($title){
        $result = $this->db->get_where('structure',array('id' => $title))->row();
        if(isset($result->title)){
            return $result->title;
        }else{
            return '';
        }
    }


        public function selectTitle($id="")
    {
        $title = $this->db->get('structure')->result();
        $data = "";
        foreach ($title as $title) {
            if ($title->id == $id) {
                $data .= "<option value='" . $title->id . "' selected='selected'>" . $title->title . "</option>";
            } else {
                $data .= "<option value='" . $title->id . "'>" . $title->title . "</option>";
            }
        }
        return $data;
    }


        public function selectPosition($id="",$department=0,$division=0)
    {
        $title = $this->db->get_where('structure',array('division'=>$division,'department'=>$department,'brand'=>$this->brand))->result();
         $data = "<option disabled='disabled' value='' selected=''>-- Select Position --</option>";
        foreach ($title as $title) {
            if ($title->id == $id) {
                $data .= "<option value='" . $title->id . "' selected='selected'>" . $title->title . "</option>";
            } else {
                $data .= "<option value='" . $title->id . "'>" . $title->title . "</option>";
            }
        }
        return $data;
    }

       public function selectEmployee($id="")
    {
        $employee = $this->db->get('employees')->result();
        $data = "";
        foreach ($employee as $employee) {
            if ($employee->id == $id) {
                $data .= "<option value='" . $employee->id . "' selected='selected'>" . $employee->name . "</option>";
            } else {
                $data .= "<option value='" . $employee->id . "'>" . $employee->name . "</option>";
            }
        }
        return $data;
    }

        public function selectTrack($id="")
    {
        $track = $this->db->get('track')->result();
        $data = "";
        foreach ($track as $track) {
            if ($track->id == $id) {
                $data .= "<option value='" . $track->id . "' selected='selected'>" . $track->name . "</option>";
            } else {
                $data .= "<option value='" . $track->id . "'>" . $track->name . "</option>";
            }
        }
        return $data;
    }

        public function getTrack($track){
        $result = $this->db->get_where('track',array('id' => $track))->row();
        if(isset($result->name)){
            return $result->name;
        }else{
            return '';
        }
    }



	public function getEmployee($employee){
		$result = $this->db->get_where('employees',array('id' => $employee))->row();
		if(isset($result->name)){
			return $result->name;
		}else{
			return '';
		}
	}

        public function AllEmployees($brand,$filter)
    {

        $data = $this->db->query(" SELECT * FROM `employees` WHERE ".$filter." AND brand = '$brand' ORDER BY id ASC , id DESC ");
        return $data;
    }

    public function AllEmployeesPages($brand,$limit,$offset)
    {
        $data = $this->db->query("SELECT * FROM `employees` WHERE brand = '$brand' ORDER BY id ASC , id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }


        public function AllMedicalInsurance($brand,$filter)
    {

        $data = $this->db->query(" SELECT * FROM `medical_insurance` WHERE ".$filter." AND brand = '$brand' ORDER BY id ASC , id DESC ");
        return $data;
    }

    public function AllMedicalInsurancePages($brand,$limit,$offset)
    {
        $data = $this->db->query("SELECT * FROM `medical_insurance` WHERE brand = '$brand' ORDER BY id ASC , id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

    public function AllStructure($brand,$filter)
    {

        $data = $this->db->query(" SELECT * FROM `structure` WHERE ".$filter." AND brand = '$brand' ORDER BY id ASC , id DESC ");
        return $data;
    }

    public function AllStructurePages($brand,$limit,$offset)
    {
        $data = $this->db->query("SELECT * FROM `structure` WHERE brand = '$brand' ORDER BY id ASC , id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

    public function AllDepartment($brand,$filter)
    {

        $data = $this->db->query(" SELECT * FROM `department` WHERE ".$filter." AND brand = '$brand' ORDER BY id ASC , id DESC ");
        return $data;
    }

    public function AllDepartmentPages($brand,$limit,$offset)
    {
        $data = $this->db->query("SELECT * FROM `department` WHERE brand = '$brand' ORDER BY id ASC , id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

        public function AllDivision($brand,$filter)
    {

        $data = $this->db->query(" SELECT * FROM `division` WHERE ".$filter." AND brand = '$brand' ORDER BY id ASC , id DESC ");
        return $data;
    }

    public function AllDivisionPages($brand,$limit,$offset)
    {
        $data = $this->db->query("SELECT * FROM `division` WHERE brand = '$brand' ORDER BY id ASC , id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    }

	/*public function attendance($permission,$filter){
    	if($permission->view == 1){
        	$ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "http://attendance.thetranslationgate.com/abc/index.php/api/attendanceLog");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        	curl_setopt($cURL_Handle, CURLOPT_BUFFERSIZE, 1000000);
			curl_setopt($cURL_Handle, CURLOPT_NOPROGRESS, false);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_TIMEOUT, 100);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, "filter=$filter");
            $data = json_decode(curl_exec($ch),TRUE);
        }elseif($permission->view == 2){
        	$userData = $this->db->get_where('users',array('id'=>$this->user))->row()->employees_id;
        	$ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "http://attendance.thetranslationgate.com/abc/index.php/api/attendanceLogByUser");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        	curl_setopt($cURL_Handle, CURLOPT_BUFFERSIZE, 1000000);
			curl_setopt($cURL_Handle, CURLOPT_NOPROGRESS, false);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_TIMEOUT, 100);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, "filter=$filter&USRID=$userData");
            $data = json_decode(curl_exec($ch),TRUE);
        }
    	return $data;
    }*/

	public function attendance($permission,$filter){
    	if($permission->view == 1){
        	//All ..
        	$attendanceArr = array();

        	$data = $this->db->query(" SELECT DISTINCT USRID,(SELECT SRVDT FROM attendance_log AS log WHERE log.USRID = l.USRID AND TNAKEY = '1' AND DATE(log.SRVDT) = DATE(l.SRVDT) 
            							ORDER BY log.id ASC LIMIT 1) AS SignIn FROM attendance_log AS l
         								WHERE ".$filter."")->result();
        }elseif($permission->view == 2){
        	//BY USER ..
        	$userData = $this->db->get_where('users',array('id'=>$this->user))->row()->employees_id;
        	$data = $this->db->query(" SELECT DISTINCT USRID,(SELECT SRVDT FROM attendance_log AS log WHERE log.USRID = l.USRID AND TNAKEY = '1' AND DATE(log.SRVDT) = DATE(l.SRVDT) 
            							ORDER BY log.id ASC LIMIT 1) AS SignIn FROM attendance_log AS l
         								WHERE ".$filter." AND l.USRID = '$userData'")->result();
        }
    	return $data;
    }

	public function remoteAttendance($data){
    		$SRVDT = $data['SRVDT'];
    		$USRID = $data['USRID'];
    		$TNAKEY = $data['TNAKEY'];
        	$ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "http://attendance.thetranslationgate.com/abc/index.php/api/remoteAttendance");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_TIMEOUT, 100);
            curl_setopt($ch, CURLOPT_POST, 1);
        	curl_setopt($ch, CURLOPT_POSTFIELDS, "SRVDT=$SRVDT&USRID=$USRID&TNAKEY=$TNAKEY");
        	$data = curl_exec($ch);
    	return $data;
    }

    ////////
      //vacation
    //start vacation
    public function selectAllVacationTypies($id='')
    {
        $vacation_types = $this->db->query("SELECT * FROM vacation_types")->result();
        $data = "";
        foreach ($vacation_types as $vacation_types) {
            if ($vacation_types->id == $id) {
                $data .= "<option value='" . $vacation_types->id . "' selected='selected'>" . $vacation_types->name . "</option>";
            } else {
                $data .= "<option value='" . $vacation_types->id . "'>" . $vacation_types->name . "</option>";
            }
        }
        return $data;
    }
    public function getAllVacationTypies($id='')
    {    
        $vacation_types = $this->db->query("SELECT * FROM vacation_types WHERE id = '$id'")->row();
        if(isset($vacation_types->name)){
            return $vacation_types->name;
        }else{
            return '';
        }

    }
    
    public function getRequestsForDirectManager($emp_id){
         $title = $this->db->query(" SELECT title FROM employees WHERE id = '$emp_id' ")->row()->title; 
         if($title == 37){
            /* $data = $this->db->query("SELECT * FROM vacation_transaction WHERE emp_id in (SELECT id FROM employees WHERE title in(11,15,16,17,28,37,40,44,48,51,54,56,59))");*/
            $data = $this->db->query("SELECT * FROM vacation_transaction WHERE emp_id in (SELECT id FROM employees WHERE manager in(13,14))HAVING status = 0 ");
         }else{
           $data = $this->db->query("SELECT * FROM vacation_transaction WHERE emp_id in (SELECT id FROM employees WHERE title in (SELECT id FROM structure WHERE parent = (SELECT title FROM employees WHERE id = '$emp_id'))) HAVING status = 0 ");
         }
        return $data;
     } 
     public function getManagerId($emp_id){
        $data = $this->db->query("SELECT id From employees WHERE title = (SELECT parent FROM structure WHERE id = (SELECT title FROM employees WHERE id = '$emp_id'))");
        return $data->row()->id; 
     }  

     public function getUser($emb_id){
        $result = $this->db->get_where('users',array('employees_id' => $emb_id))->row();
        if(isset($result->user_name)){
            return $result->user_name;
        }else{
            return '';
        }
    } 
    ///5/8/2020
     public function getEmpName($emb_id){
        $result = $this->db->get_where('employees',array('id' => $emb_id))->row();
        if(isset($result->name)){
            return $result->name;
        }else{
            return '';
        }
    } 
    public function getEmpId ($user_id){
        $result = $this->db->get_where('users',array('id' => $user_id))->row();
        if(isset($result->employees_id)){
            return $result->employees_id;
        }else{
            return '';
        }
    }
    //vacation status
     public function getVacationStatus($select=""){
        if($select == 1){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #07b817">approved</span>';
        }
        else if($select == 2){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #fb0404">Rejected</span>';
        }else if($select == 0){
            $outpt = '<span class="badge badge-danger p-2" style="background-color: #e8e806">Waiting Confirmation</span>';
        }else{
            $outpt = "";
        }
        return $outpt;
    }
 

   public function calculateAvailableVacationDays($type_of_vacation,$id,$death_leave_degree){
        ///to retrive the balance for employees  (avialable days)
        /// get availabale credite of days depend on the vacation type 
            $data = $this->db->query(" SELECT * FROM vacation_balance WHERE emp_id = '$id'");
           if($type_of_vacation == 1){ 
            //annual leave
            $month = date('m');
                  if($month <= 3){
                      return $data->row()->current_year + $data->row()->previous_year ;
                  }else{
                       return $data->row()->current_year;       
                  }
             
           }elseif ($type_of_vacation == 2) {
               //casual leave
                $remainOfCasual = 6 - $data->row()->casual_leave;
                $total_balance = $data->row()->current_year; 
                    if($total_balance >= 0){
                        $totalRemaining = $total_balance - $remainOfCasual ;
                            if($totalRemaining > 0 ){ 
                                return $remainOfCasual;
                            }elseif($totalRemaining <= $remainOfCasual){  
                               
                                return $total_balance;
                            }
                    }else {
                        return $data;
                    } 
           }elseif ($type_of_vacation == 3) {
            //for sick leave
               return $data->row()->sick_leave;
           }elseif ($type_of_vacation == 4) {
            //for mariage leave
                return $data->row()->marriage;
           }elseif ($type_of_vacation == 5) {
            //for Maternity Leave
               return $data->row()->maternity_leave;
           }elseif ($type_of_vacation == 6) {
            //for Death Leave
              if($death_leave_degree == 1){
                return 3;
              }elseif ($death_leave_degree == 2) {
                 return 1;
              }
           }elseif ($type_of_vacation == 7) {
               //for Hajj 
            return $data->row()->hajj;
            }
    } 
    public function checkVacationCredite($type_of_vacation,$days,$id){
        //to check if the employee has engouph credit to suptract the days from  
         //$data = $this->db->query(" SELECT * FROM vacation_balance WHERE emp_id = (SELECT employees_id FROM users WHERE id = '$id')");
        $data = $this->db->query(" SELECT * FROM vacation_balance WHERE emp_id = '$id'");
           if($type_of_vacation == 1){ 
            //annual leave 
                  $month = date('m');
                  if($month <= 3){
                     return ($data->row()->current_year + $data->row()->previous_year )- $days;
                  }else{
                      return $data->row()->current_year - $days;
                  }

           }elseif ($type_of_vacation == 2) {
               //casual leave
                $remainOfCasual = 6 - $data->row()->casual_leave;
                $total_balance = $data->row()->current_year; 
                    if($total_balance >= 0){
                        $totalRemaining = $total_balance - $remainOfCasual ;
                            if($totalRemaining > 0 ){ 
                                return $remainOfCasual - $days;
                            }elseif($totalRemaining <= $remainOfCasual){  
                                return $total_balance - $days;
                            }
                    }else {
                        return $data;
                    } 
           }elseif ($type_of_vacation == 3) {
            //for sick leave
               return $data->row()->sick_leave - $days;
           }elseif ($type_of_vacation == 4) {
            //for mariage leave
                return $data->row()->marriage;
           }elseif ($type_of_vacation == 5) {
            //for Maternity Leave
               return $data->row()->maternity_leave;
           }elseif ($type_of_vacation == 7) {
               //for Hajj 
            return $data->row()->hajj;
            }
       
    } 
   public function updataVacationBalance ($days,$id,$typeOfVacation){
       $credite = $this->db->get_where('vacation_balance',array('emp_id'=>$id))->row();
       $month = date('m');
       if($typeOfVacation == 1){
           //annual
           $data['annual_leave'] = $credite->annual_leave + $days;
                if($credite->previous_year > 0 && $month <= 3){
                    if($days <= $credite->previous_year){
                      $data['previous_year'] = $credite->previous_year - $days;
                    }else{
                      $temp = $days - $credite->previous_year ;
                      $this->db->query("UPDATE vacation_balance SET previous_year = '0' WHERE emp_id = '$id'");
                      $data['current_year'] = $credite->current_year - $temp; 
                    }
                }else{
                    $data['current_year'] = $credite->current_year - $days;
                } 
           $this->db->update('vacation_balance',$data,array('emp_id'=>$id));
           $this->admin_model->addToLoggerUpdate('vacation_balance',143,'id',$this->db->insert_id(),102,102,$this->user);

       }elseif($typeOfVacation == 2){
           //casual
           $data['casual_leave'] = $credite->casual_leave + $days;
               
           $data['current_year'] = $credite->current_year - $days;
           $this->db->update('vacation_balance',$data,array('emp_id'=>$id));
           $this->admin_model->addToLoggerUpdate('vacation_balance',143,'id',$this->db->insert_id(),102,102,$this->user);
       }elseif($typeOfVacation == 3){
           //sick
              $data['sick_leave'] = $credite->sick_leave - $days;
              $this->db->update('vacation_balance',$data,array('emp_id'=>$id));
              $this->admin_model->addToLoggerUpdate('vacation_balance',143,'id',$this->db->insert_id(),102,102,$this->user);
       }elseif($typeOfVacation == 4){
           //mariage
            $this->db->query("UPDATE vacation_balance SET marriage = '0' WHERE emp_id = '$id'");
            $this->admin_model->addToLoggerUpdate('vacation_balance',143,'id',$this->db->insert_id(),102,102,$this->user);
       }elseif($typeOfVacation == 5){
           //maternity
          $this->db->query("UPDATE vacation_balance SET maternity_leave = '0' WHERE emp_id = '$id'");
          $this->admin_model->addToLoggerUpdate('vacation_balance',143,'id',$this->db->insert_id(),102,102,$this->user);
       }elseif($typeOfVacation == 6){
           //death
           $data['death_leave'] = $credite->death_leave + $days;
           $this->db->update('vacation_balance',$data,array('emp_id'=>$id));
           $this->admin_model->addToLoggerUpdate('vacation_balance',143,'id',$this->db->insert_id(),102,102,$this->user);
       }elseif($typeOfVacation == 7){
           //hajj
        $this->db->query("UPDATE vacation_balance SET hajj = '0' WHERE emp_id = '$id'");
        $this->admin_model->addToLoggerUpdate('vacation_balance',143,'id',$this->db->insert_id(),102,102,$this->user);
       }
   } 
   public function getRequestedDays($start_date,$end_date,$type_of_vacation = "0"){
        //calculate number of days with out sat and sun
            $diff = strtotime($end_date) - strtotime($start_date);
             $size = (floor($diff / (60*60*24))) + 1;  
             $arr = [];
             for($i = 0 ; $i < $size ; $i++){
                 $startDateToTimestamp = strtotime($start_date. ' + '.$i.' days');
                 $day = date('D', $startDateToTimestamp);
                 // 
                    $end_date_format = date('Y-m-d', strtotime($start_date. ' + '.$i.' days'));

                     $holidays = $this->db->query("SELECT * FROM `holidays_plan` where holiday_date = '$end_date_format'")->num_rows();
                 //
                 if($type_of_vacation != 3){
                        if($day == 'Sat' || $day == 'Sun'|| $holidays > 0){
                        continue; 
                      }
                 }
                 
                 $arr[] = $day;
              }
              $data = sizeof($arr) ;
           //    $holidays = $this->db->query("SELECT * FROM `holidays_plan` where holiday_date BETWEEN '$start_date' AND '$end_date'")->num_rows();
           //    $lastData = $data - $holidays;
           // return $lastData;
              return $data;
    }
    public function getEndDate($type_of_vacation,$start_date,$end_date = "0",$death_leave_degree){
        //calculate end date dependon type of vacation with out date and time 
            if($type_of_vacation == 4){ 
                //mariage end date after 5 days without sat and sun
                $arr = [];
                $size = 5 ;
                 for($i = 0 ; $i < $size; $i++){
                     $startDateToTimestamp = strtotime($start_date. ' + '.$i.' days');
                     $day = date('D', $startDateToTimestamp);
                     $end_date_format = date('Y-m-d', strtotime($start_date. ' + '.$i.' days'));

                     $holidays = $this->db->query("SELECT * FROM `holidays_plan` where holiday_date = '$end_date_format'")->num_rows();

                     if($day == 'Sat' || $day == 'Sun' || $holidays > 0 ){
                        $size++;
                        continue; 
                      }
                      $arr[] =  $end_date_format;
                  }
                 $endDate = array_pop($arr);
            }elseif ( $type_of_vacation == 5) {
                //matrinety leave for 3 month as 90 days
                $endDate = date('Y-m-d', strtotime($start_date. ' + 90 days'));
            }elseif ( $type_of_vacation == 6) {
                //death leave depend on relative degree
                if($death_leave_degree == 1){
                    $arr = [];
                     $size = 3 ;
                     for($i = 0 ; $i < $size; $i++){
                         $startDateToTimestamp = strtotime($start_date. ' + '.$i.' days');
                         $day = date('D', $startDateToTimestamp);
                         $end_date_format = date('Y-m-d', strtotime($start_date. ' + '.$i.' days'));
                         $holidays = $this->db->query("SELECT * FROM `holidays_plan` where holiday_date = '$end_date_format'")->num_rows();
                         if($day == 'Sat' || $day == 'Sun' || $holidays > 0){
                            $size++;
                            continue; 
                          }
                          $arr[] =  $end_date_format;
                      }
                     $endDate = array_pop($arr);
                }elseif($death_leave_degree == 2){
                 $arr = [];
                    $size = 1 ;
                     for($i = 0 ; $i < $size; $i++){
                         $startDateToTimestamp = strtotime($start_date. ' + '.$i.' days');
                         $day = date('D', $startDateToTimestamp);
                         $end_date_format = date('Y-m-d', strtotime($start_date. ' + '.$i.' days'));
                         $holidays = $this->db->query("SELECT * FROM `holidays_plan` where holiday_date = '$end_date_format'")->num_rows();
                         if($day == 'Sat' || $day == 'Sun' || $holidays > 0){
                            $size++;
                            continue; 
                          }
                          $arr[] =  $end_date_format;
                      }
                     $endDate = array_pop($arr);
                    }
            }elseif ( $type_of_vacation == 7) {
                //hajj leave for 1 month as 30 days
                $endDate = date('Y-m-d', strtotime($start_date. ' + 30 days'));
            }else{
              $endDate = $end_date;
            }
            return $endDate;
    }  
     ///on approve 
    public function onApprove($start_date,$end_date,$emp_id){
        $data = $this->db->query("SELECT * FROM `vacation_transaction` WHERE emp_id = '$emp_id' and status = 1 ")->result();
         $counter = 0;
        foreach ($data as $data) {
          $oldRequest = $this->hr_model->getArrayOfRequestedDays($data->start_date,$data->end_date);
          $newRequest = $this->hr_model->getArrayOfRequestedDays($start_date,$end_date);
            for($i = 0 ; $i < sizeof($newRequest) ; $i++){
                if (in_array($newRequest[$i], $oldRequest,true)) {
                    $counter = $counter + 1 ;

                }
            }            
        }
        return $counter;
    } 

    // public function validateVacRequestedDays($start_date,$end_date,$emp_id){
    //     $data = $this->db->query("SELECT * FROM `vacation_transaction` WHERE emp_id = '$emp_id' AND (start_date <= '$start_date' AND end_date >= '$end_date') AND status = 1 ")->num_rows();
    //     return $data;
    // }
     public function getArrayOfRequestedDays($start_date,$end_date){
        //to return array of days at request
         $diff = strtotime($end_date) - strtotime($start_date);
         $size = (floor($diff / (60*60*24))) + 1; 
         $arr = [];
         for($i = 0 ; $i < $size ; $i++){
             $startDateToTimestamp = strtotime($start_date. ' + '.$i.' days');
             $day = date('Y-m-d', $startDateToTimestamp);
             $arr[] = $day;
          }
          $data = $arr;
          return $data;
    }

     //////  ///end vacation
   
  public function selectEmployeeForVT($id="")
    {
        $employee = $this->db->get('employees')->result();
        $data = "";
        foreach ($employee as $employee) {
             $excist = $this->db->query("SELECT * FROM vacation_balance WHERE emp_id = '$employee->id'")->row();
              if($excist){
                continue;
              } 
              if($employee->status == 1){
                continue;
              }
            if ($employee->id == $id) {
                $data .= "<option value='" . $employee->id . "' selected='selected'>" . $employee->name . "</option>";
            } else {
                $data .= "<option value='" . $employee->id . "'>" . $employee->name . "</option>";
            }
        }
        return $data;
    } 



    public function AllVacationBalance($permission,$user,$brand,$filter){
      if($permission->view == 1){
            $data = $this->db->query("SELECT * FROM `vacation_balance` WHERE brand = '$brand' AND ".$filter." ORDER BY id DESC ");
        }elseif($permission->view == 2){
        $data = $this->db->query(" SELECT * FROM `vacation_balance` WHERE brand = '$brand' AND created_by ='$user' AND ".$filter." ORDER BY id DESC ");
       }
        return $data;
    } 
    public function AllVacationBalancePages($permission,$user,$brand,$limit,$offset){
         if($permission->view == 1){
            $data = $this->db->query(" SELECT * FROM `vacation_balance` WHERE brand = '$brand' ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT * FROM `vacation_balance` WHERE brand = '$brand' AND created_by ='$user' ORDER BY id DESC LIMIT $limit OFFSET $offset");
        }
        return $data;
    } 

   ////

     public function AllMissingAttendance($permission,$user,$filter){
        if($permission->view == 1){
           // $data = $this->db->query("SELECT * FROM `missing_attendance` ");
            if($this->role == 31){
                $data = $this->db->query(" SELECT * FROM `missing_attendance` WHERE ".$filter." ");
            }else{
                $data = $this->db->query(" SELECT * FROM `missing_attendance` WHERE ".$filter." AND created_by ='$user'");
            }
          }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT * FROM `missing_attendance` WHERE ".$filter." AND created_by ='$user'");
          }
        return $data;
    } 
public function AllMissingAttendancePages($permission,$user,$limit,$offset){
        if($permission->view == 1){
            //$data = $this->db->query("SELECT * FROM `missing_attendance` ");
            if($this->role == 31){
                $data = $this->db->query(" SELECT * FROM `missing_attendance` ORDER BY id DESC LIMIT $limit OFFSET $offset");            
            }else{
                $data = $this->db->query(" SELECT * FROM `missing_attendance` WHERE created_by ='$user' ORDER BY id DESC LIMIT $limit OFFSET $offset");
            }
          }elseif($permission->view == 2){
             $data = $this->db->query(" SELECT * FROM `missing_attendance` WHERE created_by ='$user' ORDER BY id DESC LIMIT $limit OFFSET $offset");
          }
        return $data;
    } 
    //////////

    public function getTitleData($title){
        $structure = $this->db->get_where('structure',array('id'=>$title,'brand'=>$this->brand))->row();

        $data = "<table class='table table-striped table-hover table-bordered' style='overflow:scroll;'>
                    <thead>
                    <tr>
                        <th>Track</th>
                        <th>Direct Manager Title</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>".self::getTrack($structure->track)."</td>
                        <td>".self::getTitle($structure->parent)."</td>
                    </tr>
                    </tbody>
                </table>";
        return $data;
    }

	public function getDirectManagerByTitle($title){
    	$structure = $this->db->get_where('structure',array('id'=>$title,'brand'=>$this->brand))->row();
    	$manager = $this->db->get_where('employees',array('title'=>$structure->parent,'brand'=>$this->brand))->result();
    	//$data = "<option disabled='disabled' selected=''>-- Select Manager --</option>";
        foreach ($manager as $manager) {
            if ($manager->id == $id) {
                $data = "<option value='" . $manager->id . "' selected='selected'>" . $manager->name . "</option>";
            } else {
                $data = "<option value='" . $manager->id . "'>" . $manager->name . "</option>";
            }
        }
        return $data;
    }
  ////social insurance 
    public function AllSocialInsurance($permission,$user,$filter){
      if($permission->view == 1){
            $data = $this->db->query("SELECT * FROM `social_insurance` WHERE ".$filter." ORDER BY id DESC ");
        }elseif($permission->view == 2){
        $data = $this->db->query(" SELECT * FROM `social_insurance` WHERE created_by ='$user' AND ".$filter." ORDER BY id DESC ");
       }
        return $data;
    } 
    public function AllSocialInsurancePages($permission,$user,$limit,$offset){
         if($permission->view == 1){
            $data = $this->db->query(" SELECT * FROM `social_insurance` ORDER BY id DESC LIMIT $limit OFFSET $offset");
        }elseif($permission->view == 2){
            $data = $this->db->query(" SELECT * FROM `social_insurance` WHERE created_by ='$user' ");
        }
        return $data;
    }  

    public function selectEmployeeForSocialInsurance($id="")
    {
        $employees = $this->db->get('employees')->result();
        $data = "";
        foreach ($employees as $employee) {
             $excist = $this->db->query("SELECT * FROM social_insurance WHERE employee_id = '$employee->id'")->row();
              if($excist){
                continue;
              }
            if ($employee->id == $id) {
                $data .= "<option value='" . $employee->id . "' selected='selected'>" . $employee->name . "</option>";
            } else {
                $data .= "<option value='" . $employee->id . "'>" . $employee->name . "</option>";
            }
        }
        return $data;
    }  
 ////for strucure tree view
    /* public function getChild($title="")
    {
        $child = $this->db->query("SELECT * From structure WHERE parent = '$title'")->result();
        $data = "";
        foreach ($child as $child) {
         //$data .= "<h5>". $child->title . "</h5>";
           $data .= "<h5 onclick='get_grand_child()'>". $child->title . "</h5>";
          $data .= "<div id='item2' style='display: none; padding-left: 25px'>"
                         . self::getGrandChild($child->id). 
                    "</div>";
        }
       return $data;

    }
     public function getGrandChild($title="")
    {
        $grandChild = $this->db->query("SELECT * From structure WHERE parent = '$title'")->result();
        $data = "";
        foreach ($grandChild as $child) {
           $data .= "<h6>". $child->title . "</h6>";
           // $data .= "test";
          
        }
        return $data;

    }*/

        public function selectYear($id="")
    {
        $year = $this->db->get('years')->result();
        $data = "";
        foreach ($year as $year) {
            if ($year->id == $id) {
                $data .= "<option value='" . $year->id . "' selected='selected'>" . $year->name . "</option>";
            } else {
                $data .= "<option value='" . $year->id . "'>" . $year->name . "</option>";
            }
        }
        return $data;
    }


    public function getYear($year){

        $result = $this->db->get_where('years',array('id' => $year))->row();
        if(isset($result->name)){
            return $result->name;
        }else{
            return '';
        }
    }

    public function AllHolidayPlan($filter)
    {
        $data = $this->db->query(" SELECT * FROM `holidays_plan` WHERE ".$filter." ORDER BY id DESC ");
        return $data;
    }

    public function AllHolidayPlanPages($limit,$offset)
    {
        $data = $this->db->query("SELECT * FROM `holidays_plan` ORDER BY id DESC LIMIT $limit OFFSET $offset ");
        return $data;
    } 

     public function AllVacationRequests($filter){
      $data = $this->db->query("SELECT * FROM `vacation_transaction` WHERE ".$filter." ORDER BY id DESC ");
        return $data;
    } 
    public function AllVacationRequestsPages($limit,$offset){
         
      $data = $this->db->query(" SELECT * FROM `vacation_transaction` ORDER BY id DESC LIMIT $limit OFFSET $offset");
        return $data;
    } 
    //missing attendance 
     public function getMissingAttendanceRequests($emp_id,$title,$start_date=0,$end_date=0){
        if($title == 37 ){
         $data = $this->db->query("SELECT * FROM missing_attendance WHERE (manager_approval = 0 or hr_approval = 0) AND SRVDT BETWEEN '$start_date' AND '$end_date' ORDER BY `missing_attendance`.`SRVDT` ASC");
        }else{
            $data = $this->db->query("SELECT * FROM missing_attendance WHERE USRID in (SELECT id FROM employees WHERE manager = '$emp_id' ) HAVING manager_approval = 0 or hr_approval = 0 ");
        }
        return $data;
     }  

     //
       public function getResignationReason($id){ 
        $result = $this->db->get_where('resignation_reasons',array('id' => $id))->row();
        if(isset($result->reason)){
            return $result->reason;
        }else{
            return '';
        }
    }


        public function selectResignationReason($id="")
    {
        $reasons = $this->db->get('resignation_reasons')->result();
        $data = "";
        foreach ($reasons as $reason) {
            if ($reason->id == $id) {
                $data .= "<option value='" . $reason->id . "' selected='selected'>" . $reason->reason . "</option>";
            } else {
                $data .= "<option value='" . $reason->id . "'>" . $reason->reason . "</option>";
            }
        }
        return $data;
    } 

    //// 

        public function sendMissingAttendanceRequestMail($data,$brand){
        $managerId = $this->hr_model->getManagerId($data['USRID']);
        $managerMail = $this->db->get_where('users',array('employees_id'=>$managerId,'brand'=>$brand))->row()->email;
        $managerName = $this->db->get_where('users',array('employees_id'=>$managerId,'brand'=>$brand))->row()->first_name;
        $employeeMail = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        $mailTo= $managerMail;
            if($data['TNAKEY']== 1){
               $TNAKEY = "Sign In" ;
            }elseif($data['TNAKEY'] == 2){ 
               $TNAKEY = "Sign Out" ;
            } 
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        //$headers .= "Cc: ".$employeeMail."\r\n";
        $headers .= 'From: '.$employeeMail."\r\n";
       
        $subject = "New Missing Attendance Request ";
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body>
                     <p> Hello '.$managerName.' , </P>
                    <p> There is Missing Attendance Request from '. Self::getEmployee($data['USRID']).' need to be <a href="'.base_url().'hr/attendance" target="_blank"> Approved ..</a>  </p>
                    <table class="table table-striped  table-hover table-bordered" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center" id="">
                    <thead>
                      <tr>
                        
                         <th>Employee Name</th>
                         <th>Date </th>
                         <th>Sign In/Out</th>

                       
                      </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>'. Self::getEmployee($data['USRID']) .'</td>
                        <td>'. $data['SRVDT'] .'</td>
                        <td>'. $TNAKEY .'</td>
                      </tr>
                      </tbody>
                    </table> 

                     <p> Thank you, </p>
                     <p> div Team </p>
                    </body>
                    </html>';
      //    echo "$message"; 
      mail($mailTo,$subject,$message,$headers);
    }
      
      ///

    public function sendVacationRequestMail($data,$brand){
        $managerId = $this->hr_model->getManagerId($data['emp_id']);
        $managerMail = $this->db->get_where('users',array('employees_id'=>$managerId,'brand'=>$brand))->row()->email;
        $managerName = $this->db->get_where('users',array('employees_id'=>$managerId,'brand'=>$brand))->row()->first_name;
        $employeeMail = $this->db->get_where('users',array('id'=>$this->user))->row()->email;
        $mailTo= $managerMail;
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        //$headers .= "Cc: ".$employeeMail."\r\n";
        $headers .= 'From: '.$employeeMail."\r\n";
       
        $subject = "New Vacation Request ";
        
        $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <meta name="description" content="">
                        <meta name="author" content="">
                        <link rel="shortcut icon" href="'.base_url().'assets/images/favicon.png">
                        <title>Falaq| Site Manager</title>
                        <style>
                        body {
                            font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                            font-size: 14px;
                            line-height: 1.428571429;
                            color: #333;
                        }
                        section#unseen
                        {
                            overflow: scroll;
                            width: 100%
                        }
                        th{
                          border: 1px solid;
                        }
                        td {
                          border: 1px solid;
                        }
                        </style>
                        <!--Core js-->
                    </head>

                    <body> 
                    <p> Hello '.$managerName.' , </P>
                    <p> There is Vacation Request from '. Self::getEmployee($data['emp_id']).' need to be <a href="'.base_url().'hr/vacation" target="_blank"> Approved ..</a>  </p>
                    <table class="table table-striped  table-hover table-bordered" style="overflow:scroll;border: 1px solid;width: 100%;text-align: center" id="">
                    <thead>
                      <tr>
                        
                            <th>Employee Name</th>
                            <th>Type of vacation</th>
                            <th>Start Date</th>
                            <th>End Date</th>       
                                     

                       
                      </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>'. Self::getEmployee($data['emp_id']) .'</td>
                        <td>'. Self::getAllVacationTypies($data['type_of_vacation ']) .'</td>
                        <td>'. $data['start_date'] .'</td>
                        <td>'. $data['end_date'] .'</td>
                      </tr>
                      </tbody>
                    </table> 

                     <p> Thank you, </p>
                     <p> div Team </p>
                    </body>
                    </html>';
      mail($mailTo,$subject,$message,$headers);
    }
     //
         public function getDoubleDaysEmployeeData($emp_id,$brand){
             $data = $this->db->query(" SELECT * FROM `employees` where id = '$emp_id'")->row();
             if($data->brand == 2){
                return false;
             }elseif ($data->brand == 1) {
                   if($data->division == 4){
                    return false;
                   }else{
                    return true;
                   }
              }
         }
    /////

}